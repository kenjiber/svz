package com.svz.posesion;

import com.svz.posesion.data.PosesionPlayer;
import com.svz.posesion.logic.PlayerPhases;
import net.minecraft.server.level.ServerPlayer;

/** API pública de SVZ-Posesion. Fases: 0 Sano, 1 Marcado, 2 Tejido, 3 Poseído, 4 Consumido. */
public final class PosesionAPI {
    private PosesionAPI() {}

    public static int getFase(ServerPlayer p) {
        return PosesionPlayer.get(p).fase;
    }

    /** Cambia la fase aplicando todos sus efectos (fase 3: cuerpo Títere Jugador y traslado al Telar). */
    public static void setFase(ServerPlayer p, int fase) {
        PlayerPhases.setFase(p.level().getServer(), p, fase);
    }

    public static void liberar(ServerPlayer p) {
        PlayerPhases.liberar(p.level().getServer(), p);
    }
}
