package com.svz.posesion;

import com.svz.core.SVZConfig;
import com.svz.mobs.SVZMobsMod;
import com.svz.posesion.command.PosesionCommands;
import com.svz.posesion.data.PosesionPlayer;
import com.svz.posesion.data.PosesionWorld;
import com.svz.posesion.logic.DailyPossession;
import com.svz.posesion.logic.DrainRules;
import com.svz.posesion.logic.PlayerPhases;
import com.svz.posesion.logic.RitualRescate;
import com.svz.posesion.logic.SaberRobado;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SVZPosesionMod implements ModInitializer {
    public static final String MOD_ID = "svz-posesion";
    public static final Logger LOGGER = LoggerFactory.getLogger("SVZ-Posesion");
    public static PosesionConfig CONFIG;

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        CONFIG = PosesionConfig.load();
        PosesionPlayer.register();
        PosesionWorld.register();

        // SVZ-Posesion pasa a gobernar la posesión: se desactivan las versiones simples de los otros mods
        SVZMobsMod.CONFIG.poseidosPorDia = 0;            // la posesión diaria la hace este mod
        SVZMobsMod.CONFIG.titereJugadorAlPoseer = false;  // el Títere Jugador lo crea este mod (con dueño)
        SVZMobsMod.CONFIG.drenajeIntegrado = false;       // el drenaje por golpes lo aplica este mod
        SVZConfig.DRENAJE_JUGADOR_POSEIDO = false;        // idem para jugadores poseídos (SVZ-Core)

        PlayerPhases.register();
        DrainRules.register();
        SaberRobado.register();
        RitualRescate.register();
        PosesionCommands.register();

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            int t = server.getTickCount();
            DrainRules.tick(server, t);
            if (t % 5 == 0) SaberRobado.tickRapido(server);
            if (t % 10 == 0) {
                PlayerPhases.tick(server, t);
                SaberRobado.rastrear(server);
            }
            if (t % 20 == 0) {
                DailyPossession.tick(server);
                SaberRobado.tickLento(server, t);
            }
        });
        LOGGER.info("SVZ-Posesion cargado.");
    }
}
