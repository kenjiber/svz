package com.svz.posesion.data;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.svz.posesion.SVZPosesionMod;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.minecraft.server.MinecraftServer;

import java.util.ArrayList;
import java.util.List;

/** Estado del mundo (en el Overworld): último amanecer procesado y el saber robado de Chef y Herrero. */
public class PosesionWorld {
    public long ultimoDia = -1;
    /** Día en que un Chef / Herrero fue poseído (-1 = nadie) y lo que sabía. */
    public long chefDia = -1, herreroDia = -1;
    public final List<String> chefRecetas = new ArrayList<>(), herreroArmas = new ArrayList<>();
    public int chefPurificado, herreroPurificado;

    public static AttachmentType<PosesionWorld> TYPE;

    public static final Codec<PosesionWorld> CODEC = RecordCodecBuilder.create(i -> i.group(
            Codec.LONG.optionalFieldOf("ultimo_dia", -1L).forGetter(d -> d.ultimoDia),
            Codec.LONG.optionalFieldOf("chef_dia", -1L).forGetter(d -> d.chefDia),
            Codec.LONG.optionalFieldOf("herrero_dia", -1L).forGetter(d -> d.herreroDia),
            Codec.STRING.listOf().optionalFieldOf("chef_recetas", List.of()).forGetter(d -> d.chefRecetas),
            Codec.STRING.listOf().optionalFieldOf("herrero_armas", List.of()).forGetter(d -> d.herreroArmas),
            Codec.INT.optionalFieldOf("chef_purificado", 0).forGetter(d -> d.chefPurificado),
            Codec.INT.optionalFieldOf("herrero_purificado", 0).forGetter(d -> d.herreroPurificado)
    ).apply(i, PosesionWorld::new));

    public PosesionWorld() {}

    private PosesionWorld(long ultimo, long chefDia, long herreroDia, List<String> chef, List<String> herrero, int cp, int hp) {
        this.ultimoDia = ultimo;
        this.chefDia = chefDia;
        this.herreroDia = herreroDia;
        this.chefRecetas.addAll(chef);
        this.herreroArmas.addAll(herrero);
        this.chefPurificado = cp;
        this.herreroPurificado = hp;
    }

    public static void register() {
        TYPE = AttachmentRegistry.<PosesionWorld>create(SVZPosesionMod.id("mundo"),
                b -> b.initializer(PosesionWorld::new).persistent(CODEC));
    }

    public static PosesionWorld get(MinecraftServer server) {
        return server.overworld().getAttachedOrCreate(TYPE);
    }
}
