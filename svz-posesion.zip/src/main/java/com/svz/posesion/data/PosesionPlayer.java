package com.svz.posesion.data;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.svz.posesion.SVZPosesionMod;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.minecraft.server.level.ServerPlayer;

import java.util.ArrayList;
import java.util.List;

/** Datos persistentes de posesión por jugador. Fase: 0 sano, 1 Marcado, 2 Tejido, 3 Poseído, 4 Consumido. */
public class PosesionPlayer {
    public int fase;
    public long diaInicio;
    /** UUID (texto) del cuerpo Títere Jugador, o "". */
    public String cuerpo = "";
    /** Recetas (Chef) o armas (Herrero) usadas por último, la más reciente primero. */
    public final List<String> historial = new ArrayList<>();

    public static AttachmentType<PosesionPlayer> TYPE;

    public static final Codec<PosesionPlayer> CODEC = RecordCodecBuilder.create(i -> i.group(
            Codec.INT.optionalFieldOf("fase", 0).forGetter(d -> d.fase),
            Codec.LONG.optionalFieldOf("dia_inicio", 0L).forGetter(d -> d.diaInicio),
            Codec.STRING.optionalFieldOf("cuerpo", "").forGetter(d -> d.cuerpo),
            Codec.STRING.listOf().optionalFieldOf("historial", List.of()).forGetter(d -> d.historial)
    ).apply(i, PosesionPlayer::new));

    public PosesionPlayer() {}

    private PosesionPlayer(int fase, long dia, String cuerpo, List<String> historial) {
        this.fase = fase;
        this.diaInicio = dia;
        this.cuerpo = cuerpo;
        this.historial.addAll(historial);
    }

    public static void register() {
        TYPE = AttachmentRegistry.<PosesionPlayer>create(SVZPosesionMod.id("jugador"),
                b -> b.initializer(PosesionPlayer::new).persistent(CODEC).copyOnDeath());
    }

    public static PosesionPlayer get(ServerPlayer p) {
        return p.getAttachedOrCreate(TYPE);
    }
}
