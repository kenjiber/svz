package com.svz.posesion.logic;

import com.svz.core.api.SVZClass;
import com.svz.core.api.SVZCoreAPI;
import com.svz.core.event.SVZHilosChangeEvent;
import com.svz.mobs.entity.SVZMobMarker;
import com.svz.mobs.entity.SVZPossessed;
import com.svz.mobs.entity.boss.SVZBoss;
import com.svz.posesion.SVZPosesionMod;
import com.svz.posesion.data.PosesionPlayer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static com.svz.posesion.logic.SaberRobado.item;

/**
 * Reglas de drenaje de hilos (SVZ-Core las ejecuta con drenarHilos):
 * mobs poseídos -1 cada 3-5 golpes · jugadores poseídos / Títere Jugador -1 cada 2 · Espectro Títere -1 por golpe ·
 * mini-jefes -2 por habilidad (SVZ-Mobs) · Filo Oscuro +1 por golpe · ataque a un durmiente -1 · Hilo Negro -2 en área.
 */
public final class DrainRules {
    private DrainRules() {}

    public static final ParticleOptions ROJO = new DustParticleOptions(0xFF2020, 1.0F);
    private static final ParticleOptions NEGRO = new DustParticleOptions(0x101010, 1.6F);

    private static final Map<UUID, int[]> GOLPES = new HashMap<>();   // [contados, objetivo]
    private static final Map<UUID, Integer> BLOQUEOS_GUERRERO = new HashMap<>();
    private static final Map<UUID, Integer> PROXIMO_PULSO = new HashMap<>();
    private static final List<Entity> CACHE = new ArrayList<>();

    private record Rastro(ServerLevel nivel, Vec3 desde, Entity hasta, int[] edad) {}

    private static final List<Rastro> RASTROS = new ArrayList<>();

    /** Mobs de SVZ cargados (se refresca cada 2 s). */
    public static List<Entity> marcados() {
        CACHE.removeIf(e -> e.isRemoved() || !e.isAlive());
        return CACHE;
    }

    public static boolean esMarcado(Entity e) {
        return e instanceof SVZMobMarker || (e instanceof ServerPlayer p && SVZCoreAPI.isPoseido(p));
    }

    public static void register() {
        // ---- golpes
        ServerLivingEntityEvents.AFTER_DAMAGE.register((entity, source, base, tomado, bloqueado) -> {
            if (bloqueado || tomado <= 0 || !(entity instanceof ServerPlayer victima)) return;
            if (victima.isSpectator() || victima.isCreative()) return;
            Entity atacante = source.getEntity();
            if (atacante == null || atacante == victima || !esMarcado(atacante)) return;
            PosesionConfigRef c = new PosesionConfigRef();
            int n = 0;
            if (atacante instanceof SVZPossessed pm) {
                if (pm.svzState().profile.hitsPorDrenaje() == 1 || cuenta(atacante, c.min(), c.max())) n = 1;       // creeper: cada explosión
            } else if (atacante instanceof SVZBoss b) {
                String id = b.profile().id;
                if (id.equals("espectro_titere")) n = SVZPosesionMod.CONFIG.drenajeEspectroPorGolpe;
                else if (id.equals("titere_jugador") && cuenta(atacante, c.jug(), c.jug())) n = 1;
            } else if (atacante instanceof ServerPlayer ap && cuenta(atacante, c.jug(), c.jug())) {
                n = 1;
            }
            // Filo Oscuro: +1 hilo extra por golpe si el poseído lo lleva
            if (atacante instanceof LivingEntity le && le.getMainHandItem().is(item("filo_oscuro"))) n += 1;
            if (n > 0) drenar(victima, n, atacante);
        });

        // ---- ataque sorpresa: golpear a quien duerme cuesta 1 hilo automático
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, cantidad) -> {
            if (entity instanceof ServerPlayer v && v.isSleeping() && !v.isCreative()
                    && source.getEntity() instanceof LivingEntity a && esMarcado(a)) {
                drenar(v, 1, a);
                Msg.enviar(v, "sorpresa", true);
            }
            return true;
        });

        // ---- defensas de clase: devuelven el hilo drenado
        SVZHilosChangeEvent.EVENT.register((p, antes, despues, razon, fuente) -> {
            if (razon != SVZHilosChangeEvent.Reason.DRENAJE || despues >= antes) return;
            if (SVZCoreAPI.getHilos(p) >= antes) return; // otro mod (resistencia al control) ya lo devolvió
            if (!defiende(p)) return;
            SVZCoreAPI.addHilos(p, antes - despues);
            Msg.enviar(p, "bloqueo", true);
        });
    }

    /** Drena hilos y dibuja la partícula roja que viaja del jugador al poseído. */
    public static void drenar(ServerPlayer victima, int cantidad, Entity fuente) {
        SVZCoreAPI.drenarHilos(victima, cantidad, fuente);
        if (RASTROS.size() < 200) RASTROS.add(new Rastro((ServerLevel) victima.level(), victima.getEyePosition(), fuente, new int[]{0}));
    }

    private static boolean cuenta(Entity e, int min, int max) {
        int[] c = GOLPES.computeIfAbsent(e.getUUID(), k -> new int[]{0, min + (max > min ? e.level().getRandom().nextInt(max - min + 1) : 0)});
        if (++c[0] >= c[1]) {
            c[0] = 0;
            c[1] = min + (max > min ? e.level().getRandom().nextInt(max - min + 1) : 0);
            return true;
        }
        return false;
    }

    private static boolean defiende(ServerPlayer p) {
        var cfg = SVZPosesionMod.CONFIG;
        SVZClass clase = SVZCoreAPI.getClase(p);
        return switch (clase) {
            case GUERRERO -> cfg.defensaGuerrero && BLOQUEOS_GUERRERO.merge(p.getUUID(), 1, Integer::sum) % 3 == 0; // Voluntad de Hierro
            case HERRERO -> cfg.defensaHerrero && p.isBlocking();                                                    // Guardia de Acero
            case CHEF -> cfg.defensaChef && p.getFoodData().getFoodLevel() >= 18;                                    // Estómago Firme
            default -> false;
        };
    }

    // ------------------------------------------------------------ tick
    public static void tick(MinecraftServer server, int t) {
        // rastros: la partícula viaja en 8 ticks desde la víctima hasta el poseído
        Iterator<Rastro> it = RASTROS.iterator();
        while (it.hasNext()) {
            Rastro r = it.next();
            r.edad()[0]++;
            if (r.edad()[0] > 8 || r.hasta().isRemoved()) {
                it.remove();
                continue;
            }
            Vec3 destino = r.hasta().position().add(0, r.hasta().getBbHeight() * 0.6, 0);
            Vec3 p = r.desde().lerp(destino, r.edad()[0] / 8.0);
            r.nivel().sendParticles(ROJO, p.x, p.y, p.z, 2, 0.05, 0.05, 0.05, 0.0);
        }
        if (t % 40 == 0) {
            CACHE.clear();
            for (ServerLevel l : server.getAllLevels()) for (Entity e : l.getAllEntities()) if (e instanceof SVZMobMarker) CACHE.add(e);
            if (GOLPES.size() > 800) GOLPES.clear();
        }
        if (t % 20 == 0) hiloNegro(server, t);
    }

    /** Hilo Negro: los poseídos (Títere Jugador o jugador poseído en el mundo) drenan -2 en área cada 30 s. */
    private static void hiloNegro(MinecraftServer server, int t) {
        List<Entity> fuentes = new ArrayList<>();
        for (Entity e : marcados()) if (e instanceof SVZBoss b && b.profile().id.equals("titere_jugador")) fuentes.add(e);
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            if (SVZCoreAPI.isPoseido(p) && PosesionPlayer.get(p).fase >= 3 && !SVZCoreAPI.isInTelarRoto(p)) fuentes.add(p);
        }
        var cfg = SVZPosesionMod.CONFIG;
        for (Entity f : fuentes) {
            if (PROXIMO_PULSO.getOrDefault(f.getUUID(), 0) > t) continue;
            List<ServerPlayer> victimas = ((ServerLevel) f.level()).getEntitiesOfClass(ServerPlayer.class,
                    f.getBoundingBox().inflate(cfg.radioHiloNegro), v -> v != f && !v.isSpectator() && !v.isCreative());
            if (victimas.isEmpty()) continue;
            PROXIMO_PULSO.put(f.getUUID(), t + cfg.segundosHiloNegro * 20);
            ((ServerLevel) f.level()).sendParticles(NEGRO, f.getX(), f.getY() + 1, f.getZ(), 40, cfg.radioHiloNegro / 3.0, 0.6, cfg.radioHiloNegro / 3.0, 0.02);
            for (ServerPlayer v : victimas) drenar(v, cfg.drenajeHiloNegro, f);
        }
    }

    /** Atajo para leer los límites de golpes de la config. */
    private static final class PosesionConfigRef {
        int min() { return SVZPosesionMod.CONFIG.hitsMobMin; }
        int max() { return Math.max(SVZPosesionMod.CONFIG.hitsMobMin, SVZPosesionMod.CONFIG.hitsMobMax); }
        int jug() { return SVZPosesionMod.CONFIG.hitsJugadorPoseido; }
    }
}
