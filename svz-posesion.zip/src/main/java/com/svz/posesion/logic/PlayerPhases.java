package com.svz.posesion.logic;

import com.svz.core.api.SVZClass;
import com.svz.core.api.SVZCoreAPI;
import com.svz.core.event.SVZHilosChangeEvent;
import com.svz.core.event.SVZPosesionEvent;
import com.svz.items.api.SVZItemsAPI;
import com.svz.mobs.api.SVZMobsAPI;
import com.svz.posesion.SVZPosesionMod;
import com.svz.posesion.data.PosesionPlayer;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.Relative;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;

import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Fases de posesión de un jugador: 0 Sano → 1 Marcado → 2 Tejido → 3 Poseído → 4 Consumido.
 * 1 y 2 se alcanzan por drenaje (umbrales de hilos); 3 es perder el control: el cuerpo se queda como Títere Jugador
 * y el jugador despierta en el Umbral del Telar Roto; 4 llega si nadie lo rescata a tiempo.
 */
public final class PlayerPhases {
    private PlayerPhases() {}

    public static final String[] NOMBRES = {"Sano", "Marcado", "Tejido", "Poseído", "Consumido"};
    public static final String TAG_CUERPO = "svz_titere_de:";

    public static long dia(MinecraftServer s) {
        return s.overworld().getGameTime() / 24000L;
    }

    public static ServerLevel telar(MinecraftServer s) {
        for (ResourceKey<Level> k : s.levelKeys()) if (SVZCoreAPI.isTelarRoto(k)) return s.getLevel(k);
        return null;
    }

    // ------------------------------------------------------------ registro de eventos
    public static void register() {
        // Core marca a un jugador como poseído (0 hilos, admin o API): se completa el traspaso
        SVZPosesionEvent.EVENT.register((player, causa) -> {
            MinecraftServer s = player.level().getServer();
            if (s != null) s.execute(() -> entrarPoseido(s, player));
        });

        // Un drenaje puede dejar al jugador Marcado o Tejido
        SVZHilosChangeEvent.EVENT.register((p, antes, despues, razon, fuente) -> {
            if (razon != SVZHilosChangeEvent.Reason.DRENAJE || despues >= antes) return;
            MinecraftServer s = p.level().getServer();
            if (s != null) s.execute(() -> evaluar(p));
        });

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> comprobarConsumido(server, handler.getPlayer()));

        // Espejo de Forja: muestra la fase
        SVZItemsAPI.INSPECTORES.add(e -> {
            if (e instanceof ServerPlayer sp) {
                int f = PosesionPlayer.get(sp).fase;
                return f > 0 ? "Fase de posesión: " + NOMBRES[f] : null;
            }
            for (String t : e.getTags()) if (t.startsWith(TAG_CUERPO)) return "Cuerpo de un jugador poseído";
            return null;
        });
    }

    // ------------------------------------------------------------ transiciones
    /** Evalúa los umbrales tras un drenaje (después de que los defensores hayan devuelto hilos). */
    public static void evaluar(ServerPlayer p) {
        PosesionPlayer d = PosesionPlayer.get(p);
        if (d.fase >= 3) return;
        int max = Math.max(1, SVZCoreAPI.getMaxHilos(p));
        int h = SVZCoreAPI.getHilos(p);
        if (h <= 0) return; // el paso a Poseído lo dispara SVZ-Core
        int pct = h * 100 / max;
        if (pct <= SVZPosesionMod.CONFIG.umbralTejidoPct && d.fase < 2) aplicar(p, d, 2);
        else if (pct <= SVZPosesionMod.CONFIG.umbralMarcadoPct && d.fase < 1) aplicar(p, d, 1);
    }

    private static void aplicar(ServerPlayer p, PosesionPlayer d, int fase) {
        d.fase = fase;
        p.addTag(SVZItemsAPI.TAG_POSEIDO); // lo hace detectable para el Ojo de Títere
        Msg.enviar(p, "fase" + fase, Map.of("fase", NOMBRES[fase], "jugador", p.getName().getString()), false);
    }

    /** Fija una fase (comando de admin / API) aplicando todos sus efectos. */
    public static void setFase(MinecraftServer s, ServerPlayer p, int fase) {
        PosesionPlayer d = PosesionPlayer.get(p);
        switch (fase) {
            case 0 -> liberar(s, p);
            case 1, 2 -> {
                if (d.fase >= 3) liberar(s, p);
                aplicar(p, d, fase);
            }
            case 3 -> {
                if (!SVZCoreAPI.isPoseido(p)) SVZCoreAPI.setPoseido(p, true); // Core dispara el evento y se completa solo
                else entrarPoseido(s, p);
            }
            default -> consumir(s, p);
        }
    }

    /** Fase 3: el cuerpo queda como Títere Jugador y el jugador despierta en la Zona 1 del Telar Roto. */
    public static void entrarPoseido(MinecraftServer s, ServerPlayer p) {
        PosesionPlayer d = PosesionPlayer.get(p);
        if (d.fase >= 3) return;
        d.fase = 3;
        d.diaInicio = dia(s);
        p.addTag(SVZItemsAPI.TAG_POSEIDO);

        if (!SVZCoreAPI.isInTelarRoto(p)) {
            Mob cuerpo = SVZMobsAPI.crearTitereJugador(p); // copia completa del inventario
            if (cuerpo != null) d.cuerpo = cuerpo.getUUID().toString();
            ServerLevel telar = telar(s);
            if (telar != null) {
                double y = telar.getHeight(Heightmap.Types.MOTION_BLOCKING, 2, 2);
                p.teleportTo(telar, 2.5, y, 2.5, Set.<Relative>of(), p.getYRot(), p.getXRot(), true);
                SVZCoreAPI.iniciarHiloVidaInterno(p); // Hilo de Vida interno siempre 100
            }
        }
        SaberRobado.alPoseer(s, p, d);
        Msg.enviar(p, "fase3", Map.of("fase", NOMBRES[3], "jugador", p.getName().getString()), false);
    }

    /** Libera por completo: borra el cuerpo, quita la posesión y devuelve al jugador junto a su cuerpo. */
    public static void liberar(MinecraftServer s, ServerPlayer p) {
        PosesionPlayer d = PosesionPlayer.get(p);
        Entity cuerpo = null;
        if (!d.cuerpo.isEmpty()) {
            UUID id = UUID.fromString(d.cuerpo);
            for (ServerLevel l : s.getAllLevels()) {
                Entity e = l.getEntity(id);
                if (e != null) cuerpo = e;
            }
        }
        Vec3 pos = cuerpo != null ? cuerpo.position() : null;
        ServerLevel nivel = cuerpo != null ? (ServerLevel) cuerpo.level() : null;
        boolean conserva = cuerpo != null && llevaObjetos(cuerpo);
        if (cuerpo != null && !conserva) cuerpo.discard();
        if (conserva) { // el Títere sigue en pie con los objetos del jugador: hay que derrotarlo para recuperarlos
            for (String t : new java.util.ArrayList<>(cuerpo.getTags())) if (t.startsWith(TAG_CUERPO)) cuerpo.removeTag(t);
        }

        SaberRobado.alLiberar(s, p);
        boolean estabaMuerto = SVZCoreAPI.isMuertePermanente(p);
        d.fase = 0;
        d.cuerpo = "";
        p.removeTag(SVZItemsAPI.TAG_POSEIDO);
        if (estabaMuerto) SVZCoreAPI.setMuertePermanente(p, false);
        SVZCoreAPI.setPoseido(p, false);
        int objetivo = Math.max(3, SVZCoreAPI.getMaxHilos(p) / 2);
        if (SVZCoreAPI.getHilos(p) < objetivo) SVZCoreAPI.setHilos(p, objetivo);
        if (pos != null && SVZCoreAPI.isInTelarRoto(p)) {
            p.teleportTo(nivel, pos.x, pos.y, pos.z, Set.<Relative>of(), p.getYRot(), p.getXRot(), true);
        }
        Msg.enviar(p, "liberado", Map.of("jugador", p.getName().getString()), false);
        if (conserva) p.displayClientMessage(Component.literal("§6Tu Títere aún lleva todos tus objetos. Derrótalo para recuperarlos."), false);
    }

    private static boolean llevaObjetos(Entity e) {
        var l = e.getAttached(com.svz.mobs.entity.ModAttachments.INVENTARIO_COPIA);
        return l != null && !l.isEmpty();
    }

    /** Fase 4: el hilo se consume. Muerte permanente (solo un rescate del Telar puede devolverlo). */
    public static void consumir(MinecraftServer s, ServerPlayer p) {
        PosesionPlayer d = PosesionPlayer.get(p);
        if (!d.cuerpo.isEmpty()) {
            UUID id = UUID.fromString(d.cuerpo);
            for (ServerLevel l : s.getAllLevels()) {
                Entity e = l.getEntity(id);
                if (e != null && !llevaObjetos(e)) e.discard(); // si lleva objetos, se queda para que alguien los recupere
            }
            d.cuerpo = "";
        }
        d.fase = 4;
        SaberRobado.alLiberar(s, p);
        Msg.enviar(p, "fase4", Map.of("fase", NOMBRES[4], "jugador", p.getName().getString()), false);
        SVZCoreAPI.setMuertePermanente(p, true);
        if (p.isAlive()) p.kill((ServerLevel) p.level());
    }

    /** Se llama al amanecer y al conectarse: pasa a Consumido al agotar los días de plazo. */
    public static void comprobarConsumido(MinecraftServer s, ServerPlayer p) {
        PosesionPlayer d = PosesionPlayer.get(p);
        if (d.fase == 3 && dia(s) - d.diaInicio >= SVZPosesionMod.CONFIG.diasConsumido) consumir(s, p);
    }

    // ------------------------------------------------------------ síntomas (cada 10 ticks)
    public static void tick(MinecraftServer s, int t) {
        for (ServerPlayer p : s.getPlayerList().getPlayers()) {
            PosesionPlayer d = PosesionPlayer.get(p);
            if (d.fase == 0) continue;
            if (d.fase == 4 && !SVZCoreAPI.isMuertePermanente(p)) { // lo revivió un rescate del Telar
                d.fase = 0;
                p.removeTag(SVZItemsAPI.TAG_POSEIDO);
                continue;
            }
            if (d.fase > 3 || p.isSpectator()) continue;
            sintomas(p, d, t);
        }
    }

    private static void sintomas(ServerPlayer p, PosesionPlayer d, int t) {
        ServerLevel lvl = (ServerLevel) p.level();
        // ojos rojos intermitentes
        boolean parpadeo = d.fase >= 2 ? (t / 10) % 2 == 0 : (t / 10) % 6 == 0;
        if (parpadeo) {
            Vec3 look = p.getLookAngle();
            Vec3 ojo = p.getEyePosition().add(look.x * 0.3, 0, look.z * 0.3);
            Vec3 lado = new Vec3(-look.z, 0, look.x).normalize().scale(0.12);
            lvl.sendParticles(DrainRules.ROJO, ojo.x + lado.x, ojo.y, ojo.z + lado.z, 1, 0, 0, 0, 0);
            lvl.sendParticles(DrainRules.ROJO, ojo.x - lado.x, ojo.y, ojo.z - lado.z, 1, 0, 0, 0, 0);
        }
        if (t % 20 == 0) {
            lvl.sendParticles(ParticleTypes.CRIMSON_SPORE, p.getX(), p.getY() + 1.0, p.getZ(), d.fase * 2, 0.4, 0.7, 0.4, 0.0);
            if (d.fase >= 2) lvl.sendParticles(DrainRules.ROJO, p.getX(), p.getY() + 1.0, p.getZ(), 4, 0.4, 0.7, 0.4, 0.02);
            // susurros
            var lista = SVZPosesionMod.CONFIG.susurros;
            if (!lista.isEmpty() && p.getRandom().nextFloat() < 0.04F * d.fase) {
                p.displayClientMessage(Component.literal("§8§o" + lista.get(p.getRandom().nextInt(lista.size()))), true);
                // ← CORREGIDO: playNotifySound ya no existe, usamos level().playSound()
                lvl.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.WARDEN_HEARTBEAT, SoundSource.AMBIENT, 0.7F, 1.0F);
            }
        }
        if (d.fase >= 2 && t % 400 == 0) p.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 60, 0, false, false));
    }
}