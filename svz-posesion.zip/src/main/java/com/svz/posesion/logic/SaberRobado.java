package com.svz.posesion.logic;

import com.svz.core.api.SVZClass;
import com.svz.core.api.SVZCoreAPI;
import com.svz.posesion.SVZPosesionMod;
import com.svz.posesion.data.PosesionPlayer;
import com.svz.posesion.data.PosesionWorld;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.zombie.Zombie;              // ← CORREGIDO
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * El saber robado. Si un Chef es poseído, los mobs "comen" sus últimas recetas; si lo es un Herrero, equipan sus últimas
 * armas. Corrupción: 1 día = 1 elemento, 2 = 2, 3 = 3, 4 o más = toda la línea.
 * Purificación: Banquete de Purificación (comer un Banquete Criollo / del Segundo Hilo) o Forja Sagrada
 * (clic con un Núcleo de Hilo sobre un yunque).
 */
public final class SaberRobado {
    private SaberRobado() {}

    public static final List<String> RECETAS_CHEF = List.of("arepa_basica", "cachapa_veloz", "tequeno_de_absorcion", "pabellon_criollo",
            "tizana_de_los_andes", "hallaca_legendaria", "pabellon_supremo", "banquete_criollo", "arepa_de_la_resistencia",
            "cafe_de_los_andes", "plato_del_segundo_hilo", "arepa_espectral", "cachapa_de_los_caidos", "tequeno_de_hilo",
            "pabellon_del_mas_alla", "hallaca_eterna", "banquete_del_segundo_hilo");
    public static final List<String> ARMAS_HERRERO = List.of("hacha_de_cobre", "machete_de_hierro", "lanza_llanera", "martillo_rompehilos",
            "espada_de_acero", "filo_cortahilos", "filo_oscuro", "hacha_espectral", "machete_de_alma", "lanza_del_mas_alla",
            "martillo_de_nudos", "filo_del_segundo_hilo");

    private static final Set<UUID> COMIENDO = new HashSet<>();

    public static Item item(String path) {
        return BuiltInRegistries.ITEM.getValue(Identifier.fromNamespaceAndPath("svz-items", path));
    }

    private static String id(ItemStack s) {
        Identifier k = BuiltInRegistries.ITEM.getKey(s.getItem());
        return k.getNamespace().equals("svz-items") ? k.getPath() : "";
    }

    // ------------------------------------------------------------ registro
    public static void register() {
        // Forja Sagrada: Núcleo de Hilo sobre un yunque
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (!(world instanceof ServerLevel level) || !(player instanceof ServerPlayer sp) || hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
            ItemStack st = sp.getItemInHand(hand);
            if (!st.is(item("nucleo_de_hilo")) || !level.getBlockState(hit.getBlockPos()).is(BlockTags.ANVIL)) return InteractionResult.PASS;
            PosesionWorld w = PosesionWorld.get(level.getServer());
            if (w.herreroDia < 0) {
                sp.displayClientMessage(Component.literal("§7La forja no siente ninguna corrupción."), true);
                return InteractionResult.SUCCESS;
            }
            if (!sp.getAbilities().instabuild) st.shrink(1);
            w.herreroPurificado++;
            level.sendParticles(ParticleTypes.END_ROD, hit.getBlockPos().getX() + 0.5, hit.getBlockPos().getY() + 1.2, hit.getBlockPos().getZ() + 0.5, 25, 0.4, 0.4, 0.4, 0.05);
            Msg.enviar(sp, "purificacion", false);
            return InteractionResult.SUCCESS;
        });
    }

    // ------------------------------------------------------------ rastreo de lo que sabe cada jugador (cada 10 ticks)
    public static void rastrear(MinecraftServer server) {
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            SVZClass clase = SVZCoreAPI.getClase(p);
            if (clase == SVZClass.CHEF && p.isUsingItem()) {
                String i = id(p.getUseItem());
                if (RECETAS_CHEF.contains(i)) recordar(PosesionPlayer.get(p), i);
            } else if (clase == SVZClass.HERRERO) {
                String i = id(p.getMainHandItem());
                if (ARMAS_HERRERO.contains(i)) recordar(PosesionPlayer.get(p), i);
            }
        }
    }

    private static void recordar(PosesionPlayer d, String id) {
        if (!d.historial.isEmpty() && d.historial.get(0).equals(id)) return;
        d.historial.remove(id);
        d.historial.add(0, id);
        while (d.historial.size() > 12) d.historial.remove(d.historial.size() - 1);
    }

    // ------------------------------------------------------------ posesión / liberación
    public static void alPoseer(MinecraftServer s, ServerPlayer p, PosesionPlayer d) {
        PosesionWorld w = PosesionWorld.get(s);
        long dia = PlayerPhases.dia(s);
        switch (SVZCoreAPI.getClase(p)) {
            case CHEF -> {
                w.chefDia = dia;
                w.chefPurificado = 0;
                w.chefRecetas.clear();
                w.chefRecetas.addAll(d.historial);
            }
            case HERRERO -> {
                w.herreroDia = dia;
                w.herreroPurificado = 0;
                w.herreroArmas.clear();
                w.herreroArmas.addAll(d.historial);
            }
            default -> { }
        }
    }

    public static void alLiberar(MinecraftServer s, ServerPlayer p) {
        PosesionWorld w = PosesionWorld.get(s);
        switch (SVZCoreAPI.getClase(p)) {
            case CHEF -> {
                w.chefDia = -1;
                w.chefRecetas.clear();
            }
            case HERRERO -> {
                w.herreroDia = -1;
                w.herreroArmas.clear();
            }
            default -> { }
        }
    }

    // ------------------------------------------------------------ corrupción
    private static int nivel(long dia, long inicio, int purificado) {
        if (inicio < 0) return 0;
        return (int) Math.max(0, Math.min(4, dia - inicio - purificado));
    }

    private static List<String> robadas(List<String> historial, List<String> linea, int nivel) {
        if (nivel <= 0) return List.of();
        if (nivel >= 4) return linea; // toda la línea
        return new ArrayList<>(historial.subList(0, Math.min(nivel, historial.size())));
    }

    // ------------------------------------------------------------ efectos sobre los mobs
    /** Cada 5 ticks: detecta el Banquete de Purificación (comer un banquete). */
    public static void tickRapido(MinecraftServer server) {
        PosesionWorld w = PosesionWorld.get(server);
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            boolean banquete = p.isUsingItem() && (p.getUseItem().is(item("banquete_criollo")) || p.getUseItem().is(item("banquete_del_segundo_hilo")));
            if (!banquete) {
                COMIENDO.remove(p.getUUID());
                continue;
            }
            if (p.getUseItemRemainingTicks() <= 6 && COMIENDO.add(p.getUUID()) && w.chefDia >= 0) {
                w.chefPurificado++;
                for (ServerPlayer o : ((ServerLevel) p.level()).getEntitiesOfClass(ServerPlayer.class, p.getBoundingBox().inflate(12))) {
                    Msg.enviar(o, "purificacion", false);
                }
            }
        }
    }

    /** Cada segundo: los mobs comen recetas robadas y equipan armas robadas. */
    public static void tickLento(MinecraftServer server, int t) {
        PosesionWorld w = PosesionWorld.get(server);
        long dia = PlayerPhases.dia(server);
        List<String> comidas = robadas(w.chefRecetas, RECETAS_CHEF.subList(0, 11), nivel(dia, w.chefDia, w.chefPurificado));
        List<String> armas = robadas(w.herreroArmas, ARMAS_HERRERO, nivel(dia, w.herreroDia, w.herreroPurificado));
        if (comidas.isEmpty() && armas.isEmpty()) return;
        boolean comer = t % (SVZPosesionMod.CONFIG.segundosComerMobs * 20) == 0;
        for (Entity e : DrainRules.marcados()) {
            if (!(e instanceof Mob m)) continue;
            if (comer && !comidas.isEmpty()) comer(m, comidas.get(m.getRandom().nextInt(comidas.size())));
            if (!armas.isEmpty() && m instanceof Zombie) {
                Item a = item(armas.get(m.getRandom().nextInt(armas.size())));
                if (!armas.contains(id(m.getMainHandItem()))) m.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(a));
            }
        }
    }

    private static void eff(LivingEntity m, net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect> e, int seg, int amp) {
        m.addEffect(new MobEffectInstance(e, seg * 20, amp));
    }

    /** Aplica al mob los efectos de la receta que "come". */
    private static void comer(Mob m, String receta) {
        switch (receta) {
            case "arepa_basica" -> m.heal(4);
            case "cachapa_veloz", "cafe_de_los_andes" -> eff(m, MobEffects.SPEED, 30, 0);
            case "tequeno_de_absorcion" -> eff(m, MobEffects.ABSORPTION, 30, 1);
            case "pabellon_criollo" -> { eff(m, MobEffects.STRENGTH, 30, 0); eff(m, MobEffects.RESISTANCE, 30, 0); }
            case "pabellon_supremo", "pabellon_del_mas_alla" -> { eff(m, MobEffects.STRENGTH, 30, 1); eff(m, MobEffects.RESISTANCE, 30, 1); }
            case "hallaca_legendaria", "hallaca_eterna" -> { eff(m, MobEffects.REGENERATION, 20, 1); eff(m, MobEffects.RESISTANCE, 20, 0); }
            case "banquete_criollo", "banquete_del_segundo_hilo" -> { eff(m, MobEffects.REGENERATION, 20, 0); eff(m, MobEffects.STRENGTH, 20, 0); }
            case "arepa_de_la_resistencia", "arepa_espectral" -> eff(m, MobEffects.RESISTANCE, 30, 0);
            case "plato_del_segundo_hilo", "tizana_de_los_andes" -> m.heal(10);
            default -> eff(m, MobEffects.SPEED, 20, 0);
        }
        if (m.level() instanceof ServerLevel sl) sl.sendParticles(ParticleTypes.HAPPY_VILLAGER, m.getX(), m.getY() + m.getBbHeight(), m.getZ(), 6, 0.3, 0.3, 0.3, 0.0);
    }
}