package com.svz.posesion.logic;

import com.svz.posesion.SVZPosesionMod;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

import java.util.Map;

/** Mensajes configurables (config/svz-posesion.json). */
public final class Msg {
    private Msg() {}

    public static Component texto(String clave, Map<String, String> vars) {
        return Component.literal(SVZPosesionMod.CONFIG.msg(clave, vars));
    }

    public static void enviar(ServerPlayer p, String clave, Map<String, String> vars, boolean actionBar) {
        p.displayClientMessage(texto(clave, vars), actionBar);
    }

    public static void enviar(ServerPlayer p, String clave, boolean actionBar) {
        enviar(p, clave, Map.of(), actionBar);
    }

    /** Sustituye {mob} por un componente (el nombre traducible de la entidad). */
    public static Component conMob(String clave, Component mob) {
        String s = SVZPosesionMod.CONFIG.msg(clave, Map.of());
        int i = s.indexOf("{mob}");
        if (i < 0) return Component.literal(s);
        return Component.literal(s.substring(0, i)).append(mob).append(Component.literal(s.substring(i + 5)));
    }
}
