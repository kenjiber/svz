package com.svz.posesion.logic;

import com.svz.core.api.SVZClass;
import com.svz.core.api.SVZCoreAPI;
import com.svz.mobs.entity.boss.SVZBoss;
import com.svz.posesion.SVZPosesionMod;
import com.svz.posesion.data.PosesionPlayer;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import static com.svz.posesion.logic.SaberRobado.item;

/**
 * Rituales de liberación. Clic derecho sobre el objetivo con la ofrenda de tu clase:
 * Chef = Arepa de la Resistencia · Herrero = Nudo Rojo · Guerrero = Núcleo de Hilo.
 * - Ritual menor (jugador Marcado/Tejido): cada clase ofrece {@code ritualMenor} (1).
 * - Ritual de Rescate Mayor (cuerpo Títere Jugador de un jugador poseído): cada clase ofrece {@code ritualMayor} (8).
 */
public final class RitualRescate {
    private RitualRescate() {}

    private static final Map<UUID, int[]> PROGRESO = new HashMap<>();
    private static final String[] OFRENDA = {"arepa_de_la_resistencia", "nudo_rojo", "nucleo_de_hilo"};
    private static final String[] NOMBRE = {"Arepa de la Resistencia", "Nudo Rojo", "Núcleo de Hilo"};

    public static void register() {
        UseEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (!(world instanceof ServerLevel level) || !(player instanceof ServerPlayer sp)) return InteractionResult.PASS;
            MinecraftServer server = level.getServer();

            UUID duenio = null;
            int requerido = SVZPosesionMod.CONFIG.ritualMenor;
            if (entity instanceof ServerPlayer tp && tp != sp) {
                int f = PosesionPlayer.get(tp).fase;
                if (f == 1 || f == 2) duenio = tp.getUUID();
            } else if (entity instanceof SVZBoss) {
                for (String t : entity.getTags()) {
                    if (t.startsWith(PlayerPhases.TAG_CUERPO)) duenio = UUID.fromString(t.substring(PlayerPhases.TAG_CUERPO.length()));
                }
                requerido = SVZPosesionMod.CONFIG.ritualMayor;
            }
            if (duenio == null) return InteractionResult.PASS;

            ItemStack st = sp.getItemInHand(hand);
            SVZClass clase = SVZCoreAPI.getClase(sp);
            int idx = switch (clase) {
                case CHEF -> 0;
                case HERRERO -> 1;
                case GUERRERO -> 2;
                default -> -1;
            };
            if (idx < 0) {
                sp.displayClientMessage(Component.literal("Solo un Chef, un Herrero y un Guerrero juntos pueden liberar este hilo."), true);
                return InteractionResult.SUCCESS;
            }
            if (st.is(item("hilo_de_liberacion"))) {
                sp.displayClientMessage(Component.literal("Un hilo suelto no basta: hace falta el ritual de Chef, Herrero y Guerrero."), true);
                return InteractionResult.SUCCESS;
            }
            if (!st.is(item(OFRENDA[idx]))) {
                sp.displayClientMessage(Component.literal("Como " + clase.getSerializedName() + " debes ofrecer " + requerido + " × " + NOMBRE[idx] + "."), true);
                return InteractionResult.SUCCESS;
            }
            int[] prog = PROGRESO.computeIfAbsent(entity.getUUID(), k -> new int[3]);
            int falta = requerido - prog[idx];
            if (falta <= 0) {
                sp.displayClientMessage(Component.literal("Tu parte del ritual ya está completa."), true);
                return InteractionResult.SUCCESS;
            }
            ServerPlayer objetivo = server.getPlayerList().getPlayer(duenio);
            if (objetivo == null) {
                sp.displayClientMessage(Component.literal("Su alma no responde: el jugador está desconectado."), true);
                return InteractionResult.SUCCESS;
            }
            int n = Math.min(st.getCount(), falta);
            if (!sp.getAbilities().instabuild) st.shrink(n);
            prog[idx] += n;
            Map<String, String> v = Map.of("chef", "" + prog[0], "herrero", "" + prog[1], "guerrero", "" + prog[2],
                    "n", "" + requerido, "jugador", objetivo.getName().getString());
            for (ServerPlayer o : level.getEntitiesOfClass(ServerPlayer.class, entity.getBoundingBox().inflate(16))) Msg.enviar(o, "ritual_progreso", v, false);
            if (prog[0] >= requerido && prog[1] >= requerido && prog[2] >= requerido) {
                PROGRESO.remove(entity.getUUID());
                for (ServerPlayer o : level.getEntitiesOfClass(ServerPlayer.class, entity.getBoundingBox().inflate(16))) Msg.enviar(o, "ritual_ok", v, false);
                PlayerPhases.liberar(server, objetivo);
            }
            return InteractionResult.SUCCESS;
        });
    }
}
