package com.svz.posesion.logic;

import com.svz.mobs.api.SVZMobsAPI;
import com.svz.mobs.entity.ModEntities;
import com.svz.mobs.entity.SVZMobMarker;
import com.svz.mobs.entity.SVZPossessed;
import com.svz.posesion.SVZPosesionMod;
import com.svz.posesion.data.PosesionWorld;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.core.particles.ParticleTypes;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Posesión diaria: cada amanecer La Mano Roja elige a un mob (más si hay poseídos sin liberar, máx. 5 en total),
 * lo convierte en su variante poseída, lo anuncia en el chat y deja un rastro de partículas rojas.
 * Un "día" son 24000 ticks de juego.
 */
public final class DailyPossession {
    private DailyPossession() {}

    private static final Map<EntityType<?>, String> TIPOS = Map.of(
            EntityType.COW, "vaca_poseida", EntityType.PIG, "cerdo_poseido", EntityType.SHEEP, "oveja_poseida",
            EntityType.VILLAGER, "aldeano_poseido", EntityType.WOLF, "lobo_poseido", EntityType.CREEPER, "creeper_poseido",
            EntityType.IRON_GOLEM, "golem_poseido", EntityType.PIGLIN, "piglin_poseido", EntityType.WARDEN, "warden_poseido");

    private static final String[] PLAN_B = {"vaca_poseida", "cerdo_poseido", "oveja_poseida", "aldeano_poseido", "lobo_poseido", "creeper_poseido"};

    /** Llamado cada segundo. */
    public static void tick(MinecraftServer server) {
        PosesionWorld w = PosesionWorld.get(server);
        long dia = PlayerPhases.dia(server);
        if (w.ultimoDia < 0) {
            w.ultimoDia = dia;
            return;
        }
        // rastro visible de los poseídos
        rastro(server);
        if (dia == w.ultimoDia) return;
        w.ultimoDia = dia;
        amanecer(server);
    }

    private static void rastro(MinecraftServer server) {
        if (server.getTickCount() % 100 != 0) return; // cada 5 s una pasada rápida; el movimiento deja la línea
        for (Entity e : DrainRules.marcados()) {
            if (e instanceof SVZPossessed && e.level() instanceof ServerLevel sl) {
                sl.sendParticles(DrainRules.ROJO, e.getX(), e.getY() + 0.2, e.getZ(), 6, 0.25, 0.05, 0.25, 0.0);
                sl.sendParticles(ParticleTypes.CRIMSON_SPORE, e.getX(), e.getY() + 0.3, e.getZ(), 3, 0.3, 0.1, 0.3, 0.0);
            }
        }
    }

    private static void amanecer(MinecraftServer server) {
        ServerLevel ow = server.overworld();
        // los consumidos por plazo
        for (ServerPlayer p : server.getPlayerList().getPlayers()) PlayerPhases.comprobarConsumido(server, p);

        int vivos = 0;
        for (Entity e : ow.getAllEntities()) if (e instanceof SVZPossessed) vivos++;
        int max = SVZPosesionMod.CONFIG.maxAcumulados;
        int cantidad = 1 + vivos / 2; // acumulación: más poseídos sin liberar -> más elegidos
        cantidad = Math.min(cantidad, max - vivos);
        if (cantidad <= 0) return; // máximo acumulado

        List<ServerPlayer> jugadores = new ArrayList<>(ow.players());
        jugadores.removeIf(p -> p.isSpectator());
        if (jugadores.isEmpty()) return;

        for (int i = 0; i < cantidad; i++) {
            ServerPlayer ancla = jugadores.get(ow.random.nextInt(jugadores.size()));
            Mob elegido = candidato(ow, ancla);
            String id;
            Mob poseido;
            if (elegido != null) {
                id = TIPOS.get(elegido.getType());
                poseido = SVZMobsAPI.spawn(ow, id, elegido.getX(), elegido.getY(), elegido.getZ());
                if (poseido != null) {
                    poseido.setYRot(elegido.getYRot());
                    elegido.discard();
                }
            } else { // no hay mobs cerca: aparece uno nuevo
                id = PLAN_B[ow.random.nextInt(PLAN_B.length)];
                double a = ow.random.nextDouble() * Math.PI * 2, d = 24 + ow.random.nextDouble() * 16;
                BlockPos s = ow.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                        new BlockPos((int) (ancla.getX() + Math.cos(a) * d), 0, (int) (ancla.getZ() + Math.sin(a) * d)));
                poseido = SVZMobsAPI.spawn(ow, id, s.getX() + 0.5, s.getY(), s.getZ() + 0.5);
            }
            if (poseido != null) {
                Component nombre = ModEntities.ALL.get(id).getDescription();
                server.getPlayerList().broadcastSystemMessage(Msg.conMob("elegido", nombre), false);
            }
        }
    }

    /** Un mob vanilla de los 9 tipos poseíbles, cerca de un jugador, sin nombre ni domesticado. */
    private static Mob candidato(ServerLevel ow, ServerPlayer p) {
        List<Mob> lista = ow.getEntitiesOfClass(Mob.class, p.getBoundingBox().inflate(96), m ->
                TIPOS.containsKey(m.getType()) && !(m instanceof SVZMobMarker) && !m.hasCustomName()
                        && !(m instanceof TamableAnimal t && t.isTame()));
        return lista.isEmpty() ? null : lista.get(ow.random.nextInt(lista.size()));
    }
}
