package com.svz.posesion.command;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.svz.posesion.data.PosesionPlayer;
import com.svz.posesion.logic.PlayerPhases;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

import java.util.function.Predicate;

/**
 * /svz poseer <jugador> · /svz liberar <jugador> · /svz fase <jugador> <0-4> (admin).
 * Se registran bajo el mismo /svz de SVZ-Core: Brigadier fusiona los nodos y estos reemplazan a "poseer" de Core.
 */
public final class PosesionCommands {
    private PosesionCommands() {}

    // NOTA 1.21.11: igual que en SVZ-Core, esta línea depende del sistema de permisos.
    private static final Predicate<CommandSourceStack> ADMIN = Commands.hasPermission(Commands.LEVEL_GAMEMASTERS);

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(Commands.literal("svz")
                        .then(Commands.literal("poseer").requires(ADMIN)
                                .then(Commands.argument("jugador", EntityArgument.player()).executes(ctx -> {
                                    ServerPlayer p = EntityArgument.getPlayer(ctx, "jugador");
                                    PlayerPhases.setFase(ctx.getSource().getServer(), p, 3);
                                    ctx.getSource().sendSuccess(() -> Component.literal(p.getName().getString() + " ha sido poseído (fase 3)."), true);
                                    return 1;
                                })))
                        .then(Commands.literal("liberar").requires(ADMIN)
                                .then(Commands.argument("jugador", EntityArgument.player()).executes(ctx -> {
                                    ServerPlayer p = EntityArgument.getPlayer(ctx, "jugador");
                                    PlayerPhases.liberar(ctx.getSource().getServer(), p);
                                    ctx.getSource().sendSuccess(() -> Component.literal(p.getName().getString() + " ha sido liberado."), true);
                                    return 1;
                                })))
                        .then(Commands.literal("fase").requires(ADMIN)
                                .then(Commands.argument("jugador", EntityArgument.player())
                                        .executes(ctx -> {
                                            ServerPlayer p = EntityArgument.getPlayer(ctx, "jugador");
                                            int f = PosesionPlayer.get(p).fase;
                                            ctx.getSource().sendSuccess(() -> Component.literal(p.getName().getString() + ": fase " + f + " (" + PlayerPhases.NOMBRES[f] + ")"), false);
                                            return f;
                                        })
                                        .then(Commands.argument("fase", IntegerArgumentType.integer(0, 4)).executes(ctx -> {
                                            ServerPlayer p = EntityArgument.getPlayer(ctx, "jugador");
                                            int f = IntegerArgumentType.getInteger(ctx, "fase");
                                            PlayerPhases.setFase(ctx.getSource().getServer(), p, f);
                                            ctx.getSource().sendSuccess(() -> Component.literal(p.getName().getString() + " -> fase " + f + " (" + PlayerPhases.NOMBRES[f] + ")"), true);
                                            return f;
                                        }))))));
    }
}
