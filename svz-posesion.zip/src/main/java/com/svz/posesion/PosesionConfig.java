package com.svz.posesion;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** config/svz-posesion.json: reglas y mensajes de chat configurables ({mob}, {jugador}, {fase}, {chef}, {herrero}, {guerrero}, {n}). */
public class PosesionConfig {
    public int maxAcumulados = 5;
    /** % de hilos por debajo del cual un drenaje deja al jugador Marcado / Tejido. */
    public int umbralMarcadoPct = 50;
    public int umbralTejidoPct = 25;
    public int hitsMobMin = 3, hitsMobMax = 5;
    public int hitsJugadorPoseido = 2;
    public int drenajeEspectroPorGolpe = 1;
    /** Ofrendas por clase: ritual menor (fases 1-2) y Ritual de Rescate Mayor (cuerpo del Títere Jugador). */
    public int ritualMenor = 1, ritualMayor = 8;
    /** Días de juego como poseído (fase 3) antes de quedar Consumido. */
    public int diasConsumido = 3;
    public int segundosHiloNegro = 30, radioHiloNegro = 8, drenajeHiloNegro = 2;
    public boolean defensaGuerrero = true, defensaHerrero = true, defensaChef = true;
    public int segundosComerMobs = 30;
    public Map<String, String> mensajes = new LinkedHashMap<>();
    public List<String> susurros = List.of("...tu hilo se afloja...", "...ven... déjame tejerte...", "...ya casi eres mío...",
            "...la Mano Roja te nombra...", "...no te resistas al nudo...");

    public PosesionConfig() {
        mensajes.put("elegido", "§4La Mano Roja ha elegido a su títere de hoy: §c{mob}§4.");
        mensajes.put("fase1", "§7Una marca roja aparece en tu hilo. Estás §cMarcado§7.");
        mensajes.put("fase2", "§7Los hilos te recorren la piel. Estás §cTejido§7.");
        mensajes.put("fase3", "§4Has perdido el control. La Mano Roja mueve tu cuerpo. Estás §cPoseído§4.");
        mensajes.put("fase4", "§8Tu hilo se ha consumido por completo.");
        mensajes.put("liberado", "§aTu hilo se ha liberado. Vuelves a ser tú.");
        mensajes.put("ritual_progreso", "§6Ritual: §fChef {chef}/{n} §7· §fHerrero {herrero}/{n} §7· §fGuerrero {guerrero}/{n}");
        mensajes.put("ritual_ok", "§aEl ritual está completo: {jugador} queda libre.");
        mensajes.put("bloqueo", "§bTu habilidad de clase bloquea el drenaje.");
        mensajes.put("sorpresa", "§cUn ataque a traición te arranca un hilo mientras dormías.");
        mensajes.put("purificacion", "§aLa corrupción del saber robado retrocede un día.");
    }

    public String msg(String clave, Map<String, String> vars) {
        String s = mensajes.getOrDefault(clave, clave);
        for (var e : vars.entrySet()) s = s.replace("{" + e.getKey() + "}", e.getValue());
        return s;
    }

    public static PosesionConfig load() {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        Path file = FabricLoader.getInstance().getConfigDir().resolve("svz-posesion.json");
        try {
            if (Files.exists(file)) {
                PosesionConfig c = gson.fromJson(Files.readString(file), PosesionConfig.class);
                if (c != null) {
                    PosesionConfig def = new PosesionConfig();
                    def.mensajes.forEach(c.mensajes::putIfAbsent); // añade claves nuevas sin pisar las tuyas
                    return c;
                }
            }
            PosesionConfig def = new PosesionConfig();
            Files.writeString(file, gson.toJson(def));
            return def;
        } catch (Exception e) {
            SVZPosesionMod.LOGGER.warn("No se pudo leer svz-posesion.json, usando valores por defecto", e);
            return new PosesionConfig();
        }
    }
}
