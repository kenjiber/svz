# SVZ-Posesion (svz-posesion)
Sistema de posesión de Sobreviviendo a Venezuela. MC 1.21.11 · Fabric · Java 21.
Requiere SVZ-Core, SVZ-Items y SVZ-Mobs (usa los zips actualizados: este mod necesita pequeños parches en los tres).

## Compilar
1. Compila SVZ-Core, SVZ-Items y SVZ-Mobs y copia sus jars a `libs/`.
2. Añade `gradlew`, `gradlew.bat` y `gradle/` de la plantilla de Fabric y ejecuta `./gradlew build`.

## Qué gobierna
Al iniciar desactiva las versiones simples de los otros mods: posesión diaria de Mobs, Títere Jugador de Mobs,
drenaje por golpes de Mobs y drenaje de jugadores poseídos de Core. Todo eso lo hace ahora este mod.

## Configuración
`config/svz-posesion.json`: golpes por drenaje, umbrales de fase, ofrendas del ritual, días hasta Consumido,
defensas de clase, Hilo Negro y todos los mensajes del chat.

## Comandos de admin
`/svz poseer <jugador>` · `/svz liberar <jugador>` · `/svz fase <jugador> [0-4]` (sin número muestra la fase).
