package com.svz.telar.npc;

import com.svz.telar.ModItems;
import com.svz.telar.logic.TelarUtil;
import com.svz.telar.worldgen.TelarTerrain;
import com.svz.telar.worldgen.TelarZones;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.npc.WanderingTrader;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.trading.ItemCost;
import net.minecraft.world.item.trading.MerchantOffer;
import net.minecraft.world.item.trading.MerchantOffers;
import net.minecraft.world.phys.AABB;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** El Tejedor: comerciante fijo del Umbral con trueques de recursos del Telar y diálogos de lore. */
public final class Tejedor {
    private Tejedor() {}

    public static final String TAG = "svz_tejedor";

    private static final String[] LORE = {
            "Otro hilo que llega al telar... Hacía tiempo que nadie cruzaba con la vela encendida.",
            "Fui tejedor antes de que el hilo se rompiera. Ahora remiendo lo que el Telar suelta.",
            "Cinco tramos tiene el Telar: el Umbral, el Laberinto de Nudos, la Arena de Títeres, el Río de Ceniza y el Juicio.",
            "El Maíz Olvidado solo lo muele un Chef. El Metal Olvidado solo lo dobla un Herrero. No lo intentes de otro modo.",
            "Quien muere aquí no vuelve: su hilo se corta para siempre... salvo que alguien termine el Juicio por él.",
            "Los Espectros Títeres fueron jugadores. Procura no reconocer sus caras.",
            "El Primer Títere espera tras el Río de Ceniza. Dicen que fue el primero en perder su hilo, y aún lo busca.",
            "Cuando llegue el Juicio, decide con cuidado: liberar, reclamar o cortar. Cada hilo tiene su precio."
    };

    private static final Map<UUID, Integer> DIALOGO = new HashMap<>();

    public static void register() {
        UseEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (!(world instanceof ServerLevel) || !(player instanceof ServerPlayer sp)) return InteractionResult.PASS;
            if (!entity.getTags().contains(TAG)) return InteractionResult.PASS;
            if (sp.isShiftKeyDown()) {
                int i = DIALOGO.merge(sp.getUUID(), 1, (a, b) -> (a + 1) % LORE.length);
                i = (i - 1 + LORE.length) % LORE.length;
                sp.displayClientMessage(Component.literal("El Tejedor: \"" + LORE[i] + "\""), false);
                return InteractionResult.SUCCESS;
            }
            sp.displayClientMessage(Component.literal("Agáchate y haz clic para escuchar al Tejedor."), true);
            return InteractionResult.PASS; // se abre el comercio vanilla
        });
    }

    /** Se asegura de que El Tejedor exista en el Umbral. */
    public static void asegurar(ServerLevel telar) {
        double x = TelarZones.TEJEDOR_X + 0.5, z = TelarZones.TEJEDOR_Z + 0.5;
        AABB zona = new AABB(x - 40, 0, z - 40, x + 40, 255, z + 40);
        if (!telar.getEntitiesOfClass(WanderingTrader.class, zona, e -> e.getTags().contains(TAG)).isEmpty()) return;
        WanderingTrader t = EntityType.WANDERING_TRADER.create(telar, EntitySpawnReason.EVENT);
        if (t == null) return;
        t.setPos(x, TelarTerrain.alturaUmbral(TelarZones.TEJEDOR_X, TelarZones.TEJEDOR_Z) + 1, z);
        t.addTag(TAG);
        t.setNoAi(true);
        t.setInvulnerable(true);
        t.setPersistenceRequired();
        t.setDespawnDelay(Integer.MAX_VALUE);
        t.setCustomName(Component.literal("El Tejedor"));
        t.setCustomNameVisible(true);
        ofertas(t);
        telar.addFreshEntity(t);
    }

    private static MerchantOffer trueque(Item paga, int cantidad, ItemStack resultado) {
        return new MerchantOffer(new ItemCost(paga, cantidad), resultado, 9999, 0, 0.0F);
    }

    private static void ofertas(WanderingTrader t) {
        MerchantOffers o = t.getOffers();
        o.clear(); // descarta los tratos aleatorios vanilla
        Item nudo = TelarUtil.item("nudo_de_alma");
        o.add(trueque(nudo, 3, new ItemStack(TelarUtil.item("maiz_olvidado"))));
        o.add(trueque(TelarUtil.item("hilo_espectral"), 5, new ItemStack(TelarUtil.item("metal_olvidado"))));
        o.add(trueque(nudo, 5, new ItemStack(ModItems.HILO_DEL_ALMA)));
        o.add(trueque(nudo, 10, new ItemStack(TelarUtil.item("hilo_de_vida"))));
    }
}
