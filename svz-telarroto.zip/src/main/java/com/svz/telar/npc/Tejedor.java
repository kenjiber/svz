package com.svz.telar.npc;

import com.svz.telar.ModItems;
import com.svz.telar.logic.TelarUtil;
import com.svz.telar.worldgen.TelarTerrain;
import com.svz.telar.worldgen.TelarZones;

import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.trading.ItemCost;
import net.minecraft.world.item.trading.Merchant;
import net.minecraft.world.item.trading.MerchantOffer;
import net.minecraft.world.item.trading.MerchantOffers;
import net.minecraft.world.phys.AABB;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * El Tejedor: comerciante fijo del Umbral.
 * Incluye trueques de recursos del Telar y diálogos de historia.
 */
public final class Tejedor {

    private Tejedor() {
    }

    public static final String TAG = "svz_tejedor";

    private static final String[] LORE = {
            "Otro hilo que llega al telar... Hacía tiempo que nadie cruzaba con la vela encendida.",
            "Fui tejedor antes de que el hilo se rompiera. Ahora remiendo lo que el Telar suelta.",
            "Cinco tramos tiene el Telar: el Umbral, el Laberinto de Nudos, la Arena de Títeres, el Río de Ceniza y el Juicio.",
            "El Maíz Olvidado solo lo muele un Chef. El Metal Olvidado solo lo dobla un Herrero. No lo intentes de otro modo.",
            "Quien muere aquí no vuelve: su hilo se corta para siempre... salvo que alguien termine el Juicio por él.",
            "Los Espectros Títeres fueron jugadores. Procura no reconocer sus caras.",
            "El Primer Títere espera tras el Río de Ceniza. Dicen que fue el primero en perder su hilo, y aún lo busca.",
            "Cuando llegue el Juicio, decide con cuidado: liberar, reclamar o cortar. Cada hilo tiene su precio."
    };

    private static final Map<UUID, Integer> DIALOGO = new HashMap<>();

    public static void register() {
        UseEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {

            if (!(world instanceof ServerLevel)) {
                return InteractionResult.PASS;
            }

            if (!(player instanceof ServerPlayer sp)) {
                return InteractionResult.PASS;
            }

            if (!entity.getTags().contains(TAG)) {
                return InteractionResult.PASS;
            }

            // Agacharse y hacer clic permite escuchar el siguiente diálogo.
            if (sp.isShiftKeyDown()) {
                int indice = DIALOGO.getOrDefault(sp.getUUID(), -1);
                indice = (indice + 1) % LORE.length;

                DIALOGO.put(sp.getUUID(), indice);

                sp.displayClientMessage(
                        Component.literal("El Tejedor: \"" + LORE[indice] + "\""),
                        false
                );

                return InteractionResult.SUCCESS;
            }

            sp.displayClientMessage(
                    Component.literal("Agáchate y haz clic para escuchar al Tejedor."),
                    true
            );

            // Sin agacharse, permite que el comerciante abra el menú vanilla.
            return InteractionResult.PASS;
        });
    }

    /**
     * Garantiza que exista un solo Tejedor en el Umbral.
     */
    public static void asegurar(ServerLevel telar) {
        double x = TelarZones.TEJEDOR_X + 0.5;
        double z = TelarZones.TEJEDOR_Z + 0.5;

        AABB zona = new AABB(
                x - 40, telar.getMinY(), z - 40,
                x + 40, telar.getMaxY(), z + 40
        );

        boolean existe = !telar.getEntitiesOfClass(
                Entity.class,
                zona,
                entidad -> entidad.getType() == EntityType.WANDERING_TRADER
                        && entidad.getTags().contains(TAG)
        ).isEmpty();

        if (existe) {
            return;
        }

        Entity tejedor = EntityType.WANDERING_TRADER.create(
                telar,
                EntitySpawnReason.EVENT
        );

        if (tejedor == null) {
            return;
        }

        int y = TelarTerrain.alturaUmbral(
                TelarZones.TEJEDOR_X,
                TelarZones.TEJEDOR_Z
        ) + 1;

        tejedor.setPos(x, y, z);
        tejedor.addTag(TAG);
        if (tejedor instanceof Mob mob) {
            mob.setNoAi(true);
            mob.setPersistenceRequired();
        }

        tejedor.setInvulnerable(true);
        tejedor.setCustomName(Component.literal("El Tejedor"));
        tejedor.setCustomNameVisible(true);

        if (tejedor instanceof Merchant merchant) {
            ofertas(merchant);
        }

        telar.addFreshEntity(tejedor);
    }

    private static MerchantOffer trueque(
            Item paga,
            int cantidad,
            ItemStack resultado
    ) {
        return new MerchantOffer(
                new ItemCost(paga, cantidad),
                resultado,
                9999,
                0,
                0.0F
        );
    }

    /**
     * Reemplaza los trueques aleatorios por los trueques del Telar.
     */
    private static void ofertas(Merchant tejedor) {
        MerchantOffers ofertas = tejedor.getOffers();

        ofertas.clear();

        Item nudoAlma = TelarUtil.item("nudo_de_alma");
        Item hiloEspectral = TelarUtil.item("hilo_espectral");
        Item maizOlvidado = TelarUtil.item("maiz_olvidado");
        Item metalOlvidado = TelarUtil.item("metal_olvidado");
        Item hiloVida = TelarUtil.item("hilo_de_vida");

        ofertas.add(
                trueque(
                        nudoAlma,
                        3,
                        new ItemStack(maizOlvidado)
                )
        );

        ofertas.add(
                trueque(
                        hiloEspectral,
                        5,
                        new ItemStack(metalOlvidado)
                )
        );

        ofertas.add(
                trueque(
                        nudoAlma,
                        5,
                        new ItemStack(ModItems.HILO_DEL_ALMA)
                )
        );

        ofertas.add(
                trueque(
                        nudoAlma,
                        10,
                        new ItemStack(hiloVida)
                )
        );
    }
}