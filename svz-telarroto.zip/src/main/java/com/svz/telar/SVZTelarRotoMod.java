package com.svz.telar;

import com.svz.core.api.SVZCoreAPI;
import com.svz.telar.command.TelarCommands;
import com.svz.telar.logic.TelarEvents;
import com.svz.telar.npc.Tejedor;
import com.svz.telar.portal.PortalManager;
import com.svz.telar.rescue.RescueManager;
import com.svz.telar.rescue.TelarData;
import com.svz.telar.worldgen.TelarChunkGenerator;
import net.fabricmc.api.ModInitializer;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SVZTelarRotoMod implements ModInitializer {
    public static final String MOD_ID = "svz-telarroto";
    public static final Logger LOGGER = LoggerFactory.getLogger("SVZ-TelarRoto");

    /** Si es {@code true}, el jugador que muere en el Telar Roto es expulsado además de marcado como muerto permanente. */
    public static final boolean EXPULSAR_AL_MORIR = false;

    public static final ResourceKey<Level> TELAR_ROTO =
            ResourceKey.create(Registries.DIMENSION, Identifier.fromNamespaceAndPath(MOD_ID, "telar_roto"));

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModBlocks.register();
        ModItems.register();
        Registry.register(BuiltInRegistries.CHUNK_GENERATOR, id("telar"), TelarChunkGenerator.CODEC);
        SVZCoreAPI.setTelarRotoDimension(TELAR_ROTO);   // Core, Items y Mobs ya usan esta dimensión
        TelarData.register();
        TelarEvents.register();
        PortalManager.register();
        Tejedor.register();
        RescueManager.register();
        TelarCommands.register();
        LOGGER.info("SVZ-TelarRoto cargado.");
    }
}
