package com.svz.telar;

import com.svz.core.api.SVZCoreAPI;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.ChatFormatting;
import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.level.Level;

import java.util.List;

/** Ítems propios del Telar Roto: el Hilo del Alma (+1 hilo, se consigue con El Tejedor). */
public final class ModItems {
    private ModItems() {}

    public static Item HILO_DEL_ALMA;

    public static class HiloDelAlmaItem extends Item {
        public HiloDelAlmaItem(Properties props) {
            super(props);
        }

        @Override
        public InteractionResult use(Level level, Player player, InteractionHand hand) {
            if (!(level instanceof ServerLevel) || !(player instanceof ServerPlayer sp)) return InteractionResult.SUCCESS;
            if (SVZCoreAPI.getHilos(sp) >= SVZCoreAPI.getMaxHilos(sp)) {
                sp.displayClientMessage(Component.literal("Ya tienes todos tus hilos del alma."), true);
                return InteractionResult.FAIL;
            }
            SVZCoreAPI.addHilos(sp, 1);
            if (!sp.getAbilities().instabuild) player.getItemInHand(hand).shrink(1);
            sp.displayClientMessage(Component.literal("Recuperas un hilo del alma."), true);
            return InteractionResult.SUCCESS;
        }
    }

    public static void register() {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, SVZTelarRotoMod.id("hilo_del_alma"));
        Item.Properties props = new Item.Properties().setId(key)
                .component(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, true)
                .component(DataComponents.LORE, new ItemLore(List.of(
                        Component.translatable("item." + SVZTelarRotoMod.MOD_ID + ".hilo_del_alma.tooltip")
                                .withStyle(s -> s.withColor(ChatFormatting.GRAY).withItalic(false)))));
        HILO_DEL_ALMA = Registry.register(BuiltInRegistries.ITEM, key, new HiloDelAlmaItem(props));

        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.FUNCTIONAL_BLOCKS).register(e -> {
            e.accept(ModBlocks.ALTAR_ITEM);
            e.accept(ModBlocks.VETA_ITEM);
        });
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.INGREDIENTS).register(e -> e.accept(HILO_DEL_ALMA));
    }
}
