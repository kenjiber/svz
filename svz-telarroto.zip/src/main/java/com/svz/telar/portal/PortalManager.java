package com.svz.telar.portal;

import com.svz.core.api.SVZCoreAPI;
import com.svz.telar.ModBlocks;
import com.svz.telar.logic.TelarUtil;
import com.svz.telar.worldgen.TelarTerrain;
import com.svz.telar.worldgen.TelarZones;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Relative;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Portal del Altar del Tejedor. Se abre encendiendo una Vela de Ánima sobre el altar, dura 10 minutos
 * y teletransporta sin riesgo: del Overworld al Umbral y, desde el altar del Umbral, de vuelta.
 * (Implementación propia en lugar de Custom Portal API: ver README.)
 */
public final class PortalManager {
    private PortalManager() {}

    public static final int DURACION_TICKS = 12000; // 10 minutos

    private record Portal(ResourceKey<Level> dim, BlockPos altar, int expira) {}

    private static final List<Portal> ACTIVOS = new ArrayList<>();
    private static final Map<UUID, BlockPos> ORIGEN = new HashMap<>();
    private static final Map<UUID, Integer> ENFRIAR = new HashMap<>();

    public static void register() {
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (!(world instanceof ServerLevel level) || !(player instanceof ServerPlayer sp)) return InteractionResult.PASS;
            if (hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
            BlockPos pos = hit.getBlockPos();
            if (!level.getBlockState(pos).is(ModBlocks.ALTAR)) return InteractionResult.PASS;
            ItemStack vela = ItemStack.EMPTY;
            for (InteractionHand h : InteractionHand.values()) {
                ItemStack st = sp.getItemInHand(h);
                if (st.is(TelarUtil.item("vela_de_anima"))) vela = st;
            }
            if (vela.isEmpty()) {
                sp.displayClientMessage(Component.literal("El Altar del Tejedor espera una Vela de Ánima."), true);
                return InteractionResult.SUCCESS;
            }
            if (TelarUtil.telar(level.getServer()) == null) {
                sp.displayClientMessage(Component.literal("El Telar Roto aún no existe en este mundo."), true);
                return InteractionResult.SUCCESS;
            }
            if (!sp.getAbilities().instabuild) vela.shrink(1);
            abrir(level, pos);
            return InteractionResult.SUCCESS;
        });
    }

    private static void abrir(ServerLevel level, BlockPos altar) {
        int t = level.getServer().getTickCount();
        ACTIVOS.removeIf(p -> p.altar().equals(altar) && p.dim().equals(level.dimension()));
        ACTIVOS.add(new Portal(level.dimension(), altar.immutable(), t + DURACION_TICKS));
        level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, altar.getX() + 0.5, altar.getY() + 1.5, altar.getZ() + 0.5, 60, 0.6, 1.0, 0.6, 0.05);
        for (ServerPlayer p : level.getEntitiesOfClass(ServerPlayer.class, new AABB(altar).inflate(24))) {
            p.displayClientMessage(Component.literal("El portal del Telar Roto se abre durante 10 minutos."), false);
        }
    }

    // ------------------------------------------------------------ tick
    public static void tick(MinecraftServer server) {
        int t = server.getTickCount();
        Iterator<Portal> it = ACTIVOS.iterator();
        while (it.hasNext()) {
            Portal portal = it.next();
            ServerLevel level = server.getLevel(portal.dim());
            if (level == null) {
                it.remove();
                continue;
            }
            BlockPos a = portal.altar();
            if (t > portal.expira() || !level.getBlockState(a).is(ModBlocks.ALTAR)) {
                level.sendParticles(ParticleTypes.SMOKE, a.getX() + 0.5, a.getY() + 1.5, a.getZ() + 0.5, 30, 0.5, 0.8, 0.5, 0.02);
                it.remove();
                continue;
            }
            if (t % 3 == 0) {
                level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, a.getX() + 0.5, a.getY() + 2.0, a.getZ() + 0.5, 6, 0.5, 1.0, 0.5, 0.02);
                level.sendParticles(ParticleTypes.PORTAL, a.getX() + 0.5, a.getY() + 2.0, a.getZ() + 0.5, 10, 0.6, 1.0, 0.6, 0.3);
            }
            if (t % 5 == 0) {
                AABB zona = new AABB(a.getX() - 0.5, a.getY() + 1, a.getZ() - 0.5, a.getX() + 1.5, a.getY() + 3.5, a.getZ() + 1.5);
                for (ServerPlayer p : level.getEntitiesOfClass(ServerPlayer.class, zona)) viajar(server, p, portal);
            }
        }
    }

    // ------------------------------------------------------------ viaje
    private static void viajar(MinecraftServer server, ServerPlayer p, Portal portal) {
        if (p.isSpectator() || SVZCoreAPI.isMuertePermanente(p)) return;
        int t = server.getTickCount();
        if (ENFRIAR.getOrDefault(p.getUUID(), 0) > t) return;
        ENFRIAR.put(p.getUUID(), t + 100);
        if (SVZCoreAPI.isTelarRoto(portal.dim())) regresar(server, p);
        else entrar(server, p, portal.altar());
    }

    /** Entrada al Telar Roto: llega al Umbral sin morir y recibe su Hilo de Vida interno. */
    public static void entrar(MinecraftServer server, ServerPlayer p, BlockPos origen) {
        ServerLevel telar = TelarUtil.telar(server);
        if (telar == null) return;
        if (origen != null) ORIGEN.put(p.getUUID(), origen);
        double x = TelarZones.LLEGADA_X + 0.5, z = TelarZones.LLEGADA_Z + 0.5;
        double y = TelarTerrain.alturaUmbral(TelarZones.LLEGADA_X, TelarZones.LLEGADA_Z) + 1;
        p.teleportTo(telar, x, y, z, Set.<Relative>of(), p.getYRot(), p.getXRot(), true);
        SVZCoreAPI.iniciarHiloVidaInterno(p); // 100, o 0 si llegó poseído (lo aplica SVZ-Core)
        p.displayClientMessage(Component.literal("Cruzas el hilo... El Telar Roto te recibe."), false);
    }

    /** Salida del Telar Roto hacia el altar de origen (o el centro del Overworld). */
    public static void regresar(MinecraftServer server, ServerPlayer p) {
        ServerLevel ow = server.overworld();
        BlockPos o = ORIGEN.get(p.getUUID());
        double x, y, z;
        if (o != null) {
            x = o.getX() + 2.5;
            y = o.getY() + 1;
            z = o.getZ() + 0.5;
        } else {
            x = 0.5;
            z = 0.5;
            y = ow.getHeight(Heightmap.Types.MOTION_BLOCKING, 0, 0);
        }
        p.teleportTo(ow, x, y, z, Set.<Relative>of(), p.getYRot(), p.getXRot(), true);
        p.displayClientMessage(Component.literal("Regresas del Telar Roto."), false);
    }
}
