package com.svz.telar.logic;

import com.svz.core.api.SVZClass;
import com.svz.core.api.SVZCoreAPI;
import com.svz.core.event.SVZMuerteTelarEvent;
import com.svz.core.event.SVZPosesionEvent;
import net.fabricmc.loader.api.FabricLoader;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import com.svz.mobs.api.SVZMobsAPI;
import com.svz.mobs.entity.SVZMobMarker;
import com.svz.mobs.entity.boss.SVZBoss;
import com.svz.telar.ModBlocks;
import com.svz.telar.SVZTelarRotoMod;
import com.svz.telar.npc.Tejedor;
import com.svz.telar.portal.PortalManager;
import com.svz.telar.rescue.RescueManager;
import com.svz.telar.worldgen.TelarZones;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.AABB;

/** Reglas del Telar Roto: muerte permanente, anuncio, progreso por zonas, recursos y limpieza de mobs vanilla. */
public final class TelarEvents {
    private TelarEvents() {}

    /** Jugadores que llegaron a 0 hilos y deben despertar en el Telar Roto en cuanto estén vivos. */
    private static final Set<UUID> PENDIENTES = new HashSet<>();

    public static void register() {
        // 0 hilos: el jugador despierta en la Zona 1 del Telar Roto (si SVZ-Posesion está instalado, él gestiona el traslado)
        SVZPosesionEvent.EVENT.register((player, causa) -> {
            if (FabricLoader.getInstance().isModLoaded("svz-posesion")) return;
            if (!SVZCoreAPI.isInTelarRoto(player)) PENDIENTES.add(player.getUUID());
        });
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (PENDIENTES.isEmpty() || server.getTickCount() % 10 != 0) return;
            for (UUID id : new HashSet<>(PENDIENTES)) {
                ServerPlayer p = server.getPlayerList().getPlayer(id);
                if (p == null) continue;                         // desconectado: se hará al volver
                if (!p.isAlive() || p.isSpectator()) continue;   // espera a reaparecer
                PENDIENTES.remove(id);
                if (TelarUtil.telar(server) == null) continue;
                PortalManager.entrar(server, p, null);           // llega poseído: Hilo de Vida interno = 0
                p.displayClientMessage(Component.literal("§4Tu hilo se ha agotado. Despiertas en el Telar Roto..."), false);
            }
        });

        // 1) Muerte permanente: se marca ANTES que cualquier otro mod (Hilo de Vida, Cofre, Resurrección ya no actúan).
        Identifier temprano = SVZTelarRotoMod.id("muerte_permanente");
        ServerLivingEntityEvents.ALLOW_DEATH.addPhaseOrdering(temprano, Event.DEFAULT_PHASE);
        ServerLivingEntityEvents.ALLOW_DEATH.register(temprano, (entity, source, amount) -> {
            if (entity instanceof ServerPlayer p && SVZCoreAPI.isInTelarRoto(p)) SVZCoreAPI.setMuertePermanente(p, true);
            return true;
        });

        // 2) Anuncio global, registro de atrapados y (opcional) expulsión
        SVZMuerteTelarEvent.EVENT.register((player, source, permanente) -> {
            MinecraftServer server = player.level().getServer();
            if (server == null) return;
            RescueManager.registrarAtrapado(server, player);
            server.getPlayerList().broadcastSystemMessage(Component.literal("§c" + player.getName().getString()
                    + " ha muerto en el Telar Roto. Su hilo se ha cortado para siempre."), false);
            if (SVZTelarRotoMod.EXPULSAR_AL_MORIR && player.connection != null) {
                player.connection.disconnect(Component.literal("Tu hilo se ha cortado para siempre en el Telar Roto."));
            }
        });

        // 3) Solo mobs de SVZ en el Telar: se descartan los vanilla que genere el bioma
        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if (!SVZCoreAPI.isTelarRoto(world.dimension())) return;
            if (entity instanceof Mob m && !(m instanceof SVZMobMarker) && !m.getTags().contains(Tejedor.TAG) && !m.getTags().contains("svz_evento")) {
                world.getServer().execute(entity::discard);
            }
        });

        // 4) Recursos de las vetas según la zona y la clase del jugador
        PlayerBlockBreakEvents.AFTER.register((level, player, pos, state, be) -> {
            if (state.is(ModBlocks.VETA) && level instanceof ServerLevel sl && player instanceof ServerPlayer sp) {
                soltarRecursos(sl, sp, pos);
            }
        });

        ServerTickEvents.END_SERVER_TICK.register(TelarEvents::tick);
    }

    // ------------------------------------------------------------ recursos
    private static void soltarRecursos(ServerLevel level, ServerPlayer p, net.minecraft.core.BlockPos pos) {
        int zona = TelarZones.zona(pos.getX());
        String a, b;
        switch (zona) {
            case 1 -> { a = "hilo_espectral"; b = "hilo_espectral"; }
            case 2 -> { a = "hilo_espectral"; b = "nudo_de_alma"; }
            case 3 -> { a = "nudo_de_alma"; b = "ceniza_de_titere"; }
            case 4 -> { a = "ceniza_de_titere"; b = "tela_de_difunto"; }
            default -> { a = "lagrima_de_tejedor"; b = "lagrima_de_tejedor"; }
        }
        double r = level.random.nextDouble();
        SVZClass clase = SVZCoreAPI.getClase(p);
        String item;
        if (clase == SVZClass.CHEF && r < 0.20) item = "maiz_olvidado";           // solo el Chef lo extrae
        else if (clase == SVZClass.HERRERO && r < 0.20) item = "metal_olvidado";  // solo el Herrero lo extrae
        else item = level.random.nextBoolean() ? a : b;
        int n = 1 + level.random.nextInt(zona >= 4 ? 3 : 2);
        Block.popResource(level, pos, new ItemStack(TelarUtil.item(item), n));
    }

    // ------------------------------------------------------------ tick
    private static void tick(MinecraftServer server) {
        PortalManager.tick(server);
        if (server.getTickCount() % 20 != 0) return;
        ServerLevel telar = TelarUtil.telar(server);
        if (telar == null) return;
        for (ServerPlayer p : telar.players()) {
            if (p.isSpectator() || p.getY() < 20 || Math.abs(p.getZ()) > 110) continue;
            int zona = TelarZones.zona((int) Math.floor(p.getX()));
            String tag = "svz_telar_z" + zona;
            if (!p.getTags().contains(tag)) {
                p.addTag(tag);
                p.displayClientMessage(Component.literal("Zona " + zona + ": " + TelarZones.NOMBRES[zona]), true);
                p.displayClientMessage(Component.literal("§7Entras en la Zona " + zona + ": §f" + TelarZones.NOMBRES[zona]), false);
            }
            if (zona == 1) Tejedor.asegurar(telar);
            if (zona == 5 && p.getX() >= 640 && Math.abs(p.getZ()) < 45 && !p.getTags().contains("svz_boss_primer_titere")) {
                AABB area = new AABB(500, 0, -150, 900, 255, 150);
                if (telar.getEntitiesOfClass(SVZBoss.class, area, bb -> bb.profile().id.equals("primer_titere")).isEmpty()
                        && !RescueManager.juicioActivo()) {
                    SVZMobsAPI.spawn(telar, "primer_titere", TelarZones.JUICIO_X + 0.5, TelarZones.BASE_Y + 3, 0.5);
                    p.displayClientMessage(Component.literal("§4El Primer Títere despierta..."), false);
                }
            }
        }
    }
}
