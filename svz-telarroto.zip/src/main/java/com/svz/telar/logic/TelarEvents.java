package com.svz.telar.logic;

import com.svz.core.api.SVZClass;
import com.svz.core.api.SVZCoreAPI;
import com.svz.core.event.SVZMuerteTelarEvent;
import com.svz.core.event.SVZPosesionEvent;
import net.fabricmc.loader.api.FabricLoader;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import com.svz.mobs.api.SVZMobsAPI;
import com.svz.mobs.entity.SVZMobMarker;
import com.svz.mobs.entity.boss.SVZBoss;
import com.svz.telar.ModBlocks;
import com.svz.telar.SVZTelarRotoMod;
import com.svz.telar.npc.Tejedor;
import com.svz.telar.portal.PortalManager;
import com.svz.telar.rescue.RescueManager;
import com.svz.telar.worldgen.TelarZones;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.AABB;

/** Reglas del Telar Roto: muerte permanente, anuncio, progreso por zonas, recursos y limpieza de mobs vanilla. */
public final class TelarEvents {
    private TelarEvents() {}

    /** Jugadores que llegaron a 0 hilos y deben despertar en el Telar Roto en cuanto estén vivos. */
    private static final Set<UUID> PENDIENTES = new HashSet<>();
    private static final java.util.Map<UUID, Boolean> EN_SEGURA = new java.util.HashMap<>();

    public static boolean enZonaSegura(double x, double z) {
        return x >= TelarZones.X_MIN && x <= TelarZones.SEGURA_X_MAX && Math.abs(z) <= 100;
    }

    public static void register() {
        // 0 hilos: el jugador despierta en la Zona 1 del Telar Roto (si SVZ-Posesion está instalado, él gestiona el traslado)
        SVZPosesionEvent.EVENT.register((player, causa) -> {
            if (FabricLoader.getInstance().isModLoaded("svz-posesion")) return;
            if (!SVZCoreAPI.isInTelarRoto(player)) PENDIENTES.add(player.getUUID());
        });
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (PENDIENTES.isEmpty()) return;
            for (UUID id : new HashSet<>(PENDIENTES)) {
                ServerPlayer p = server.getPlayerList().getPlayer(id);
                if (p == null) continue;                         // desconectado: se hará al volver
                if (!p.isAlive() || p.isSpectator()) continue;   // espera a reaparecer
                PENDIENTES.remove(id);
                if (TelarUtil.telar(server) == null) continue;
                PortalManager.entrar(server, p, null);           // llega poseído: Hilo de Vida interno = 0
                p.displayClientMessage(Component.literal(SVZCoreAPI.isPoseido(p) ? "§4Tu hilo se ha agotado. Despiertas en el Telar Roto..."
                        : "§4Has muerto. Tu hilo te arrastra al Telar Roto..."), false);
            }
        });

        // Toda muerte fuera del Telar Roto te lleva al Telar al reaparecer.
        // Excepciones: Hilo de Vida (te revive en el sitio, no hay muerte) y muerte permanente dentro del Telar.
        // Con Hilo de Cofre llegas con todo tu inventario (SVZ-Items lo devuelve al reaparecer).
        ServerPlayerEvents.AFTER_RESPAWN.register((viejo, nuevo, vivo) -> {
            if (!vivo && !SVZCoreAPI.isMuertePermanente(nuevo) && !SVZCoreAPI.isInTelarRoto(nuevo)) PENDIENTES.add(nuevo.getUUID());
        });

        // Zona segura del Umbral: los mobs no hacen daño dentro
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, cantidad) ->
                !(entity instanceof ServerPlayer p && SVZCoreAPI.isInTelarRoto(p) && enZonaSegura(p.getX(), p.getZ()) && source.getEntity() instanceof Mob));

        // SVZ-Mobs no genera espectros en la zona segura ni durante el periodo de gracia
        SVZMobsAPI.registrarZonaSegura(new SVZMobsAPI.ZonaSegura() {
            @Override
            public boolean protegido(ServerPlayer p) {
                return enZonaSegura(p.getX(), p.getZ()) || PortalManager.enGracia(p);
            }

            @Override
            public boolean posicionSegura(ServerLevel l, double x, double z) {
                return enZonaSegura(x, z);
            }
        });

        // 1) Muerte permanente: se marca ANTES que cualquier otro mod (Hilo de Vida, Cofre, Resurrección ya no actúan).
        Identifier temprano = SVZTelarRotoMod.id("muerte_permanente");
        ServerLivingEntityEvents.ALLOW_DEATH.addPhaseOrdering(temprano, Event.DEFAULT_PHASE);
        ServerLivingEntityEvents.ALLOW_DEATH.register(temprano, (entity, source, amount) -> {
            if (entity instanceof ServerPlayer p && SVZCoreAPI.isInTelarRoto(p)) SVZCoreAPI.setMuertePermanente(p, true);
            return true;
        });

        // 2) Anuncio global, registro de atrapados y (opcional) expulsión
        SVZMuerteTelarEvent.EVENT.register((player, source, permanente) -> {
            MinecraftServer server = player.level().getServer();
            if (server == null) return;
            RescueManager.registrarAtrapado(server, player);
            server.getPlayerList().broadcastSystemMessage(Component.literal("§c" + player.getName().getString()
                    + " ha muerto en el Telar Roto. Su hilo se ha cortado para siempre."), false);
            if (SVZTelarRotoMod.EXPULSAR_AL_MORIR && player.connection != null) {
                player.connection.disconnect(Component.literal("Tu hilo se ha cortado para siempre en el Telar Roto."));
            }
        });

        // 3) Solo mobs de SVZ en el Telar: se descartan los vanilla que genere el bioma
        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if (!SVZCoreAPI.isTelarRoto(world.dimension())) return;
            if (entity instanceof Mob m && !(m instanceof SVZMobMarker) && !m.getTags().contains(Tejedor.TAG) && !m.getTags().contains("svz_evento")) {
                world.getServer().execute(entity::discard);
            }
        });

        // 4) Recursos de las vetas según la zona y la clase del jugador
        PlayerBlockBreakEvents.AFTER.register((level, player, pos, state, be) -> {
            if (state.is(ModBlocks.VETA) && level instanceof ServerLevel sl && player instanceof ServerPlayer sp) {
                soltarRecursos(sl, sp, pos);
            }
        });

        ServerTickEvents.END_SERVER_TICK.register(TelarEvents::tick);
    }

    // ------------------------------------------------------------ recursos
    private static void soltarRecursos(ServerLevel level, ServerPlayer p, net.minecraft.core.BlockPos pos) {
        int zona = TelarZones.zona(pos.getX());
        String a, b;
        switch (zona) {
            case 1 -> { a = "hilo_espectral"; b = "hilo_espectral"; }
            case 2 -> { a = "hilo_espectral"; b = "nudo_de_alma"; }
            case 3 -> { a = "nudo_de_alma"; b = "ceniza_de_titere"; }
            case 4 -> { a = "ceniza_de_titere"; b = "tela_de_difunto"; }
            default -> { a = "lagrima_de_tejedor"; b = "lagrima_de_tejedor"; }
        }
        double r = level.random.nextDouble();
        SVZClass clase = SVZCoreAPI.getClase(p);
        String item;
        if (clase == SVZClass.CHEF && r < 0.20) item = "maiz_olvidado";           // solo el Chef lo extrae
        else if (clase == SVZClass.HERRERO && r < 0.20) item = "metal_olvidado";  // solo el Herrero lo extrae
        else item = level.random.nextBoolean() ? a : b;
        int n = 1 + level.random.nextInt(zona >= 4 ? 3 : 2);
        Block.popResource(level, pos, new ItemStack(TelarUtil.item(item), n));
    }

    // ------------------------------------------------------------ tick
    private static void tick(MinecraftServer server) {
        PortalManager.tick(server);
        if (server.getTickCount() % 20 != 0) return;
        ServerLevel telar = TelarUtil.telar(server);
        if (telar == null) return;
        for (Mob m : telar.getEntitiesOfClass(Mob.class, new AABB(TelarZones.X_MIN, 0, -100, TelarZones.SEGURA_X_MAX, 255, 100),
                e -> e instanceof SVZMobMarker && !e.getTags().contains("svz_evento"))) m.discard();
        for (ServerPlayer p : telar.players()) {
            if (p.isSpectator() || p.getY() < 20 || Math.abs(p.getZ()) > 110) continue;
            int zona = TelarZones.zona((int) Math.floor(p.getX()));
            String tag = "svz_telar_z" + zona;
            if (!p.getTags().contains(tag)) {
                p.addTag(tag);
                p.displayClientMessage(Component.literal("Zona " + zona + ": " + TelarZones.NOMBRES[zona]), true);
                p.displayClientMessage(Component.literal("§7Entras en la Zona " + zona + ": §f" + TelarZones.NOMBRES[zona]), false);
            }
            if (zona == 1) Tejedor.asegurar(telar);
            boolean segura = enZonaSegura(p.getX(), p.getZ());
            if (segura != EN_SEGURA.getOrDefault(p.getUUID(), false)) {
                EN_SEGURA.put(p.getUUID(), segura);
                p.displayClientMessage(Component.literal(segura ? "§aZona segura del Umbral: aquí nada puede hacerte daño."
                        : "§cSales de la zona segura. A partir de aquí aparecen espectros."), true);
            }
            if (zona == 5 && p.getX() >= 640 && Math.abs(p.getZ()) < 45 && !p.getTags().contains("svz_boss_primer_titere")) {
                AABB area = new AABB(500, 0, -150, 900, 255, 150);
                if (telar.getEntitiesOfClass(SVZBoss.class, area, bb -> bb.profile().id.equals("primer_titere")).isEmpty()
                        && !RescueManager.juicioActivo()) {
                    SVZMobsAPI.spawn(telar, "primer_titere", TelarZones.JUICIO_X + 0.5, TelarZones.BASE_Y + 3, 0.5);
                    p.displayClientMessage(Component.literal("§4El Primer Títere despierta..."), false);
                }
            }
        }
    }
}
