package com.svz.telar.logic;

import com.svz.core.api.SVZCoreAPI;
import com.svz.items.item.ModItems;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;

public final class TelarUtil {
    private TelarUtil() {}

    /** @return el nivel del Telar Roto, o {@code null} si el mundo no lo tiene. */
    public static ServerLevel telar(MinecraftServer server) {
        for (ResourceKey<Level> k : server.levelKeys()) {
            if (SVZCoreAPI.isTelarRoto(k)) return server.getLevel(k);
        }
        return null;
    }

    /** Ítem de SVZ-Items por nombre. */
    public static Item item(String path) {
        return BuiltInRegistries.ITEM.getValue(Identifier.fromNamespaceAndPath("svz-items", path));
    }
}
