package com.svz.telar.command;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.svz.telar.logic.TelarUtil;
import com.svz.telar.portal.PortalManager;
import com.svz.telar.rescue.RescueManager;
import com.svz.telar.worldgen.TelarTerrain;
import com.svz.telar.worldgen.TelarZones;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Relative;

import java.util.List;
import java.util.Set;
import java.util.function.Predicate;

/**
 * /telar juicio <liberar|reclamar|cortar> · /telar estado
 * Admin: /telar revivir <jugador> · /telar ir <zona 1-5>
 */
public final class TelarCommands {
    private TelarCommands() {}

    // NOTA 1.21.11: igual que en SVZ-Core, esta línea depende del sistema de permisos.
    private static final Predicate<CommandSourceStack> ADMIN = Commands.hasPermission(Commands.LEVEL_GAMEMASTERS);

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(Commands.literal("telar")
                        .then(Commands.literal("juicio")
                                .then(Commands.argument("opcion", StringArgumentType.word())
                                        .suggests((c, b) -> SharedSuggestionProvider.suggest(List.of("liberar", "reclamar", "cortar"), b))
                                        .executes(ctx -> {
                                            ServerPlayer p = ctx.getSource().getPlayerOrException();
                                            String msg = RescueManager.votar(p, StringArgumentType.getString(ctx, "opcion"));
                                            ctx.getSource().sendSuccess(() -> Component.literal(msg), false);
                                            return 1;
                                        })))
                        .then(Commands.literal("estado").executes(ctx -> {
                            ServerPlayer p = ctx.getSource().getPlayerOrException();
                            int n = RescueManager.cuantosAtrapados(ctx.getSource().getServer());
                            ctx.getSource().sendSuccess(() -> Component.literal("Atrapados en el Telar Roto: " + n), false);
                            return n;
                        }))
                        .then(Commands.literal("revivir").requires(ADMIN)
                                .then(Commands.argument("jugador", EntityArgument.player()).executes(ctx -> {
                                    ServerPlayer p = EntityArgument.getPlayer(ctx, "jugador");
                                    RescueManager.revivir(p);
                                    ctx.getSource().sendSuccess(() -> Component.literal("Revivido: " + p.getName().getString()), true);
                                    return 1;
                                })))
                        .then(Commands.literal("ir").requires(ADMIN)
                                .then(Commands.argument("zona", IntegerArgumentType.integer(1, 5)).executes(ctx -> {
                                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                                    ServerLevel telar = TelarUtil.telar(ctx.getSource().getServer());
                                    if (telar == null) {
                                        ctx.getSource().sendFailure(Component.literal("El Telar Roto no existe en este mundo."));
                                        return 0;
                                    }
                                    int zona = IntegerArgumentType.getInteger(ctx, "zona");
                                    int x = zona == 1 ? 2 : (zona - 1) * TelarZones.LARGO + 3;
                                    int y = zona == 1 ? TelarTerrain.alturaUmbral(2, 2) + 1 : TelarZones.BASE_Y + 1;
                                    p.teleportTo(telar, x + 0.5, y, 0.5, Set.<Relative>of(), p.getYRot(), p.getXRot(), true);
                                    return 1;
                                })))));
    }
}
