package com.svz.telar.rescue;

import com.svz.core.api.SVZCoreAPI;
import com.svz.mobs.entity.boss.SVZBoss;
import com.svz.telar.logic.TelarUtil;
import com.svz.telar.portal.PortalManager;
import com.svz.telar.worldgen.TelarZones;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity;
import net.minecraft.world.level.storage.loot.LootTable;
import com.svz.telar.SVZTelarRotoMod;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Ritual de rescate. El equipo vivo completa las 5 zonas; al caer El Primer Títere se abre el Juicio:
 * <ul>
 *   <li><b>liberar</b>: todos los atrapados reviven y el equipo regresa;</li>
 *   <li><b>reclamar</b>: aparece el cofre del Juicio (recursos extremos), los atrapados siguen atrapados;</li>
 *   <li><b>cortar</b>: el equipo vuelve con +3 hilos y el Telar se reinicia para otro intento.</li>
 * </ul>
 * Gana la opción más votada (empate: liberar &gt; cortar &gt; reclamar). Quien muera en el Telar queda atrapado.
 */
public final class RescueManager {
    private RescueManager() {}

    private static final int VOTO_TICKS = 1200; // 60 s

    private static final class Juicio {
        final int limite;
        final Set<UUID> participantes;
        final double x, y, z;
        final Map<UUID, String> votos = new HashMap<>();

        Juicio(int limite, Set<UUID> participantes, double x, double y, double z) {
            this.limite = limite;
            this.participantes = participantes;
            this.x = x;
            this.y = y;
            this.z = z;
        }
    }

    private static Juicio juicio;

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(RescueManager::tick);

        // El Primer Títere cae -> se abre el Juicio
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (entity instanceof SVZBoss b && b.profile().id.equals("primer_titere") && entity.level() instanceof ServerLevel lvl
                    && SVZCoreAPI.isTelarRoto(lvl.dimension())) {
                abrirJuicio(lvl.getServer(), lvl, entity.getX(), entity.getY(), entity.getZ());
            }
        });

        // revives pendientes de jugadores que estaban desconectados
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayer p = handler.getPlayer();
            if (TelarData.get(server).pendientes.remove(p.getUUID())) revivir(p);
        });
    }

    // ------------------------------------------------------------ atrapados
    public static void registrarAtrapado(MinecraftServer server, ServerPlayer p) {
        TelarData.get(server).atrapados.add(p.getUUID());
    }

    public static int cuantosAtrapados(MinecraftServer server) {
        return TelarData.get(server).atrapados.size();
    }

    public static void revivir(ServerPlayer p) {
        SVZCoreAPI.setMuertePermanente(p, false);
        SVZCoreAPI.setPoseido(p, false);
        if (SVZCoreAPI.getHilos(p) < 5) SVZCoreAPI.setHilos(p, 5);
        p.displayClientMessage(Component.literal("Tu hilo se ha vuelto a tejer. Has regresado del Telar Roto."), false);
    }

    /** Revive a todos los atrapados (en línea al instante, los demás al conectarse). */
    public static void rescatarATodos(MinecraftServer server) {
        TelarData d = TelarData.get(server);
        for (UUID id : d.atrapados) {
            ServerPlayer p = server.getPlayerList().getPlayer(id);
            if (p != null) revivir(p);
            else d.pendientes.add(id);
        }
        d.atrapados.clear();
    }

    // ------------------------------------------------------------ juicio
    private static void abrirJuicio(MinecraftServer server, ServerLevel telar, double x, double y, double z) {
        if (juicio != null) return;
        Set<UUID> part = new HashSet<>();
        for (ServerPlayer p : telar.players()) if (!p.isSpectator()) part.add(p.getUUID());
        if (part.isEmpty()) return;
        juicio = new Juicio(server.getTickCount() + VOTO_TICKS, part, x, y, z);
        for (UUID id : part) {
            ServerPlayer p = server.getPlayerList().getPlayer(id);
            if (p == null) continue;
            p.displayClientMessage(Component.literal("§6El Primer Títere ha caído. El Juicio del Telar comienza (60 s)."), false);
            p.displayClientMessage(Component.literal("Decidid con §e/telar juicio liberar§r (rescatar a los atrapados), "
                    + "§e/telar juicio reclamar§r (recursos extremos) o §e/telar juicio cortar§r (volver con +3 hilos)."), false);
        }
    }

    public static String votar(ServerPlayer p, String opcion) {
        if (juicio == null) return "No hay ningún Juicio en curso.";
        if (!juicio.participantes.contains(p.getUUID())) return "No participas en este Juicio.";
        if (!opcion.equals("liberar") && !opcion.equals("reclamar") && !opcion.equals("cortar")) return "Opciones: liberar, reclamar, cortar.";
        juicio.votos.put(p.getUUID(), opcion);
        return "Tu voto: " + opcion + " (" + juicio.votos.size() + "/" + juicio.participantes.size() + ")";
    }

    private static void tick(MinecraftServer server) {
        if (juicio == null) return;
        boolean todos = juicio.votos.keySet().containsAll(juicio.participantes);
        if (todos || server.getTickCount() >= juicio.limite) resolver(server);
    }

    private static void resolver(MinecraftServer server) {
        Juicio j = juicio;
        juicio = null;
        int liberar = 0, reclamar = 0, cortar = 0;
        for (String v : j.votos.values()) {
            switch (v) {
                case "liberar" -> liberar++;
                case "reclamar" -> reclamar++;
                default -> cortar++;
            }
        }
        String ganador = (liberar >= cortar && liberar >= reclamar) ? "liberar" : (cortar >= reclamar ? "cortar" : "reclamar");
        if (j.votos.isEmpty()) ganador = "liberar"; // sin votos: el equipo elige salvar a los suyos

        switch (ganador) {
            case "liberar" -> {
                int n = cuantosAtrapados(server);
                rescatarATodos(server);
                server.getPlayerList().broadcastSystemMessage(Component.literal("§bEl Telar Roto ha sido liberado: " + n + " hilo(s) vuelven a tejerse."), false);
                volver(server, j, 0);
            }
            case "cortar" -> {
                server.getPlayerList().broadcastSystemMessage(Component.literal("§7El equipo ha cortado el hilo del Telar. Los atrapados siguen perdidos."), false);
                volver(server, j, 3);
            }
            default -> {
                ServerLevel telar = TelarUtil.telar(server);
                if (telar != null) cofreDelJuicio(telar, new BlockPos((int) j.x, (int) j.y + 1, (int) j.z));
                server.getPlayerList().broadcastSystemMessage(Component.literal("§6El equipo reclama el tesoro del Juicio. Los atrapados siguen perdidos."), false);
                for (UUID id : j.participantes) {
                    ServerPlayer p = server.getPlayerList().getPlayer(id);
                    if (p != null) limpiarProgreso(p);
                }
            }
        }
    }

    private static void volver(MinecraftServer server, Juicio j, int hilos) {
        for (UUID id : j.participantes) {
            ServerPlayer p = server.getPlayerList().getPlayer(id);
            if (p == null || p.isSpectator() || SVZCoreAPI.isMuertePermanente(p)) continue;
            if (hilos > 0) SVZCoreAPI.addHilos(p, hilos);
            limpiarProgreso(p);
            PortalManager.regresar(server, p);
        }
    }

    private static void limpiarProgreso(ServerPlayer p) {
        for (int z = 1; z <= 5; z++) p.removeTag("svz_telar_z" + z);
        p.removeTag("svz_boss_primer_titere"); // permite repetir el rescate
    }

    private static void cofreDelJuicio(ServerLevel telar, BlockPos pos) {
        telar.setBlock(pos, Blocks.CHEST.defaultBlockState(), 3);
        BlockEntity be = telar.getBlockEntity(pos);
        if (be instanceof RandomizableContainerBlockEntity c) {
            ResourceKey<LootTable> key = ResourceKey.create(Registries.LOOT_TABLE, SVZTelarRotoMod.id("chests/juicio"));
            c.setLootTable(key);
            c.setLootTableSeed(telar.random.nextLong());
        }
    }

    public static boolean juicioActivo() {
        return juicio != null;
    }
}
