package com.svz.telar.rescue;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.svz.telar.SVZTelarRotoMod;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.minecraft.core.UUIDUtil;
import net.minecraft.server.MinecraftServer;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/** Estado persistente del mundo (guardado en el Overworld): jugadores atrapados y revivires pendientes. */
public class TelarData {
    public final Set<UUID> atrapados = new LinkedHashSet<>();
    public final Set<UUID> pendientes = new LinkedHashSet<>();

    public static AttachmentType<TelarData> TYPE;

    public static final Codec<TelarData> CODEC = RecordCodecBuilder.create(i -> i.group(
            UUIDUtil.CODEC.listOf().optionalFieldOf("atrapados", List.of()).forGetter(d -> new ArrayList<>(d.atrapados)),
            UUIDUtil.CODEC.listOf().optionalFieldOf("pendientes", List.of()).forGetter(d -> new ArrayList<>(d.pendientes))
    ).apply(i, TelarData::new));

    public TelarData() {}

    private TelarData(List<UUID> atrapados, List<UUID> pendientes) {
        this.atrapados.addAll(atrapados);
        this.pendientes.addAll(pendientes);
    }

    public static void register() {
        TYPE = AttachmentRegistry.<TelarData>create(SVZTelarRotoMod.id("data"),
                b -> b.initializer(TelarData::new).persistent(CODEC));
    }

    public static TelarData get(MinecraftServer server) {
        return server.overworld().getAttachedOrCreate(TYPE);
    }
}
