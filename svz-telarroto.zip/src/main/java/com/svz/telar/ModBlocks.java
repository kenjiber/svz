package com.svz.telar;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;

/** Bloques del Telar Roto: el Altar del Tejedor y la Veta del Telar (nodo de recursos). */
public final class ModBlocks {
    private ModBlocks() {}

    public static Block ALTAR;
    public static Block VETA;
    public static Item ALTAR_ITEM;
    public static Item VETA_ITEM;

    private static Block reg(String name, BlockBehaviour.Properties props, boolean item) {
        ResourceKey<Block> key = ResourceKey.create(Registries.BLOCK, SVZTelarRotoMod.id(name));
        Block block = new Block(props.setId(key));
        Registry.register(BuiltInRegistries.BLOCK, key, block);
        ResourceKey<Item> ik = ResourceKey.create(Registries.ITEM, SVZTelarRotoMod.id(name));
        BlockItem bi = new BlockItem(block, new Item.Properties().setId(ik).useBlockDescriptionPrefix());
        Registry.register(BuiltInRegistries.ITEM, ik, bi);
        if (name.equals("altar_del_tejedor")) ALTAR_ITEM = bi;
        else VETA_ITEM = bi;
        return block;
    }

    public static void register() {
        ALTAR = reg("altar_del_tejedor", BlockBehaviour.Properties.of().strength(30.0F, 1200.0F)
                .requiresCorrectToolForDrops().sound(SoundType.DEEPSLATE).lightLevel(s -> 8), true);
        // La veta no suelta loot propio: sus recursos los decide la zona (ver TelarEvents)
        VETA = reg("veta_del_telar", BlockBehaviour.Properties.of().strength(3.0F, 6.0F)
                .requiresCorrectToolForDrops().sound(SoundType.AMETHYST).lightLevel(s -> 5).noLootTable(), false);
    }
}
