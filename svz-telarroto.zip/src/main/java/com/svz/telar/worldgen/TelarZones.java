package com.svz.telar.worldgen;

/**
 * Geometría del Telar Roto: una franja a lo largo del eje +X ("el hilo"), cada zona de 150 bloques.
 * Zona 1: x -48..150 · Zona 2: 150..300 · Zona 3: 300..450 · Zona 4: 450..600 · Zona 5: 600..800 (Juicio en x=700).
 * La zona 5 empieza a 600 del origen, igual que {@code zona5Radio} de SVZ-Mobs.
 */
public final class TelarZones {
    private TelarZones() {}

    public static final int LARGO = 150;
    public static final int BASE_Y = 64;
    public static final int MITAD_ANCHO = 96;
    public static final int X_MIN = -48;
    public static final int X_MAX = 800;
    public static final int JUICIO_X = 700;

    public static final String[] NOMBRES = {"", "El Umbral", "Laberinto de Nudos", "Arena de Títeres", "Río de Ceniza", "Juicio del Telar"};

    public static int zona(int x) {
        if (x < 0) return 1;
        return Math.min(5, x / LARGO + 1);
    }

    /** Coordenadas del Altar del Tejedor generado en la Zona 1. */
    public static final int ALTAR_X = 6, ALTAR_Z = 6;
    /** Punto de llegada al entrar por el portal. */
    public static final int LLEGADA_X = 2, LLEGADA_Z = 2;
    /** Posición del NPC El Tejedor. */
    public static final int TEJEDOR_X = 12, TEJEDOR_Z = 8;
}
