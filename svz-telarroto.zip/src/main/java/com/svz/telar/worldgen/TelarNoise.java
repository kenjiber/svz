package com.svz.telar.worldgen;

/** Hash y ruido de valor deterministas (sin depender de clases de ruido de Minecraft). */
public final class TelarNoise {
    private TelarNoise() {}

    public static long mix(long a, long b, long c) {
        long h = a * 0x9E3779B97F4A7C15L ^ b * 0xC2B2AE3D27D4EB4FL ^ c * 0x165667B19E3779F9L;
        h ^= h >>> 32;
        h *= 0xD6E8FEB86659FD93L;
        h ^= h >>> 32;
        h *= 0xD6E8FEB86659FD93L;
        h ^= h >>> 32;
        return h;
    }

    /** Número pseudoaleatorio en [0,1) para (a,b,salt). */
    public static double rnd(long a, long b, long salt) {
        return (mix(a, b, salt) >>> 11) * (1.0 / (1L << 53));
    }

    /** Ruido de valor suave en [0,1). */
    public static double noise(double x, double z, int salt) {
        int x0 = (int) Math.floor(x), z0 = (int) Math.floor(z);
        double fx = x - x0, fz = z - z0;
        fx = fx * fx * (3 - 2 * fx);
        fz = fz * fz * (3 - 2 * fz);
        double a = rnd(x0, z0, salt), b = rnd(x0 + 1, z0, salt), c = rnd(x0, z0 + 1, salt), d = rnd(x0 + 1, z0 + 1, salt);
        return (a + (b - a) * fx) + ((c + (d - c) * fx) - (a + (b - a) * fx)) * fz;
    }
}
