package com.svz.telar.worldgen;

import com.svz.telar.ModBlocks;
import com.svz.telar.SVZTelarRotoMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.loot.LootTable;

import static com.svz.telar.worldgen.TelarNoise.noise;
import static com.svz.telar.worldgen.TelarNoise.rnd;
import static com.svz.telar.worldgen.TelarZones.BASE_Y;

/**
 * Generación procedural columna a columna de las 5 zonas. No depende de la API de chunks:
 * escribe a través de {@link Sink}, que implementa el generador.
 */
public final class TelarTerrain {
    private TelarTerrain() {}

    public interface Sink {
        void set(int x, int y, int z, BlockState state);

        void chest(int x, int y, int z, ResourceKey<LootTable> table, long seed);
    }

    private static ResourceKey<LootTable> loot(String name) {
        return ResourceKey.create(Registries.LOOT_TABLE, SVZTelarRotoMod.id("chests/" + name));
    }

    private static final BlockState AIRE = Blocks.AIR.defaultBlockState();

    // ------------------------------------------------------------------ entrada principal
    public static void columna(int x, int z, Sink s) {
        if (x < TelarZones.X_MIN || x > TelarZones.X_MAX) return;
        int az = Math.abs(z);
        int zona = TelarZones.zona(x);
        if (az > TelarZones.MITAD_ANCHO + 3) return;
        if (az > TelarZones.MITAD_ANCHO) {
            if (zona <= 3) muroLateral(x, z, s);
            return;
        }
        switch (zona) {
            case 1 -> umbral(x, z, s);
            case 2 -> laberinto(x, z, s);
            case 3 -> arena(x, z, s);
            case 4 -> rio(x, z, s);
            default -> juicio(x, z, s);
        }
    }

    /** Altura del suelo en las zonas 1-3 (usada por el NPC y el altar). */
    public static int alturaUmbral(int x, int z) {
        return BASE_Y + (int) Math.round((noise(x * 0.05, z * 0.05, 11) - 0.5) * 4);
    }

    // ------------------------------------------------------------------ utilidades
    private static void relleno(Sink s, int x, int z, int desde, int hasta, BlockState b) {
        for (int y = desde; y <= hasta; y++) s.set(x, y, z, b);
    }

    private static void muroLateral(int x, int z, Sink s) {
        relleno(s, x, z, BASE_Y - 8, BASE_Y + 14, Blocks.BLACKSTONE.defaultBlockState());
    }

    /** Coloca decoración/recursos sobre el suelo según la probabilidad; devuelve true si usó la columna. */
    private static boolean decorar(Sink s, int x, int z, int sueloY, int zonaLoot, double pVeta, double pCofre) {
        double r = rnd(x, z, 77);
        if (r < pVeta) {
            s.set(x, sueloY + 1, z, ModBlocks.VETA.defaultBlockState());
            return true;
        }
        if (r < pVeta + pCofre) {
            s.chest(x, sueloY + 1, z, loot("zona_" + zonaLoot), TelarNoise.mix(x, z, 5));
            return true;
        }
        return false;
    }

    // ------------------------------------------------------------------ Zona 1: El Umbral
    private static void umbral(int x, int z, Sink s) {
        int top = alturaUmbral(x, z);
        int borde = Math.min(Math.max(0, -x + TelarZones.X_MIN), 0); // reservado
        int grosor = 8;
        double p = noise(x * 0.09 + 100, z * 0.09, 23);
        BlockState sup = p > 0.64 ? Blocks.SOUL_SOIL.defaultBlockState()
                : (p < 0.22 ? Blocks.SMOOTH_BASALT.defaultBlockState() : Blocks.TUFF.defaultBlockState());
        for (int y = top - grosor; y <= top; y++) {
            s.set(x, y, z, y == top ? sup : (y >= top - 2 ? Blocks.TUFF.defaultBlockState() : Blocks.DEEPSLATE.defaultBlockState()));
        }
        if (x == TelarZones.ALTAR_X && z == TelarZones.ALTAR_Z) {
            s.set(x, top + 1, z, ModBlocks.ALTAR.defaultBlockState());
            return;
        }
        // zona despejada alrededor del altar, de la llegada y del Tejedor
        if (Math.abs(x - 6) < 12 && Math.abs(z - 6) < 12) {
            if (rnd(x, z, 3) < 0.01) s.set(x, top + 1, z, Blocks.SOUL_LANTERN.defaultBlockState());
            return;
        }
        if (!decorar(s, x, z, top, 1, 0.0030, 0.0006) && rnd(x, z, 9) < 0.004) {
            s.set(x, top + 1, z, Blocks.SOUL_TORCH.defaultBlockState());
        }
    }

    // ------------------------------------------------------------------ Zona 2: Laberinto de Nudos
    private static final int U = 4;          // lado de cada unidad del laberinto
    private static final int UX_MAX = 36, UZ_MAX = 46;
    private static final int NX = 18, NZ = 23; // celdas

    /** Árbol binario: cada celda abre hacia el norte (z-) o el este (x+). 0 = norte, 1 = este, -1 = ninguna. */
    private static int dir(int i, int j) {
        if (j == 0 && i == NX - 1) return -1;
        if (j == 0) return 1;
        if (i == NX - 1) return 0;
        return rnd(i, j, 41) < 0.5 ? 0 : 1;
    }

    private static boolean esMuro(int ux, int uz) {
        if (uz <= 0 || uz >= UZ_MAX) return true;
        if (ux <= 0 || ux >= UX_MAX) return false; // entrada y salida abiertas a todo lo ancho
        boolean ix = (ux & 1) == 1, iz = (uz & 1) == 1;
        if (!ix && !iz) return true;
        if (ix && iz) return false;
        if (ix) { // pared entre (i,j-1) y (i,j)
            int i = (ux - 1) / 2, j = uz / 2;
            return dir(i, j) != 0;
        }
        int i = (ux - 2) / 2, j = (uz - 1) / 2; // pared entre (i,j) y (i+1,j)
        return dir(i, j) != 1;
    }

    private static void laberinto(int x, int z, Sink s) {
        int ux = Math.floorDiv(x - 150, U), uz = Math.floorDiv(z + 96, U);
        BlockState suelo = Blocks.POLISHED_DEEPSLATE.defaultBlockState();
        boolean muro = uz > UZ_MAX || esMuro(ux, uz);
        boolean celda = !muro && (ux & 1) == 1 && (uz & 1) == 1 && ux < UX_MAX && uz < UZ_MAX;
        int lx = Math.floorMod(x - 150, U), lz = Math.floorMod(z + 96, U);
        boolean centro = lx >= 1 && lx <= 2 && lz >= 1 && lz <= 2;
        double trampa = celda ? rnd(ux, uz, 52) : 1.0;

        for (int y = BASE_Y - 6; y < BASE_Y; y++) s.set(x, y, z, Blocks.DEEPSLATE.defaultBlockState());
        if (muro) {
            double h = rnd(x, z, 8);
            s.set(x, BASE_Y, z, Blocks.DEEPSLATE_BRICKS.defaultBlockState());
            for (int y = BASE_Y + 1; y <= BASE_Y + 7; y++) {
                BlockState b = h < 0.08 ? Blocks.CRACKED_DEEPSLATE_BRICKS.defaultBlockState() : Blocks.DEEPSLATE_BRICKS.defaultBlockState();
                if (y == BASE_Y + 4 && h > 0.97) b = Blocks.SHROOMLIGHT.defaultBlockState();
                s.set(x, y, z, b);
            }
            return;
        }
        // suelo con trampas
        BlockState piso = suelo;
        if (celda && trampa < 0.06) piso = Blocks.MAGMA_BLOCK.defaultBlockState();                                  // magma
        if (celda && trampa >= 0.06 && trampa < 0.10 && centro) piso = Blocks.LAVA.defaultBlockState();            // pozo de lava
        s.set(x, BASE_Y, z, piso);
        if (celda && trampa >= 0.10 && trampa < 0.15 && centro) {                                                  // telarañas
            s.set(x, BASE_Y + 1, z, Blocks.COBWEB.defaultBlockState());
            s.set(x, BASE_Y + 2, z, Blocks.COBWEB.defaultBlockState());
        }
        if (celda && trampa >= 0.15 && centro && lx == 1 && lz == 1) {
            double r = rnd(ux, uz, 63);
            if (r < 0.07) s.set(x, BASE_Y + 1, z, ModBlocks.VETA.defaultBlockState());
            else if (r < 0.085) s.chest(x, BASE_Y + 1, z, loot("zona_2"), TelarNoise.mix(x, z, 6));
        }
    }

    // ------------------------------------------------------------------ Zona 3: Arena de Títeres
    private static void arena(int x, int z, Sink s) {
        int ax = Math.max(0, Math.min(2, Math.floorDiv(x - 300, 50)));
        int kz = Math.max(0, Math.min(3, (int) Math.round((z + 72) / 48.0)));
        int cx = 300 + ax * 50 + 25, cz = -72 + kz * 48;
        double dx = x - cx, dz = z - cz, d = Math.sqrt(dx * dx + dz * dz);
        double h = rnd(x, z, 12);

        for (int y = BASE_Y - 6; y < BASE_Y; y++) s.set(x, y, z, Blocks.BLACKSTONE.defaultBlockState());
        if (d <= 15.5) {
            BlockState b = (d > 8 && d < 9.2) ? Blocks.CRYING_OBSIDIAN.defaultBlockState()
                    : (h < 0.15 ? Blocks.CRACKED_POLISHED_BLACKSTONE_BRICKS.defaultBlockState() : Blocks.POLISHED_BLACKSTONE.defaultBlockState());
            s.set(x, BASE_Y, z, b);
            if (d <= 1.6) relleno(s, x, z, BASE_Y + 1, BASE_Y + 8, Blocks.CHISELED_POLISHED_BLACKSTONE.defaultBlockState());
            else if ((int) dx == 3 && (int) dz == 0 && x == cx + 3 && z == cz) s.chest(x, BASE_Y + 1, z, loot("zona_3"), TelarNoise.mix(x, z, 7));
            return;
        }
        s.set(x, BASE_Y, z, h < 0.12 ? Blocks.SOUL_SAND.defaultBlockState() : (h < 0.5 ? Blocks.BASALT.defaultBlockState() : Blocks.BLACKSTONE.defaultBlockState()));
        if (d <= 17.5) {
            boolean puerta = Math.abs(dx) <= 2.5 || Math.abs(dz) <= 2.5;
            if (!puerta) relleno(s, x, z, BASE_Y + 1, BASE_Y + 3, Blocks.POLISHED_BLACKSTONE_BRICKS.defaultBlockState());
            return;
        }
        // brasas en las esquinas de la arena
        if (Math.abs(Math.abs(dx) - 19) < 0.6 && Math.abs(Math.abs(dz) - 19) < 0.6) {
            relleno(s, x, z, BASE_Y + 1, BASE_Y + 3, Blocks.POLISHED_BLACKSTONE_WALL.defaultBlockState());
            s.set(x, BASE_Y + 4, z, Blocks.SHROOMLIGHT.defaultBlockState());
            return;
        }
        decorar(s, x, z, BASE_Y, 3, 0.0040, 0.0006);
    }

    // ------------------------------------------------------------------ Zona 4: Río de Ceniza
    private static final int PITCH = 12;

    private static void rio(int x, int z, Sink s) {
        // río de ceniza (caída mortal desde las plataformas)
        for (int y = 28; y <= 35; y++) s.set(x, y, z, Blocks.BASALT.defaultBlockState());
        for (int y = 36; y <= 44; y++) s.set(x, y, z, Blocks.GRAY_CONCRETE_POWDER.defaultBlockState());

        // aterrizaje al final de la zona (une con el puente del Juicio)
        if (x >= 588 && Math.abs(z) <= 7) {
            plataforma(s, x, z, BASE_Y, false);
            return;
        }
        int cellX = Math.floorDiv(x - 450, PITCH), cellZ = Math.floorDiv(z + 96, PITCH);
        int mejorTop = Integer.MIN_VALUE;
        for (int i = cellX - 1; i <= cellX + 1; i++) {
            for (int j = cellZ - 1; j <= cellZ + 1; j++) {
                if (i < 0 || j < 0 || j > 15) continue;
                boolean columna = j == 7 || j == 8;                       // "espina" siempre conectada
                if (!columna && rnd(i, j, 91) >= 0.62) continue;
                double r = columna ? 4.6 + rnd(i, j, 92) * 1.0 : 3.4 + rnd(i, j, 92) * 2.0;
                double cx = 450 + i * PITCH + 6 + (rnd(i, j, 93) - 0.5) * 3;
                double cz = -96 + j * PITCH + 6 + (rnd(i, j, 94) - 0.5) * 3;
                if (i == 0 && columna) { cx = 456; cz = -96 + j * PITCH + 6; r = 5.4; }
                if (Math.hypot(x - cx, z - cz) > r) continue;
                int top = (i == 0 && columna) ? BASE_Y : BASE_Y + (int) Math.round((noise(cx * 0.03, cz * 0.03, 31) - 0.5) * 5);
                mejorTop = Math.max(mejorTop, top);
            }
        }
        if (mejorTop != Integer.MIN_VALUE) plataforma(s, x, z, mejorTop, true);
    }

    private static void plataforma(Sink s, int x, int z, int top, boolean decorar) {
        double h = rnd(x, z, 14);
        for (int y = top - 3; y <= top; y++) {
            s.set(x, y, z, y == top ? (h < 0.15 ? Blocks.BLACKSTONE.defaultBlockState() : Blocks.SMOOTH_BASALT.defaultBlockState())
                    : Blocks.BASALT.defaultBlockState());
        }
        if (decorar) decorar(s, x, z, top, 4, 0.012, 0.0025);
    }

    // ------------------------------------------------------------------ Zona 5: Juicio del Telar
    private static final int[][] PILARES = new int[8][];
    private static final int[][] COFRES = new int[4][];
    private static final int[][] LAGRIMAS = new int[16][];

    static {
        for (int k = 0; k < 8; k++) {
            double a = k * Math.PI / 4;
            PILARES[k] = new int[]{(int) Math.round(700 + 30 * Math.cos(a)), (int) Math.round(30 * Math.sin(a))};
        }
        for (int k = 0; k < 4; k++) {
            double a = Math.PI / 4 + k * Math.PI / 2;
            COFRES[k] = new int[]{(int) Math.round(700 + 20 * Math.cos(a)), (int) Math.round(20 * Math.sin(a))};
        }
        for (int k = 0; k < 16; k++) {
            double a = k * Math.PI / 8 + Math.PI / 16;
            LAGRIMAS[k] = new int[]{(int) Math.round(700 + 33 * Math.cos(a)), (int) Math.round(33 * Math.sin(a))};
        }
    }

    private static void juicio(int x, int z, Sink s) {
        int az = Math.abs(z);
        double dx = x - TelarZones.JUICIO_X, d = Math.sqrt(dx * dx + (double) z * z);
        BlockState negro = Blocks.BLACKSTONE.defaultBlockState();
        // aterrizaje y puente hacia el arena
        if (x < 612 && az <= 7) {
            plataforma(s, x, z, BASE_Y, false);
            return;
        }
        if (x < 660 && az <= 2) {
            for (int y = BASE_Y - 3; y <= BASE_Y; y++) s.set(x, y, z, y == BASE_Y ? Blocks.POLISHED_BLACKSTONE.defaultBlockState() : negro);
            return;
        }
        if (d > 41) return;
        for (int y = BASE_Y - 6; y < BASE_Y; y++) s.set(x, y, z, Blocks.OBSIDIAN.defaultBlockState());
        BlockState top = d >= 36 && d <= 38 ? Blocks.CRYING_OBSIDIAN.defaultBlockState()
                : (d >= 20 && d < 21 ? Blocks.POLISHED_BLACKSTONE.defaultBlockState() : Blocks.OBSIDIAN.defaultBlockState());
        s.set(x, BASE_Y, z, top);
        if (d <= 7) { // estrado central
            s.set(x, BASE_Y + 1, z, Blocks.POLISHED_BLACKSTONE_BRICKS.defaultBlockState());
            if (d <= 2.2) relleno(s, x, z, BASE_Y + 2, BASE_Y + 3, Blocks.CHISELED_POLISHED_BLACKSTONE.defaultBlockState());
        }
        if (d > 39 && !(dx < 0 && az <= 4)) s.set(x, BASE_Y + 1, z, Blocks.POLISHED_BLACKSTONE_BRICKS.defaultBlockState());
        for (int[] p : PILARES) {
            if (Math.hypot(x - p[0], z - p[1]) <= 1.5) {
                relleno(s, x, z, BASE_Y + 1, BASE_Y + 14, Blocks.POLISHED_BLACKSTONE_BRICKS.defaultBlockState());
                s.set(x, BASE_Y + 15, z, Blocks.SHROOMLIGHT.defaultBlockState());
                return;
            }
        }
        for (int[] c : COFRES) if (x == c[0] && z == c[1]) s.chest(x, BASE_Y + 1, z, loot("zona_5"), TelarNoise.mix(x, z, 8));
        for (int[] l : LAGRIMAS) if (x == l[0] && z == l[1]) s.set(x, BASE_Y + 1, z, ModBlocks.VETA.defaultBlockState());
    }
}
