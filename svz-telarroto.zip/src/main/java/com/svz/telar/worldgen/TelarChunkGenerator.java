package com.svz.telar.worldgen;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.LevelHeightAccessor;
import net.minecraft.world.level.NoiseColumn;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.biome.BiomeManager;
import net.minecraft.world.level.biome.BiomeSource;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.blending.Blender; // ← CAMBIO: subpaquete correcto
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.RandomState;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.server.level.WorldGenRegion;

import java.util.List;
import java.util.concurrent.CompletableFuture;

/**
 * Chunk generator propio del Telar Roto. Rellena cada columna con {@link TelarTerrain}.
 */
public class TelarChunkGenerator extends ChunkGenerator {
    public static final MapCodec<TelarChunkGenerator> CODEC = RecordCodecBuilder.mapCodec(i -> i.group(
            BiomeSource.CODEC.fieldOf("biome_source").forGetter(g -> g.getBiomeSource())
    ).apply(i, i.stable(TelarChunkGenerator::new)));

    public TelarChunkGenerator(BiomeSource biomeSource) {
        super(biomeSource);
    }

    protected MapCodec<? extends ChunkGenerator> codec() {
        return CODEC;
    }

    // ✅ RESTAURADO: el parámetro Blender vuelve a estar
    public CompletableFuture<ChunkAccess> fillFromNoise(Blender blender, RandomState randomState,
                                                        StructureManager structureManager, ChunkAccess chunk) {
        Heightmap oceanFloor = chunk.getOrCreateHeightmapUnprimed(Heightmap.Types.OCEAN_FLOOR_WG);
        Heightmap surface = chunk.getOrCreateHeightmapUnprimed(Heightmap.Types.WORLD_SURFACE_WG);
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        int x0 = chunk.getPos().getMinBlockX(), z0 = chunk.getPos().getMinBlockZ();

        TelarTerrain.Sink sink = new TelarTerrain.Sink() {
            @Override
            public void set(int x, int y, int z, BlockState state) {
                if (y < 0 || y > 255) return;
                pos.set(x, y, z);
                chunk.setBlockState(pos, state, 0);
                oceanFloor.update(x & 15, y, z & 15, state);
                surface.update(x & 15, y, z & 15, state);
            }

            @Override
            public void chest(int x, int y, int z, ResourceKey<LootTable> table, long seed) {
                BlockState st = Blocks.CHEST.defaultBlockState().setValue(ChestBlock.FACING, Direction.NORTH);
                set(x, y, z, st);
                ChestBlockEntity be = new ChestBlockEntity(new BlockPos(x, y, z), st);
                be.setLootTable(table);
                be.setLootTableSeed(seed);
                chunk.setBlockEntity(be);
            }
        };
        for (int lx = 0; lx < 16; lx++) {
            for (int lz = 0; lz < 16; lz++) TelarTerrain.columna(x0 + lx, z0 + lz, sink);
        }
        return CompletableFuture.completedFuture(chunk);
    }

    public void applyCarvers(WorldGenRegion region, long seed, RandomState randomState, BiomeManager biomeManager,
                             StructureManager structureManager, ChunkAccess chunk) {
    }

    public void buildSurface(WorldGenRegion region, StructureManager structureManager, RandomState randomState, ChunkAccess chunk) {
    }

    /** Sin mobs de generación: los espectros los gestiona SVZ-Mobs. */
    public void spawnOriginalMobs(WorldGenRegion region) {
    }

    public int getGenDepth() {
        return 256;
    }

    public int getSeaLevel() {
        return 0;
    }

    public int getMinY() {
        return 0;
    }

    public int getBaseHeight(int x, int z, Heightmap.Types type, LevelHeightAccessor level, RandomState randomState) {
        return TelarZones.BASE_Y + 1;
    }

    public NoiseColumn getBaseColumn(int x, int z, LevelHeightAccessor level, RandomState randomState) {
        BlockState[] estados = new BlockState[TelarZones.BASE_Y + 1];
        for (int i = 0; i < estados.length; i++) estados[i] = Blocks.STONE.defaultBlockState();
        return new NoiseColumn(0, estados);
    }

    public void addDebugScreenInfo(List<String> info, RandomState randomState, BlockPos pos) {
        info.add("Telar Roto - zona " + TelarZones.zona(pos.getX()));
    }
}