package com.svz.telar.worldgen;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.WorldGenRegion;
import net.minecraft.world.level.LevelHeightAccessor;
import net.minecraft.world.level.NoiseColumn;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.biome.BiomeManager;
import net.minecraft.world.level.biome.BiomeSource;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.RandomState;
import net.minecraft.world.level.levelgen.blending.Blender;
import net.minecraft.world.level.storage.loot.LootTable;

import java.util.List;
import java.util.concurrent.CompletableFuture;

/**
 * Generador de chunks del Telar Roto.
 * Genera el terreno mediante TelarTerrain.
 */
public class TelarChunkGenerator extends ChunkGenerator {

    public static final MapCodec<TelarChunkGenerator> CODEC =
            RecordCodecBuilder.mapCodec(instance ->
                    instance.group(
                            BiomeSource.CODEC
                                    .fieldOf("biome_source")
                                    .forGetter(TelarChunkGenerator::getBiomeSource)
                    ).apply(instance, instance.stable(TelarChunkGenerator::new))
            );

    public TelarChunkGenerator(BiomeSource biomeSource) {
        super(biomeSource);
    }

    @Override
    protected MapCodec<? extends ChunkGenerator> codec() {
        return CODEC;
    }

    @Override
    public CompletableFuture<ChunkAccess> fillFromNoise(
            Blender blender,
            RandomState randomState,
            StructureManager structureManager,
            ChunkAccess chunk
    ) {
        Heightmap oceanFloor =
                chunk.getOrCreateHeightmapUnprimed(Heightmap.Types.OCEAN_FLOOR_WG);

        Heightmap surface =
                chunk.getOrCreateHeightmapUnprimed(Heightmap.Types.WORLD_SURFACE_WG);

        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();

        int x0 = chunk.getPos().getMinBlockX();
        int z0 = chunk.getPos().getMinBlockZ();

        TelarTerrain.Sink sink = new TelarTerrain.Sink() {

            @Override
            public void set(int x, int y, int z, BlockState state) {
                if (y < chunk.getMinY() || y >= chunk.getMaxY()) {
                    return;
                }

                pos.set(x, y, z);

                chunk.setBlockState(pos, state, 0);

                oceanFloor.update(x & 15, y, z & 15, state);
                surface.update(x & 15, y, z & 15, state);
            }

            @Override
            public void chest(
                    int x,
                    int y,
                    int z,
                    ResourceKey<LootTable> table,
                    long seed
            ) {
                BlockState state = Blocks.CHEST.defaultBlockState()
                        .setValue(ChestBlock.FACING, Direction.NORTH);

                set(x, y, z, state);

                BlockPos chestPos = new BlockPos(x, y, z);
                ChestBlockEntity chestEntity =
                        new ChestBlockEntity(chestPos, state);

                chestEntity.setLootTable(table);
                chestEntity.setLootTableSeed(seed);

                chunk.setBlockEntity(chestEntity);
            }
        };

        for (int localX = 0; localX < 16; localX++) {
            for (int localZ = 0; localZ < 16; localZ++) {
                TelarTerrain.columna(
                        x0 + localX,
                        z0 + localZ,
                        sink
                );
            }
        }

        return CompletableFuture.completedFuture(chunk);
    }

    @Override
    public void applyCarvers(
            WorldGenRegion region,
            long seed,
            RandomState randomState,
            BiomeManager biomeManager,
            StructureManager structureManager,
            ChunkAccess chunk
    ) {
        // El Telar Roto no utiliza cuevas ni carvers vanilla.
    }

    @Override
    public void buildSurface(
            WorldGenRegion region,
            StructureManager structureManager,
            RandomState randomState,
            ChunkAccess chunk
    ) {
        // El terreno se genera directamente en fillFromNoise.
    }

    @Override
    public void spawnOriginalMobs(WorldGenRegion region) {
        // El Telar Roto no genera mobs vanilla durante la generación.
        // Los mobs propios de SVZ se gestionan por separado.
    }

    @Override
    public int getGenDepth() {
        return 256;
    }

    @Override
    public int getSeaLevel() {
        return 0;
    }

    @Override
    public int getMinY() {
        return 0;
    }

    @Override
    public int getBaseHeight(
            int x,
            int z,
            Heightmap.Types type,
            LevelHeightAccessor level,
            RandomState randomState
    ) {
        return TelarZones.BASE_Y + 1;
    }

    @Override
    public NoiseColumn getBaseColumn(
            int x,
            int z,
            LevelHeightAccessor level,
            RandomState randomState
    ) {
        BlockState[] states = new BlockState[TelarZones.BASE_Y + 1];

        for (int y = 0; y < states.length; y++) {
            states[y] = Blocks.STONE.defaultBlockState();
        }

        return new NoiseColumn(0, states);
    }

    @Override
    public void addDebugScreenInfo(
            List<String> info,
            RandomState randomState,
            BlockPos pos
    ) {
        info.add("Telar Roto - zona " + TelarZones.zona(
                pos.getX()
        ));
    }
}