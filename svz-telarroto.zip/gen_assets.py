#!/usr/bin/env python3
"""Genera texturas, modelos, lang, loot tables, recetas y la dimensión de SVZ-TelarRoto."""
import json, os, random
from PIL import Image
M = "svz-telarroto"
R = os.path.dirname(os.path.abspath(__file__))
A = f"{R}/src/main/resources/assets/{M}"
D = f"{R}/src/main/resources/data/{M}"
for d in ("textures/block","textures/item","models/block","models/item","items","blockstates","lang"):
    os.makedirs(f"{A}/{d}", exist_ok=True)

def w(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    json.dump(obj, open(path, "w"), indent=2, ensure_ascii=False)

# ---------------------------------------------------------------- texturas
def altar():
    rnd = random.Random(1); im = Image.new("RGBA", (16, 16))
    for x in range(16):
        for y in range(16):
            v = rnd.randint(-8, 8); c = (34 + v, 22 + v, 52 + v)
            if x in (0, 15) or y in (0, 15): c = (70, 45, 95)
            im.putpixel((x, y), c + (255,))
    for i in range(1, 15):                      # hilos rojos en X
        im.putpixel((i, i), (205, 35, 50, 255)); im.putpixel((15 - i, i), (205, 35, 50, 255))
    for (x, y) in [(7, 7), (8, 7), (7, 8), (8, 8), (7, 4), (8, 4), (7, 11), (8, 11), (4, 7), (4, 8), (11, 7), (11, 8)]:
        im.putpixel((x, y), (110, 225, 240, 255))
    im.save(f"{A}/textures/block/altar_del_tejedor.png")

def veta():
    rnd = random.Random(2); im = Image.new("RGBA", (16, 16))
    for x in range(16):
        for y in range(16):
            v = rnd.randint(-10, 10); im.putpixel((x, y), (60 + v, 58 + v, 68 + v, 255))
    for _ in range(9):
        x, y = rnd.randint(1, 14), rnd.randint(1, 14)
        im.putpixel((x, y), (110, 225, 240, 255)); im.putpixel((x + 1, y), (60, 160, 190, 255))
    for i in range(3, 13):
        if rnd.random() < .6: im.putpixel((i, 8 + (i % 3)), (205, 35, 50, 255))
    im.save(f"{A}/textures/block/veta_del_telar.png")

def hilo():
    im = Image.new("RGBA", (16, 16), (0, 0, 0, 0)); import math
    for i in range(15):
        x = 1 + i; y = int(round(13 - i * .8 + 1.6 * math.sin(i * .8)))
        for dx in (0, 1): im.putpixel((x + dx if x + dx < 16 else x, max(0, min(15, y))), (255, 240, 200, 255))
        if 0 <= y + 1 < 16: im.putpixel((x, y + 1), (230, 190, 90, 255))
    for p in [(2, 2), (13, 3), (3, 12), (12, 13)]: im.putpixel(p, (110, 225, 240, 255))
    # contorno
    out = im.copy()
    for x in range(16):
        for y in range(16):
            if im.getpixel((x, y))[3] == 0 and any(0 <= x + dx < 16 and 0 <= y + dy < 16 and im.getpixel((x + dx, y + dy))[3] for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1))):
                out.putpixel((x, y), (90, 60, 30, 255))
    out.save(f"{A}/textures/item/hilo_del_alma.png")
altar(); veta(); hilo()

# ---------------------------------------------------------------- modelos
for b in ("altar_del_tejedor", "veta_del_telar"):
    w(f"{A}/blockstates/{b}.json", {"variants": {"": {"model": f"{M}:block/{b}"}}})
    w(f"{A}/models/block/{b}.json", {"parent": "minecraft:block/cube_all", "textures": {"all": f"{M}:block/{b}"}})
    w(f"{A}/items/{b}.json", {"model": {"type": "minecraft:model", "model": f"{M}:block/{b}"}})
w(f"{A}/models/item/hilo_del_alma.json", {"parent": "minecraft:item/generated", "textures": {"layer0": f"{M}:item/hilo_del_alma"}})
w(f"{A}/items/hilo_del_alma.json", {"model": {"type": "minecraft:model", "model": f"{M}:item/hilo_del_alma"}})

lang = {f"block.{M}.altar_del_tejedor": "Altar del Tejedor", f"block.{M}.veta_del_telar": "Veta del Telar",
        f"item.{M}.hilo_del_alma": "Hilo del Alma",
        f"item.{M}.hilo_del_alma.tooltip": "Úsalo para recuperar 1 hilo del alma."}
for code in ("es_ve", "es_es", "es_mx", "es_ar", "en_us"): w(f"{A}/lang/{code}.json", lang)

# ---------------------------------------------------------------- datos
w(f"{D}/dimension/telar_roto.json", {
    "type": "minecraft:the_nether",   # tipo vanilla: sin cielo, luz tenue, niebla del bioma
    "generator": {"type": f"{M}:telar",
                  "biome_source": {"type": "minecraft:fixed", "biome": "minecraft:crimson_forest"}}})
w(f"{R}/src/main/resources/data/minecraft/tags/block/mineable/pickaxe.json",
  {"replace": False, "values": [f"{M}:altar_del_tejedor", f"{M}:veta_del_telar"]})
w(f"{D}/loot_table/blocks/altar_del_tejedor.json", {
    "type": "minecraft:block", "random_sequence": f"{M}:blocks/altar_del_tejedor",
    "pools": [{"rolls": 1, "conditions": [{"condition": "minecraft:survives_explosion"}],
               "entries": [{"type": "minecraft:item", "name": f"{M}:altar_del_tejedor"}]}]})
w(f"{D}/recipe/altar_del_tejedor.json", {
    "type": "minecraft:crafting_shaped", "category": "misc", "pattern": ["OHO", "ONO", "OOO"],
    "key": {"O": "minecraft:obsidian", "H": "svz-items:hilo_rojo", "N": "svz-items:nudo_rojo"},
    "result": {"id": f"{M}:altar_del_tejedor", "count": 1}})

def it(name, wgt, mn=1, mx=1):
    e = {"type": "minecraft:item", "name": name if ":" in name else f"svz-items:{name}", "weight": wgt}
    if mx > 1: e["functions"] = [{"function": "minecraft:set_count", "count": {"min": mn, "max": mx}}]
    return e
def plano(titulo, recetas, wgt):
    return {"type": "minecraft:item", "name": "minecraft:knowledge_book", "weight": wgt, "functions": [{
        "function": "minecraft:set_components", "components": {
            "minecraft:recipes": [f"svz-items:{r}" for r in recetas],
            "minecraft:custom_name": {"text": f"Plano: {titulo}", "italic": False, "color": "aqua"}}}]}
def cofre(nombre, entries, rolls=(3, 6)):
    w(f"{D}/loot_table/chests/{nombre}.json", {"type": "minecraft:chest",
      "pools": [{"rolls": {"min": rolls[0], "max": rolls[1]}, "entries": entries}]})

cofre("zona_1", [it("hilo_espectral", 10, 1, 3), it("maiz_olvidado", 4, 1, 2), it("metal_olvidado", 4, 1, 2),
                 it("minecraft:bread", 6, 1, 3), it("minecraft:iron_ingot", 5, 1, 3), it("hilo_de_anclaje", 1),
                 plano("Arepa Espectral", ["arepa_espectral"], 3), plano("Tequeño de Hilo", ["tequeno_de_hilo"], 3)])
cofre("zona_2", [it("hilo_espectral", 6, 1, 3), it("nudo_de_alma", 10, 1, 3), it("maiz_olvidado", 4, 1, 2), it("metal_olvidado", 4, 1, 2),
                 it("minecraft:golden_apple", 1), it("hilo_de_cofre", 2),
                 plano("Cachapa de los Caídos", ["cachapa_de_los_caidos"], 3), plano("Hacha Espectral", ["hacha_espectral"], 3)])
cofre("zona_3", [it("nudo_de_alma", 6, 1, 3), it("ceniza_de_titere", 10, 1, 3), it("maiz_olvidado", 5, 1, 3), it("metal_olvidado", 5, 1, 3),
                 it("minecraft:diamond", 2, 1, 2), it("hilo_de_cofre", 3), it("hilo_resurreccion_menor", 1),
                 plano("Pabellón del Más Allá", ["pabellon_del_mas_alla"], 3), plano("Machete de Alma", ["machete_de_alma"], 3)])
cofre("zona_4", [it("ceniza_de_titere", 6, 1, 3), it("tela_de_difunto", 10, 1, 3), it("maiz_olvidado", 5, 1, 3), it("metal_olvidado", 5, 1, 3),
                 it("minecraft:netherite_scrap", 1), it("hilo_de_vida", 2), it("hilo_resurreccion_mayor", 1),
                 plano("Hallaca Eterna", ["hallaca_eterna"], 3), plano("Lanza del Más Allá", ["lanza_del_mas_alla"], 3),
                 plano("Martillo de Nudos", ["martillo_de_nudos"], 3)])
cofre("zona_5", [it("lagrima_de_tejedor", 10, 1, 3), it("tela_de_difunto", 5, 1, 3), it("maiz_olvidado", 6, 2, 4), it("metal_olvidado", 6, 2, 4),
                 it("hilo_de_vida", 4), it("hilo_resurreccion_perfecto", 2), it("nucleo_de_hilo", 4), it("minecraft:netherite_ingot", 1),
                 plano("Banquete del Segundo Hilo", ["banquete_del_segundo_hilo"], 4), plano("Filo del Segundo Hilo", ["filo_del_segundo_hilo"], 4),
                 plano("Armadura del Tejedor", ["casco_del_tejedor", "peto_del_tejedor", "pantalones_del_tejedor", "botas_del_tejedor"], 4)], (4, 7))
cofre("juicio", [it("lagrima_de_tejedor", 10, 4, 8), it("nucleo_de_hilo", 8, 2, 4), it("hilo_de_vida", 5, 1, 2),
                 it("hilo_resurreccion_perfecto", 3), it("minecraft:netherite_ingot", 3, 1, 2), it("minecraft:diamond", 6, 3, 6)], (5, 8))
print("ok")
