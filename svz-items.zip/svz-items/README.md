# SVZ-Items (svz-items)
Ítems, comidas, armas y armaduras de Sobreviviendo a Venezuela. MC 1.21.11 · Fabric · Java 21. Requiere SVZ-Core.

## Compilar
1. Compila SVZ-Core y copia su jar a `libs/svz-core-1.0.0.jar` (usa el svz-core.zip actualizado).
2. `gradle wrapper && ./gradlew build`

## Regenerar texturas / recetas / lang
    python3 gen_assets.py     (necesita Pillow)
Edita ese script para cambiar texturas, textos o recetas.

## Contrato con otros mods
- SVZ-Mobs: marca a sus poseídos con el tag de entidad `svz_poseido` y llama a
  `SVZItemsAPI.consumirAnclaje(player)` antes de generar un Espectro Títere.
- El Telar Roto debe existir como dimensión (por defecto `svzcore:telar_roto`, o la que registres
  con `SVZCoreAPI.setTelarRotoDimension`). La Vela de Ánima te lleva allí.
- Recetas en `data/svz-items/recipe/` (en 1.21.x la carpeta es singular).
