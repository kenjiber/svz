package com.svz.items.api;

import com.svz.items.item.ModItems;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * API pública de SVZ-Items para SVZ-Mobs y otros mods.
 */
public final class SVZItemsAPI {
    private SVZItemsAPI() {}

    /** Etiqueta de entidad (/tag) que identifica a un mob poseído. SVZ-Mobs debe añadirla a sus poseídos. */
    public static final String TAG_POSEIDO = "svz_poseido";

    /** Otros mods añaden texto al Espejo de Forja (p. ej. la fase de posesión). Devuelve null si no aplica. */
    public static final java.util.List<java.util.function.Function<LivingEntity, String>> INSPECTORES =
            new java.util.concurrent.CopyOnWriteArrayList<>();

    private static final Map<UUID, Long> RESISTENCIA = new ConcurrentHashMap<>();

    /** @return {@code true} si el jugador lleva un Hilo de Anclaje en el inventario. */
    public static boolean tieneAnclaje(ServerPlayer player) {
        Inventory inv = player.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            if (inv.getItem(i).is(ModItems.HILO_ANCLAJE)) return true;
        }
        return false;
    }

    /**
     * Consume un Hilo de Anclaje si el jugador lo lleva. SVZ-Mobs debe llamar a esto antes de
     * generar un Espectro Títere: si devuelve {@code true}, el espectro NO debe aparecer.
     */
    public static boolean consumirAnclaje(ServerPlayer player) {
        Inventory inv = player.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack s = inv.getItem(i);
            if (s.is(ModItems.HILO_ANCLAJE)) {
                s.shrink(1);
                return true;
            }
        }
        return false;
    }

    /** Da resistencia al control: durante {@code ticks} el drenaje de hilos del alma se revierte. */
    public static void darResistenciaControl(ServerPlayer player, int ticks) {
        RESISTENCIA.put(player.getUUID(), player.level().getGameTime() + ticks);
    }

    /** @return {@code true} si el jugador tiene resistencia al control activa. */
    public static boolean tieneResistenciaControl(ServerPlayer player) {
        Long hasta = RESISTENCIA.get(player.getUUID());
        return hasta != null && player.level().getGameTime() < hasta;
    }

    /** @return {@code true} si la entidad lleva la etiqueta de poseído. */
    public static boolean esMobPoseido(LivingEntity entity) {
        return entity.getTags().contains(TAG_POSEIDO);
    }
}
