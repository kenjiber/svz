package com.svz.items.item;

import com.svz.core.api.SVZClass;
import com.svz.core.api.SVZCoreAPI;
import com.svz.items.SVZItemsMod;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * Ítem genérico de SVZ con acción al usar en el aire y/o sobre una entidad.
 * Verifica dimensión (Telar Roto) y clase (Guerrero) antes de ejecutar.
 */
public class SVZItem extends Item {
    @FunctionalInterface
    public interface UseAction {
        InteractionResult run(ServerLevel level, ServerPlayer player, InteractionHand hand, ItemStack stack);
    }

    @FunctionalInterface
    public interface TargetAction {
        InteractionResult run(ServerPlayer user, LivingEntity target, ItemStack stack);
    }

    private final UseAction onUse;
    private final TargetAction onTarget;
    private final boolean telarOnly;
    private final boolean guerreroOnly;

    public SVZItem(Properties props, UseAction onUse, TargetAction onTarget, boolean telarOnly, boolean guerreroOnly) {
        super(props);
        this.onUse = onUse;
        this.onTarget = onTarget;
        this.telarOnly = telarOnly;
        this.guerreroOnly = guerreroOnly;
    }

    private boolean permitido(ServerPlayer sp) {
        if (telarOnly && !SVZCoreAPI.isInTelarRoto(sp)) {
            sp.displayClientMessage(Component.translatable(SVZItemsMod.MOD_ID + ".msg.solo_telar"), true);
            return false;
        }
        if (guerreroOnly && SVZCoreAPI.getClase(sp) != SVZClass.GUERRERO) {
            sp.displayClientMessage(Component.translatable(SVZItemsMod.MOD_ID + ".msg.solo_guerrero"), true);
            return false;
        }
        return true;
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (onUse == null) return super.use(level, player, hand);
        if (!(level instanceof ServerLevel sl) || !(player instanceof ServerPlayer sp)) return InteractionResult.SUCCESS;
        if (!permitido(sp)) return InteractionResult.FAIL;
        return onUse.run(sl, sp, hand, player.getItemInHand(hand));
    }

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player player, LivingEntity target, InteractionHand hand) {
        if (onTarget == null) return super.interactLivingEntity(stack, player, target, hand);
        if (!(player instanceof ServerPlayer sp)) return InteractionResult.SUCCESS;
        if (!permitido(sp)) return InteractionResult.FAIL;
        return onTarget.run(sp, target, stack);
    }
}
