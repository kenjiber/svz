package com.svz.items.item;

import com.svz.core.api.SVZCoreAPI;
import com.svz.items.SVZItemsMod;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Comida con efecto personalizado. Las olvidadas solo se pueden comer en el Telar Roto. */
public class SVZFood extends Item {
    @FunctionalInterface
    public interface Effect {
        void apply(ServerLevel level, ServerPlayer player);
    }

    private final Effect effect;
    private final boolean telarOnly;

    public SVZFood(Properties props, Effect effect, boolean telarOnly) {
        super(props);
        this.effect = effect;
        this.telarOnly = telarOnly;
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (telarOnly && player instanceof ServerPlayer sp && !SVZCoreAPI.isInTelarRoto(sp)) {
            sp.displayClientMessage(Component.translatable(SVZItemsMod.MOD_ID + ".msg.solo_telar"), true);
            return InteractionResult.FAIL;
        }
        return super.use(level, player, hand);
    }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity entity) {
        ItemStack result = super.finishUsingItem(stack, level, entity);
        if (effect != null && level instanceof ServerLevel sl && entity instanceof ServerPlayer sp) {
            if (!telarOnly || SVZCoreAPI.isInTelarRoto(sp)) effect.apply(sl, sp);
        }
        return result;
    }
}
