package com.svz.items.item;

import com.svz.core.api.SVZCoreAPI;
import com.svz.core.logic.SVZEventHandlers;
import com.svz.items.SVZItemsMod;
import com.svz.items.api.SVZItemsAPI;
import net.minecraft.core.Holder;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Relative;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;

import java.util.List;
import java.util.Set;

/** Comportamientos de los ítems y comidas de SVZ. */
public final class SVZActions {
    private SVZActions() {}

    // ------------------------------------------------------------ utilidades
    public static boolean esMarcado(LivingEntity e) {
        return (e instanceof ServerPlayer sp && SVZCoreAPI.isPoseido(sp))
                || SVZItemsAPI.esMobPoseido(e)
                || e.getType().is(SVZEventHandlers.DRENA_HILOS);
    }

    private static void consumir(ServerPlayer p, ItemStack s) {
        if (!p.getAbilities().instabuild) s.shrink(1);
    }

    private static void msg(ServerPlayer p, String texto, boolean actionBar) {
        p.displayClientMessage(Component.literal(texto), actionBar);
    }

    public static void particulas(LivingEntity t, ParticleOptions part, int n) {
        if (t.level() instanceof ServerLevel sl) sl.sendParticles(part, t.getX(), t.getY(0.5), t.getZ(), n, 0.3, 0.3, 0.3, 0.02);
    }

    public static MobEffectInstance e(Holder<MobEffect> eff, int segundos, int amp) {
        return new MobEffectInstance(eff, segundos * 20, amp);
    }

    // ------------------------------------------------------------ efectos de comida
    public static SVZFood.Effect efectos(MobEffectInstance... lista) {
        return (lvl, p) -> {
            for (MobEffectInstance i : lista) p.addEffect(new MobEffectInstance(i));
        };
    }

    public static SVZFood.Effect y(SVZFood.Effect a, SVZFood.Effect b) {
        return (lvl, p) -> {
            a.apply(lvl, p);
            b.apply(lvl, p);
        };
    }

    public static SVZFood.Effect restauraHiloVida(int cantidad) {
        return (lvl, p) -> SVZCoreAPI.setHiloVidaInterno(p, SVZCoreAPI.getHiloVidaInterno(p) + cantidad);
    }

    public static SVZFood.Effect resistenciaControl(int segundos) {
        return (lvl, p) -> SVZItemsAPI.darResistenciaControl(p, segundos * 20);
    }

    public static final SVZFood.Effect LIMPIA_EFECTOS = (lvl, p) -> p.removeAllEffects();

    /** Café de los Andes: despierta (libera) a un poseído. */
    public static final SVZFood.Effect DESPIERTA = (lvl, p) -> {
        if (SVZCoreAPI.isPoseido(p)) {
            SVZCoreAPI.setPoseido(p, false);
            if (SVZCoreAPI.getHilos(p) < 1) SVZCoreAPI.setHilos(p, 1);
            msg(p, "Despiertas. El hilo te suelta.", true);
        }
    };

    /** Plato del Segundo Hilo: revive el alma sin pasar por el Telar. */
    public static final SVZFood.Effect SEGUNDO_HILO = (lvl, p) -> {
        if (SVZCoreAPI.isPoseido(p)) SVZCoreAPI.setPoseido(p, false);
        if (SVZCoreAPI.getHilos(p) < 3) SVZCoreAPI.setHilos(p, 3);
        msg(p, "Tu alma recupera el segundo hilo.", true);
    };

    /** Banquete Criollo: buff en área y +1 hilo del alma. */
    public static final SVZFood.Effect BANQUETE_CRIOLLO = (lvl, p) -> {
        for (ServerPlayer o : lvl.getEntitiesOfClass(ServerPlayer.class, p.getBoundingBox().inflate(8))) {
            o.addEffect(e(MobEffects.REGENERATION, 30, 0));
            o.addEffect(e(MobEffects.STRENGTH, 60, 0));
            o.addEffect(e(MobEffects.RESISTANCE, 60, 0));
            SVZCoreAPI.addHilos(o, 1);
        }
    };

    /** Banquete del Segundo Hilo (Telar): Hilo de Vida interno al máximo para los aliados cercanos. */
    public static final SVZFood.Effect BANQUETE_SEGUNDO_HILO = (lvl, p) -> {
        for (ServerPlayer o : lvl.getEntitiesOfClass(ServerPlayer.class, p.getBoundingBox().inflate(8))) {
            if (!SVZCoreAPI.isInTelarRoto(o)) continue;
            SVZCoreAPI.setHiloVidaInterno(o, 100);
            o.addEffect(e(MobEffects.REGENERATION, 30, 1));
        }
    };

    // ------------------------------------------------------------ armas
    public static SVZWeapon.OnHit vsMarcados(MobEffectInstance... lista) {
        return (s, t, a) -> {
            if (esMarcado(t)) for (MobEffectInstance i : lista) t.addEffect(new MobEffectInstance(i));
        };
    }

    public static SVZWeapon.OnHit siempre(ParticleOptions part, MobEffectInstance... lista) {
        return (s, t, a) -> {
            particulas(t, part, 8);
            for (MobEffectInstance i : lista) t.addEffect(new MobEffectInstance(i));
        };
    }

    public static SVZWeapon.OnHit robaVida(float cantidad, ParticleOptions part) {
        return (s, t, a) -> {
            a.heal(cantidad);
            particulas(t, part, 6);
        };
    }

    /** Filo Oscuro: roba vida; 20% de costar 1 hilo del alma (nunca el último). */
    public static final SVZWeapon.OnHit FILO_OSCURO = (s, t, a) -> {
        a.heal(1.0F);
        particulas(t, ParticleTypes.SOUL, 6);
        if (a instanceof ServerPlayer sp && a.getRandom().nextFloat() < 0.2F && SVZCoreAPI.getHilos(sp) > 1) {
            SVZCoreAPI.removeHilos(sp, 1);
            msg(sp, "El filo se cobra un hilo de tu alma...", true);
        }
    };

    // ------------------------------------------------------------ ítems especiales
    /** Vela de Ánima: abre un portal (teletransporte) al Telar Roto. */
    /** La Vela ya no teletransporta: se enciende sobre el Altar del Tejedor (SVZ-TelarRoto). */
    public static InteractionResult vela(ServerLevel level, ServerPlayer p, InteractionHand hand, ItemStack stack) {
        p.displayClientMessage(Component.literal("Enciende la Vela sobre el Altar del Tejedor."), true);
        return InteractionResult.FAIL;
    }

    /** Teletransporte directo antiguo (sin uso). */
    public static InteractionResult velaDirecta(ServerLevel level, ServerPlayer p, InteractionHand hand, ItemStack stack) {
        if (SVZCoreAPI.isInTelarRoto(p)) {
            p.displayClientMessage(Component.translatable(SVZItemsMod.MOD_ID + ".msg.ya_telar"), true);
            return InteractionResult.FAIL;
        }
        MinecraftServer server = level.getServer();
        ServerLevel telar = null;
        for (ResourceKey<Level> k : server.levelKeys()) {
            if (SVZCoreAPI.isTelarRoto(k)) telar = server.getLevel(k);
        }
        if (telar == null) {
            p.displayClientMessage(Component.translatable(SVZItemsMod.MOD_ID + ".msg.telar_ausente"), true);
            return InteractionResult.FAIL;
        }
        particulas(p, ParticleTypes.SOUL_FIRE_FLAME, 20);
        int y = telar.getHeight(Heightmap.Types.MOTION_BLOCKING, 0, 0);
        p.teleportTo(telar, 0.5, y, 0.5, Set.<Relative>of(), p.getYRot(), p.getXRot(), true);
        SVZCoreAPI.iniciarHiloVidaInterno(p); // idempotente: Core también lo hace al cambiar de dimensión
        consumir(p, stack);
        return InteractionResult.SUCCESS;
    }

    /** Ojo de Títere: resalta las marcas de posesión cercanas. */
    public static InteractionResult ojo(ServerLevel level, ServerPlayer p, InteractionHand hand, ItemStack stack) {
        List<LivingEntity> marcados = level.getEntitiesOfClass(LivingEntity.class,
                p.getBoundingBox().inflate(32), en -> en != p && esMarcado(en));
        for (LivingEntity en : marcados) en.addEffect(new MobEffectInstance(MobEffects.GLOWING, 200, 0, false, false));
        msg(p, marcados.isEmpty() ? "El Ojo no ve marcas cerca." : "El Ojo revela " + marcados.size() + " marca(s) cercana(s).", true);
        p.getCooldowns().addCooldown(stack, 100);
        return InteractionResult.SUCCESS;
    }

    private static String estado(LivingEntity t) {
        String base = estadoBase(t);
        for (var f : SVZItemsAPI.INSPECTORES) {
            String extra = f.apply(t);
            if (extra != null) base += " | " + extra;
        }
        return base;
    }

    private static String estadoBase(LivingEntity t) {
        if (t instanceof ServerPlayer sp) {
            return sp.getName().getString() + ": Hilos " + SVZCoreAPI.getHilos(sp) + "/" + SVZCoreAPI.getMaxHilos(sp)
                    + " | Clase " + SVZCoreAPI.getClase(sp).getSerializedName()
                    + " | " + (SVZCoreAPI.isPoseido(sp) ? "POSEÍDO" : "libre");
        }
        return esMarcado(t) ? "El espejo muestra una posesión en este ser." : "El espejo no muestra posesión alguna.";
    }

    /** Espejo de Forja: en el aire te inspecciona a ti. */
    public static InteractionResult espejoAire(ServerLevel level, ServerPlayer p, InteractionHand hand, ItemStack stack) {
        msg(p, estado(p), false);
        return InteractionResult.SUCCESS;
    }

    /** Espejo de Forja: sobre una entidad la inspecciona. */
    public static InteractionResult espejoObjetivo(ServerPlayer user, LivingEntity t, ItemStack stack) {
        msg(user, estado(t), false);
        return InteractionResult.SUCCESS;
    }

    /** Hilo de Liberación: libera a un poseído (jugador o mob con la etiqueta svz_poseido). */
    public static InteractionResult liberar(ServerPlayer user, LivingEntity t, ItemStack stack) {
        boolean ok = false;
        if (t instanceof ServerPlayer tp && SVZCoreAPI.isPoseido(tp)) {
            SVZCoreAPI.setPoseido(tp, false);
            if (SVZCoreAPI.getHilos(tp) < 3) SVZCoreAPI.setHilos(tp, 3);
            msg(tp, "Un hilo cortado te libera de la posesión.", true);
            ok = true;
        } else if (SVZItemsAPI.esMobPoseido(t)) {
            t.removeTag(SVZItemsAPI.TAG_POSEIDO);
            ok = true;
        }
        if (!ok) {
            user.displayClientMessage(Component.translatable(SVZItemsMod.MOD_ID + ".msg.sin_efecto"), true);
            return InteractionResult.FAIL;
        }
        particulas(t, ParticleTypes.END_ROD, 15);
        consumir(user, stack);
        return InteractionResult.SUCCESS;
    }

    public static InteractionResult liberarAire(ServerLevel level, ServerPlayer p, InteractionHand hand, ItemStack stack) {
        return liberar(p, p, stack);
    }

    // ------------------------------------------------------------ resurrección (nivel 1 menor, 2 mayor, 3 perfecto)
    public static SVZItem.UseAction resurreccionAire(int nivel) {
        return (lvl, p, hand, stack) -> resucitar(p, p, nivel, stack);
    }

    public static SVZItem.TargetAction resurreccionObjetivo(int nivel) {
        return (user, t, stack) -> t instanceof ServerPlayer tp ? resucitar(user, tp, nivel, stack) : InteractionResult.PASS;
    }

    private static InteractionResult resucitar(ServerPlayer user, ServerPlayer t, int nivel, ItemStack stack) {
        int h = SVZCoreAPI.getHilos(t), max = SVZCoreAPI.getMaxHilos(t);
        boolean pos = SVZCoreAPI.isPoseido(t), perm = SVZCoreAPI.isMuertePermanente(t);
        String error = null;
        if (nivel == 1) {
            if (pos) error = "Está poseído: hace falta un hilo mayor.";
            else if (h >= max) error = "Sus hilos ya están completos.";
            else SVZCoreAPI.addHilos(t, 3);
        } else if (nivel == 2) {
            if (!pos && h >= max) error = "Sus hilos ya están completos.";
            else {
                if (pos) SVZCoreAPI.setPoseido(t, false);
                SVZCoreAPI.addHilos(t, 7);
            }
        } else {
            if (perm) error = "Solo el Ritual de Rescate del Telar Roto puede devolver a un muerto permanente.";
            else if (!pos && h >= max) error = "No necesita resurrección.";
            else {
                if (pos) SVZCoreAPI.setPoseido(t, false);
                SVZCoreAPI.setHilos(t, max);
                SVZCoreAPI.setHiloVidaInterno(t, 100);
            }
        }
        if (error != null) {
            msg(user, error, true);
            return InteractionResult.FAIL;
        }
        particulas(t, ParticleTypes.TOTEM_OF_UNDYING, 25);
        msg(t, "Un hilo de resurrección te devuelve el alma.", true);
        consumir(user, stack);
        return InteractionResult.SUCCESS;
    }
}
