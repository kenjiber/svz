package com.svz.items.item;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ToolMaterial;

/** Hacha (conserva el descortezado de troncos) con efecto opcional al golpear. */
public class SVZAxe extends AxeItem {
    private final SVZWeapon.OnHit onHit;

    public SVZAxe(ToolMaterial material, float damage, float speed, Properties props, SVZWeapon.OnHit onHit) {
        super(material, damage, speed, props);
        this.onHit = onHit;
    }

    @Override
    public void postHurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        super.postHurtEnemy(stack, target, attacker);
        if (onHit != null) onHit.hit(stack, target, attacker);
    }
}
