package com.svz.items;

import com.svz.items.item.ModItems;
import com.svz.items.logic.SVZHandlers;
import net.fabricmc.api.ModInitializer;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SVZItemsMod implements ModInitializer {
    public static final String MOD_ID = "svz-items";
    public static final Logger LOGGER = LoggerFactory.getLogger("SVZ-Items");

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModItems.register();
        SVZHandlers.register();
        LOGGER.info("SVZ-Items cargado.");
    }
}
