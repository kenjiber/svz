package com.svz.items.item;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/** Arma (espada/machete/lanza/martillo) con efecto opcional al golpear. */
public class SVZWeapon extends Item {
    @FunctionalInterface
    public interface OnHit {
        void hit(ItemStack stack, LivingEntity target, LivingEntity attacker);
    }

    private final OnHit onHit;

    public SVZWeapon(Properties props, OnHit onHit) {
        super(props);
        this.onHit = onHit;
    }

    @Override
    public void postHurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        super.postHurtEnemy(stack, target, attacker);
        if (onHit != null) onHit.hit(stack, target, attacker);
    }
}
