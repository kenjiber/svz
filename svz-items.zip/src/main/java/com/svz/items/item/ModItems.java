package com.svz.items.item;

import com.svz.items.SVZItemsMod;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.ChatFormatting;
import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Consumables;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.component.BlocksAttacks;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;
import net.minecraft.world.item.equipment.EquipmentAsset;
import net.minecraft.world.item.equipment.EquipmentAssets;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;

import static com.svz.items.item.SVZActions.e;

/** Registro de todos los ítems de SVZ-Items. */
public final class ModItems {
    private ModItems() {}

    // pestañas
    public static final List<Item> MATERIALES = new ArrayList<>();
    public static final List<Item> ESPECIALES = new ArrayList<>();
    public static final List<Item> COMIDAS = new ArrayList<>();
    public static final List<Item> HERRERO = new ArrayList<>();

    /** Ítems con partículas espectrales. */
    public static final Set<Item> ESPECTRALES = new HashSet<>();
    /** Ítems que solo funcionan en el Telar Roto. */
    public static final Set<Item> TELAR_ONLY = new HashSet<>();
    public static final List<Item> ARMADURA_TEJEDOR = new ArrayList<>();

    public static Item HILO_ROJO, HILO_VIDA, HILO_COFRE, HILO_ANCLAJE;

    // flags
    private static final int G = 1;     // brillo (glint)
    private static final int S = 2;     // partículas espectrales
    private static final int T = 4;     // solo Telar Roto
    private static final int W = 8;     // solo Guerrero
    private static final int CHEF = 16; // recurso de Chef
    private static final int HERR = 32; // recurso de Herrero

    // materiales de herramienta
    public static final ToolMaterial COBRE = new ToolMaterial(BlockTags.INCORRECT_FOR_IRON_TOOL, 190, 5.5F, 1.5F, 10, ItemTags.IRON_TOOL_MATERIALS);
    public static final ToolMaterial ACERO = new ToolMaterial(BlockTags.INCORRECT_FOR_IRON_TOOL, 520, 6.5F, 2.5F, 12, ItemTags.IRON_TOOL_MATERIALS);
    public static final ToolMaterial OLVIDADO = new ToolMaterial(BlockTags.INCORRECT_FOR_DIAMOND_TOOL, 1561, 8.0F, 3.5F, 18, ItemTags.IRON_TOOL_MATERIALS);

    // materiales de armadura
    private static ResourceKey<EquipmentAsset> asset(String n) {
        return ResourceKey.create(EquipmentAssets.ROOT_ID, SVZItemsMod.id(n));
    }

    private static ArmorMaterial armadura(int dur, int h, int c, int l, int b, int ench, float tough, float kb, String asset) {
        EnumMap<ArmorType, Integer> m = new EnumMap<>(ArmorType.class);
        m.put(ArmorType.HELMET, h);
        m.put(ArmorType.CHESTPLATE, c);
        m.put(ArmorType.LEGGINGS, l);
        m.put(ArmorType.BOOTS, b);
        m.put(ArmorType.BODY, c);
        return new ArmorMaterial(dur, m, ench, SoundEvents.ARMOR_EQUIP_IRON, tough, kb, ItemTags.REPAIRS_IRON_ARMOR, asset(asset));
    }

    // ------------------------------------------------------------------ registro
    private static Component tip(String key, ChatFormatting color) {
        return Component.translatable(key).withStyle(s -> s.withColor(color).withItalic(false));
    }

    private static Item reg(List<Item> tab, String name, Function<Item.Properties, Item> factory, Item.Properties props, int flags) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, SVZItemsMod.id(name));
        String mod = SVZItemsMod.MOD_ID;
        List<Component> lore = new ArrayList<>();
        lore.add(tip("item." + mod + "." + name + ".tooltip", ChatFormatting.GRAY));
        if ((flags & T) != 0) lore.add(tip(mod + ".tooltip.telar", ChatFormatting.DARK_PURPLE));
        if ((flags & W) != 0) lore.add(tip(mod + ".tooltip.guerrero", ChatFormatting.RED));
        if ((flags & CHEF) != 0) lore.add(tip(mod + ".tooltip.chef", ChatFormatting.GOLD));
        if ((flags & HERR) != 0) lore.add(tip(mod + ".tooltip.herrero", ChatFormatting.GOLD));
        props.component(DataComponents.LORE, new ItemLore(lore));
        if ((flags & G) != 0) props.component(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, true);
        Item item = factory.apply(props.setId(key));
        Registry.register(BuiltInRegistries.ITEM, key, item);
        tab.add(item);
        if ((flags & S) != 0) ESPECTRALES.add(item);
        if ((flags & T) != 0) TELAR_ONLY.add(item);
        return item;
    }

    private static Item simple(List<Item> tab, String name, int flags) {
        return reg(tab, name, Item::new, new Item.Properties(), flags);
    }

    private static Item especial(String name, int flags, SVZItem.UseAction use, SVZItem.TargetAction target, boolean telar, boolean guerrero) {
        return reg(ESPECIALES, name, p -> new SVZItem(p, use, target, telar, guerrero), new Item.Properties().stacksTo(16), flags);
    }

    private static Item comida(String name, int nutricion, float saciedad, boolean bebida, int flags, SVZFood.Effect fx) {
        FoodProperties fp = new FoodProperties.Builder().nutrition(nutricion).saturationModifier(saciedad).alwaysEdible().build();
        Item.Properties props = new Item.Properties();
        props = bebida ? props.food(fp, Consumables.DEFAULT_DRINK) : props.food(fp);
        boolean telar = (flags & T) != 0;
        return reg(COMIDAS, name, p -> new SVZFood(p, fx, telar), props, flags);
    }

    private static Item espada(String name, ToolMaterial m, float dmg, float spd, int flags, SVZWeapon.OnHit hit) {
        return reg(HERRERO, name, p -> new SVZWeapon(p, hit), new Item.Properties().sword(m, dmg, spd), flags);
    }

    private static Item hacha(String name, ToolMaterial m, float dmg, float spd, int flags, SVZWeapon.OnHit hit) {
        return reg(HERRERO, name, p -> new SVZAxe(m, dmg, spd, p, hit), new Item.Properties(), flags);
    }

    private static void armaduraSet(String sufijo, ArmorMaterial mat, int flags, boolean tejedor) {
        String[] piezas = {"casco", "peto", "pantalones", "botas"};
        ArmorType[] tipos = {ArmorType.HELMET, ArmorType.CHESTPLATE, ArmorType.LEGGINGS, ArmorType.BOOTS};
        for (int i = 0; i < 4; i++) {
            Item it = reg(HERRERO, piezas[i] + "_" + sufijo, Item::new, new Item.Properties().humanoidArmor(mat, tipos[i]), flags);
            if (tejedor) ARMADURA_TEJEDOR.add(it);
        }
    }

    /** Escudo: usa el componente blocks_attacks de 1.21.5+ (mismos valores que el escudo vanilla). */
    private static Item.Properties escudoProps() {
        return new Item.Properties().durability(450).equippable(EquipmentSlot.OFFHAND)
                .component(DataComponents.BLOCKS_ATTACKS, new BlocksAttacks(0.25F, 1.0F,
                        List.of(new BlocksAttacks.DamageReduction(90.0F, Optional.empty(), 0.0F, 1.0F)),
                        new BlocksAttacks.ItemDamageFunction(3.0F, 1.0F, 1.0F),
                        Optional.of(DamageTypeTags.BYPASSES_SHIELD),
                        Optional.of(SoundEvents.SHIELD_BLOCK),
                        Optional.of(SoundEvents.SHIELD_BREAK)));
    }

    public static void register() {
        // ---------------- 1. materiales básicos
        HILO_ROJO = simple(MATERIALES, "hilo_rojo", G);
        simple(MATERIALES, "nudo_rojo", G);
        simple(MATERIALES, "nucleo_de_hilo", G);
        simple(MATERIALES, "hilo_negro", G);
        simple(MATERIALES, "hilo_espectral", G | S);
        simple(MATERIALES, "nudo_de_alma", G | S);
        simple(MATERIALES, "ceniza_de_titere", S);
        simple(MATERIALES, "tela_de_difunto", S);
        simple(MATERIALES, "lagrima_de_tejedor", S);
        simple(MATERIALES, "maiz_olvidado", S | CHEF);
        simple(MATERIALES, "metal_olvidado", S | HERR);

        // ---------------- 2. ítems especiales
        HILO_VIDA = reg(ESPECIALES, "hilo_de_vida", Item::new, new Item.Properties().stacksTo(1), G);
        HILO_COFRE = reg(ESPECIALES, "hilo_de_cofre", Item::new, new Item.Properties().stacksTo(1), G);
        especial("hilo_resurreccion_menor", G | W, SVZActions.resurreccionAire(1), SVZActions.resurreccionObjetivo(1), false, true);
        especial("hilo_resurreccion_mayor", G | W, SVZActions.resurreccionAire(2), SVZActions.resurreccionObjetivo(2), false, true);
        especial("hilo_resurreccion_perfecto", G | W, SVZActions.resurreccionAire(3), SVZActions.resurreccionObjetivo(3), false, true);
        HILO_ANCLAJE = simple(ESPECIALES, "hilo_de_anclaje", G);
        especial("hilo_de_liberacion", G, SVZActions::liberarAire, SVZActions::liberar, false, false);
        especial("vela_de_anima", S, SVZActions::vela, null, false, false);
        especial("ojo_de_titere", S, SVZActions::ojo, null, false, false);
        especial("espejo_de_forja", 0, SVZActions::espejoAire, SVZActions::espejoObjetivo, false, false);
        reg(HERRERO, "filo_oscuro", p -> new SVZWeapon(p, SVZActions.FILO_OSCURO),
                new Item.Properties().sword(OLVIDADO, 4.0F, -2.0F), G);

        // ---------------- 3. comidas del Chef
        comida("arepa_basica", 8, 0.8F, false, 0, null);
        comida("cachapa_veloz", 6, 0.6F, false, 0, SVZActions.efectos(e(MobEffects.SPEED, 60, 0)));
        comida("tequeno_de_absorcion", 5, 0.6F, false, 0, SVZActions.efectos(e(MobEffects.ABSORPTION, 120, 1)));
        comida("pabellon_criollo", 10, 0.8F, false, 0,
                SVZActions.efectos(e(MobEffects.STRENGTH, 120, 0), e(MobEffects.RESISTANCE, 120, 0)));
        comida("tizana_de_los_andes", 3, 0.3F, true, 0,
                SVZActions.y(SVZActions.LIMPIA_EFECTOS, SVZActions.efectos(e(MobEffects.NIGHT_VISION, 180, 0))));
        comida("hallaca_legendaria", 10, 0.9F, false, G,
                SVZActions.y(SVZActions.efectos(e(MobEffects.REGENERATION, 20, 1), e(MobEffects.SATURATION, 10, 0)),
                        SVZActions.resistenciaControl(60)));
        comida("pabellon_supremo", 12, 1.0F, false, G,
                SVZActions.efectos(e(MobEffects.STRENGTH, 180, 1), e(MobEffects.RESISTANCE, 180, 1), e(MobEffects.SPEED, 180, 0)));
        comida("banquete_criollo", 14, 1.0F, false, G, SVZActions.BANQUETE_CRIOLLO);
        comida("arepa_de_la_resistencia", 6, 0.7F, false, 0,
                SVZActions.y(SVZActions.resistenciaControl(120), SVZActions.efectos(e(MobEffects.RESISTANCE, 60, 0))));
        comida("cafe_de_los_andes", 2, 0.3F, true, 0,
                SVZActions.y(SVZActions.DESPIERTA, SVZActions.efectos(e(MobEffects.SPEED, 40, 0))));
        comida("plato_del_segundo_hilo", 8, 0.8F, false, G,
                SVZActions.y(SVZActions.SEGUNDO_HILO, SVZActions.efectos(e(MobEffects.REGENERATION, 10, 0))));

        // ---------------- 4. comidas olvidadas (solo Telar Roto)
        comida("arepa_espectral", 6, 0.6F, false, S | T, SVZActions.restauraHiloVida(25));
        comida("cachapa_de_los_caidos", 6, 0.6F, false, S | T,
                SVZActions.y(SVZActions.restauraHiloVida(15), SVZActions.efectos(e(MobEffects.SPEED, 60, 1))));
        comida("tequeno_de_hilo", 5, 0.6F, false, S | T,
                SVZActions.y(SVZActions.restauraHiloVida(15), SVZActions.efectos(e(MobEffects.ABSORPTION, 90, 2))));
        comida("pabellon_del_mas_alla", 10, 0.9F, false, S | T,
                SVZActions.y(SVZActions.restauraHiloVida(30),
                        SVZActions.efectos(e(MobEffects.STRENGTH, 120, 1), e(MobEffects.RESISTANCE, 120, 1))));
        comida("hallaca_eterna", 10, 1.0F, false, G | S | T,
                SVZActions.y(SVZActions.restauraHiloVida(50),
                        SVZActions.y(SVZActions.efectos(e(MobEffects.REGENERATION, 30, 1), e(MobEffects.SATURATION, 10, 0)),
                                SVZActions.resistenciaControl(120))));
        comida("banquete_del_segundo_hilo", 14, 1.0F, false, G | S | T, SVZActions.BANQUETE_SEGUNDO_HILO);

        // ---------------- 5. armas del Herrero
        hacha("hacha_de_cobre", COBRE, 6.0F, -3.1F, 0, null);
        espada("machete_de_hierro", ToolMaterial.IRON, 3.0F, -2.2F, 0, null);
        espada("lanza_llanera", ToolMaterial.IRON, 3.5F, -2.8F, 0, null);
        espada("martillo_rompehilos", ACERO, 5.0F, -3.2F, 0, SVZActions.vsMarcados(e(MobEffects.SLOWNESS, 4, 1)));
        espada("espada_de_acero", ACERO, 3.0F, -2.4F, 0, null);
        reg(HERRERO, "escudo_de_acero_llanero", Item::new, escudoProps(), 0);
        espada("filo_cortahilos", ACERO, 3.5F, -2.2F, 0,
                SVZActions.vsMarcados(e(MobEffects.WEAKNESS, 5, 0), e(MobEffects.GLOWING, 5, 0)));
        armaduraSet("acero_llanero", armadura(24, 3, 7, 5, 3, 12, 1.0F, 0.0F, "acero_llanero"), 0, false);

        // armas olvidadas
        hacha("hacha_espectral", OLVIDADO, 5.5F, -3.0F, S | T,
                SVZActions.siempre(ParticleTypes.SOUL_FIRE_FLAME, e(MobEffects.SLOWNESS, 3, 0)));
        espada("machete_de_alma", OLVIDADO, 3.0F, -2.2F, S | T, SVZActions.robaVida(1.0F, ParticleTypes.SOUL));
        espada("lanza_del_mas_alla", OLVIDADO, 3.5F, -2.6F, S | T,
                SVZActions.siempre(ParticleTypes.END_ROD, e(MobEffects.WEAKNESS, 5, 0)));
        espada("martillo_de_nudos", OLVIDADO, 6.0F, -3.3F, S | T,
                SVZActions.siempre(ParticleTypes.SOUL_FIRE_FLAME, e(MobEffects.SLOWNESS, 3, 2)));
        espada("filo_del_segundo_hilo", OLVIDADO, 4.0F, -2.2F, S | T, SVZActions.robaVida(2.0F, ParticleTypes.END_ROD));
        armaduraSet("del_tejedor", armadura(40, 3, 8, 6, 3, 22, 2.0F, 0.1F, "tejedor"), S | T, true);

        registrarPestanas();
    }

    // ------------------------------------------------------------------ pestañas creativas
    private static void pestana(String id, Item icono, List<Item> items) {
        CreativeModeTab tab = FabricItemGroup.builder()
                .title(Component.translatable("itemGroup." + SVZItemsMod.MOD_ID + "." + id))
                .icon(() -> new ItemStack(icono))
                .displayItems((params, output) -> items.forEach(i -> output.accept(i)))
                .build();
        Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB,
                ResourceKey.create(Registries.CREATIVE_MODE_TAB, SVZItemsMod.id(id)), tab);
    }

    private static void registrarPestanas() {
        pestana("materiales", HILO_ROJO, MATERIALES);
        pestana("especiales", HILO_VIDA, ESPECIALES);
        pestana("comidas", COMIDAS.get(0), COMIDAS);
        pestana("herrero", HERRERO.get(0), HERRERO);
    }
}
