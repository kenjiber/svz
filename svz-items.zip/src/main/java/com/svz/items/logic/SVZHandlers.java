package com.svz.items.logic;

import com.svz.core.api.SVZCoreAPI;
import com.svz.core.event.SVZHilosChangeEvent;
import com.svz.items.api.SVZItemsAPI;
import com.svz.items.item.ModItems;
import com.svz.items.item.SVZAxe;
import com.svz.items.item.SVZWeapon;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Eventos globales: Hilo de Vida, Hilo de Cofre, partículas, armas del Telar y sincronía con SVZ-Core. */
public final class SVZHandlers {
    private SVZHandlers() {}

    private static final EquipmentSlot[] SLOTS = {EquipmentSlot.MAINHAND, EquipmentSlot.OFFHAND,
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    /** Inventarios guardados por Hilo de Cofre (en memoria: se devuelven al reaparecer). */
    private static final Map<UUID, List<ItemStack>> STASH = new HashMap<>();

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(SVZHandlers::tick);
        ServerLivingEntityEvents.ALLOW_DEATH.register(SVZHandlers::allowDeath);
        ServerLivingEntityEvents.ALLOW_DAMAGE.register(SVZHandlers::allowDamage);
        ServerPlayerEvents.AFTER_RESPAWN.register((oldP, newP, alive) -> restaurar(newP));
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> restaurar(handler.getPlayer()));
        SVZHilosChangeEvent.EVENT.register(SVZHandlers::onHilos);
    }

    // ------------------------------------------------------------ utilidades de inventario
    /** Como un tótem: solo cuenta si está en la mano principal o en la secundaria. */
    private static boolean tiene(ServerPlayer p, Item item) {
        return p.getMainHandItem().is(item) || p.getOffhandItem().is(item);
    }

    /** Gasta uno de los que lleva en las manos. */
    private static boolean consumir(ServerPlayer p, Item item) {
        if (p.getMainHandItem().is(item)) {
            p.getMainHandItem().shrink(1);
            return true;
        }
        if (p.getOffhandItem().is(item)) {
            p.getOffhandItem().shrink(1);
            return true;
        }
        return false;
    }

    // ------------------------------------------------------------ tick
    private static void tick(MinecraftServer server) {
        int t = server.getTickCount();
        if (t % 5 != 0) return;
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            particulas(p);
            if (t % 20 == 0) {
                sincronizarCore(p);
                penalizacionTejedor(p);
            }
        }
    }

    private static void particulas(ServerPlayer p) {
        int n = 0;
        for (EquipmentSlot slot : SLOTS) {
            if (ModItems.ESPECTRALES.contains(p.getItemBySlot(slot).getItem())) n++;
        }
        if (n == 0 || !(p.level() instanceof ServerLevel sl)) return;
        n = Math.min(n, 4);
        sl.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, p.getX(), p.getY(1.0), p.getZ(), n, 0.4, 0.6, 0.4, 0.01);
        sl.sendParticles(ParticleTypes.END_ROD, p.getX(), p.getY(1.0), p.getZ(), 1, 0.4, 0.6, 0.4, 0.01);
    }

    /** Mantiene en SVZ-Core los flags de HUD "lleva Hilo de Vida / Hilo de Cofre". */
    private static void sincronizarCore(ServerPlayer p) {
        boolean vida = tiene(p, ModItems.HILO_VIDA);
        boolean cofre = tiene(p, ModItems.HILO_COFRE);
        if (vida != SVZCoreAPI.llevaHiloVida(p)) SVZCoreAPI.setLlevaHiloVida(p, vida);
        if (cofre != SVZCoreAPI.llevaHiloCofre(p)) SVZCoreAPI.setLlevaHiloCofre(p, cofre);
    }

    /** La Armadura del Tejedor solo es ligera en el Telar Roto: fuera, ralentiza. */
    private static void penalizacionTejedor(ServerPlayer p) {
        if (SVZCoreAPI.isInTelarRoto(p)) return;
        for (EquipmentSlot slot : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
            if (ModItems.ARMADURA_TEJEDOR.contains(p.getItemBySlot(slot).getItem())) {
                p.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 60, 1, true, false));
                return;
            }
        }
    }

    // ------------------------------------------------------------ muerte
    private static boolean allowDeath(LivingEntity entity, DamageSource source, float amount) {
        if (!(entity instanceof ServerPlayer p)) return true;
        // El Hilo de Vida no evita la muerte permanente del Telar Roto.
        if (!SVZCoreAPI.isMuertePermanente(p) && consumir(p, ModItems.HILO_VIDA)) {
            revivir(p);
            return false;
        }
        if (!SVZCoreAPI.isMuertePermanente(p) && tiene(p, ModItems.HILO_COFRE)) guardarInventario(p);
        return true;
    }

    private static void revivir(ServerPlayer p) {
        p.setHealth(p.getMaxHealth() * 0.5F);
        p.removeAllEffects();
        p.clearFire();
        p.resetFallDistance();
        p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 200, 1));
        p.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, 100, 1));
        p.level().broadcastEntityEvent(p, (byte) 35); // animación del tótem
        p.displayClientMessage(Component.literal("Tu Hilo de Vida te trajo de vuelta."), true);
    }

    private static void guardarInventario(ServerPlayer p) {
        Inventory inv = p.getInventory();
        List<ItemStack> copia = new ArrayList<>();
        for (int i = 0; i < inv.getContainerSize(); i++) copia.add(inv.getItem(i).copy());
        for (ItemStack s : copia) {
            if (s.is(ModItems.HILO_COFRE)) {
                s.shrink(1); // el hilo se consume
                break;
            }
        }
        inv.clearContent();
        STASH.put(p.getUUID(), copia);
    }

    private static void restaurar(ServerPlayer p) {
        List<ItemStack> guardado = STASH.remove(p.getUUID());
        if (guardado == null) return;
        Inventory inv = p.getInventory();
        for (int i = 0; i < guardado.size() && i < inv.getContainerSize(); i++) inv.setItem(i, guardado.get(i));
        p.displayClientMessage(Component.literal("El Hilo de Cofre conservó tu inventario."), true);
    }

    // ------------------------------------------------------------ daño
    /** Las armas olvidadas no hacen daño fuera del Telar Roto. */
    private static boolean allowDamage(LivingEntity entity, DamageSource source, float amount) {
        if (source.getEntity() instanceof ServerPlayer att) {
            Item arma = att.getMainHandItem().getItem();
            if ((arma instanceof SVZWeapon || arma instanceof SVZAxe) && ModItems.TELAR_ONLY.contains(arma)
                    && !SVZCoreAPI.isInTelarRoto(att)) {
                att.displayClientMessage(Component.translatable("svz-items.msg.solo_telar"), true);
                return false;
            }
        }
        return true;
    }

    // ------------------------------------------------------------ resistencia al control
    /** Con resistencia al control activa, el drenaje de hilos del alma se revierte. */
    private static void onHilos(ServerPlayer p, int oldValue, int newValue, SVZHilosChangeEvent.Reason reason,
                                net.minecraft.world.entity.Entity source) {
        if (reason == SVZHilosChangeEvent.Reason.DRENAJE && newValue < oldValue && SVZItemsAPI.tieneResistenciaControl(p)) {
            SVZCoreAPI.addHilos(p, oldValue - newValue);
            p.displayClientMessage(Component.literal("Tu resistencia frena el drenaje."), true);
        }
    }
}
