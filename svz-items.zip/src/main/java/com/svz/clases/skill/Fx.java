package com.svz.clases.skill;

import com.svz.core.api.SVZCoreAPI;
import com.svz.items.api.SVZItemsAPI;
import com.svz.items.item.SVZActions;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.npc.villager.Villager;                     // ← CORREGIDO
import net.minecraft.world.entity.npc.wanderingtrader.WanderingTrader;     // ← CORREGIDO
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * Efecto de una habilidad y, en los métodos estáticos, el catálogo de bloques con los que se construyen
 * todas (buffs, curas, detección, daño en área, control, liberación...).
 */
@FunctionalInterface
public interface Fx {
    void run(ServerLevel level, ServerPlayer caster);

    /** Efecto sobre un jugador concreto (el propio lanzador o un aliado). */
    @FunctionalInterface
    interface Tgt {
        void apply(ServerLevel level, ServerPlayer caster, ServerPlayer target);
    }

    // ------------------------------------------------------------ composición
    static Fx yo(Tgt... t) {
        return (l, p) -> { for (Tgt x : t) x.apply(l, p, p); };
    }

    /** Aplica a todos los jugadores en el radio (incluido el lanzador). */
    static Fx aliados(double radio, Tgt... t) {
        return (l, p) -> {
            for (ServerPlayer o : l.getEntitiesOfClass(ServerPlayer.class, p.getBoundingBox().inflate(radio), o -> !o.isSpectator())) {
                for (Tgt x : t) x.apply(l, p, o);
            }
        };
    }

    static Fx varios(Fx... f) {
        return (l, p) -> { for (Fx x : f) x.run(l, p); };
    }

    // ------------------------------------------------------------ efectos sobre jugadores
    static Tgt buff(Holder<MobEffect> e, int seg, int amp) {
        return (l, c, t) -> t.addEffect(new MobEffectInstance(e, seg * 20, amp));
    }

    static Tgt curar(float corazones) {
        return (l, c, t) -> t.heal(corazones * 2);
    }

    static Tgt saciar(int comida) {
        return (l, c, t) -> t.getFoodData().eat(comida, 0.8F);
    }

    static Tgt hilos(int n) {
        return (l, c, t) -> SVZCoreAPI.addHilos(t, n);
    }

    static Tgt resControl(int seg) {
        return (l, c, t) -> SVZItemsAPI.darResistenciaControl(t, seg * 20);
    }

    /** Quita los efectos negativos. */
    static Tgt limpiar() {
        return (l, c, t) -> {
            for (MobEffectInstance m : new ArrayList<>(t.getActiveEffects())) {
                if (!m.getEffect().value().isBeneficial()) t.removeEffect(m.getEffect());
            }
        };
    }

    /** Libera a un jugador poseído (deja al menos {@code minimo} hilos). */
    static Tgt liberar(int minimo) {
        return (l, c, t) -> {
            if (SVZCoreAPI.isPoseido(t)) SVZCoreAPI.setPoseido(t, false);
            if (SVZCoreAPI.getHilos(t) < minimo) SVZCoreAPI.setHilos(t, minimo);
        };
    }

    static Tgt reparar() {
        return (l, c, t) -> {
            for (EquipmentSlot s : new EquipmentSlot[]{EquipmentSlot.MAINHAND, EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
                ItemStack st = t.getItemBySlot(s);
                if (st.isDamageableItem()) st.setDamageValue(0);
            }
        };
    }

    static Tgt dar(String itemSVZ, int n) {
        return (l, c, t) -> {
            ItemStack st = new ItemStack(BuiltInRegistries.ITEM.getValue(Identifier.fromNamespaceAndPath("svz-items", itemSVZ)), n);
            if (!t.getInventory().add(st)) t.drop(st, false);
        };
    }

    static Tgt todos(Tgt... t) {
        return (l, c, x) -> { for (Tgt y : t) y.apply(l, c, x); };
    }

    // ------------------------------------------------------------ combate y control
    private static List<LivingEntity> enemigos(ServerLevel l, ServerPlayer p, double r, boolean soloMarcados) {
        return l.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(r), e ->
                e != p && !(e instanceof Player) && (soloMarcados ? SVZActions.esMarcado(e) : (e instanceof Enemy || SVZActions.esMarcado(e))));
    }

    static Fx dano(double radio, float dmg, boolean soloMarcados, MobEffectInstance... efectos) {
        return (l, p) -> {
            for (LivingEntity e : enemigos(l, p, radio, soloMarcados)) {
                e.hurtServer(l, l.damageSources().playerAttack(p), dmg);
                for (MobEffectInstance m : efectos) e.addEffect(new MobEffectInstance(m));
            }
        };
    }

    /** Daño en área con empuje hacia fuera (torbellino). */
    static Fx torbellino(double radio, float dmg) {
        return (l, p) -> {
            for (LivingEntity e : enemigos(l, p, radio, false)) {
                e.hurtServer(l, l.damageSources().playerAttack(p), dmg);
                Vec3 d = e.position().subtract(p.position()).normalize();
                e.knockback(1.2, -d.x, -d.z);
            }
        };
    }

    static MobEffectInstance ef(Holder<MobEffect> e, int seg, int amp) {
        return new MobEffectInstance(e, seg * 20, amp);
    }

    /** Impulso hacia delante (embestida / lanza). */
    static Fx impulso(double fuerza) {
        return (l, p) -> {
            Vec3 v = p.getLookAngle();
            p.setDeltaMovement(v.x * fuerza, 0.25, v.z * fuerza);
            p.hurtMarked = true;
        };
    }

    private static LivingEntity enFrente(ServerLevel l, ServerPlayer p, double alcance) {
        Vec3 look = p.getLookAngle();
        LivingEntity mejor = null;
        double md = Double.MAX_VALUE;
        for (LivingEntity e : l.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(alcance), e -> e != p && !(e instanceof Player))) {
            Vec3 d = e.position().subtract(p.position());
            double dist = d.length();
            if (dist < 0.5 || d.normalize().dot(look) < 0.85) continue;
            if (dist < md) { md = dist; mejor = e; }
        }
        return mejor;
    }

    /** Lazo: arrastra hacia ti al enemigo que miras. */
    static Fx lazo(double alcance) {
        return (l, p) -> {
            LivingEntity e = enFrente(l, p, alcance);
            if (e == null) { p.displayClientMessage(Component.literal("§7El lazo no encuentra objetivo."), true); return; }
            Vec3 d = p.position().subtract(e.position()).normalize();
            e.setDeltaMovement(d.x * 1.4, 0.35, d.z * 1.4);
            e.hurtMarked = true;
            line(l, p.getEyePosition(), e.position().add(0, e.getBbHeight() / 2, 0));
        };
    }

    /** Inmoviliza al objetivo que miras (o a los del radio si {@code radio} &gt; 0). */
    static Fx inmovilizar(double alcance, int seg, int amp, boolean debilitar) {
        return (l, p) -> {
            LivingEntity e = enFrente(l, p, alcance);
            if (e == null) { p.displayClientMessage(Component.literal("§7No hay objetivo al frente."), true); return; }
            e.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, seg * 20, amp));
            if (debilitar) e.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, seg * 20, 0));
            line(l, p.getEyePosition(), e.position().add(0, e.getBbHeight() / 2, 0));
        };
    }

    static Fx golpeFrente(double alcance, float dmg) {
        return (l, p) -> {
            LivingEntity e = enFrente(l, p, alcance);
            if (e != null) e.hurtServer(l, l.damageSources().playerAttack(p), dmg);
        };
    }

    // ------------------------------------------------------------ detección
    private static void resaltar(ServerLevel l, ServerPlayer p, double radio, int seg, boolean marcados, boolean aldeanos) {
        int n = 0;
        for (LivingEntity e : l.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(radio), e -> e != p)) {
            boolean ok = (marcados && SVZActions.esMarcado(e)) || (aldeanos && (e instanceof Villager || e instanceof WanderingTrader));
            if (!ok) continue;
            e.addEffect(new MobEffectInstance(MobEffects.GLOWING, seg * 20, 0, false, false));
            n++;
        }
        p.displayClientMessage(Component.literal("§7Percibes " + n + " presencia(s) cercana(s)."), true);
    }

    static Fx detectar(double radio, int seg) {
        return (l, p) -> resaltar(l, p, radio, seg, true, false);
    }

    static Fx aldeanos(double radio, int seg) {
        return (l, p) -> resaltar(l, p, radio, seg, false, true);
    }

    static Fx resaltarAliados(double radio, int seg) {
        return (l, p) -> {
            for (ServerPlayer o : l.getEntitiesOfClass(ServerPlayer.class, p.getBoundingBox().inflate(radio), o -> o != p && !o.isSpectator())) {
                o.addEffect(new MobEffectInstance(MobEffects.GLOWING, seg * 20, 0, false, false));
            }
        };
    }

    /** Línea de partículas hacia la presencia marcada más cercana. */
    static Fx rastro(double radio) {
        return (l, p) -> {
            LivingEntity mejor = null;
            double md = Double.MAX_VALUE;
            for (LivingEntity e : l.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(radio), e -> e != p && SVZActions.esMarcado(e))) {
                double d = e.distanceToSqr(p);
                if (d < md) { md = d; mejor = e; }
            }
            if (mejor == null) { p.displayClientMessage(Component.literal("§7El hilo no te lleva a ningún sitio."), true); return; }
            line(l, p.position().add(0, 1, 0), mejor.position().add(0, mejor.getBbHeight() / 2, 0));
            p.displayClientMessage(Component.literal("§7El hilo señala a " + (int) Math.sqrt(md) + " bloques."), true);
        };
    }

    private static void line(ServerLevel l, Vec3 a, Vec3 b) {
        int n = (int) Math.max(8, a.distanceTo(b) * 2);
        for (int i = 0; i <= n; i++) {
            Vec3 q = a.lerp(b, i / (double) n);
            l.sendParticles(ParticleTypes.END_ROD, q.x, q.y, q.z, 1, 0, 0, 0, 0);
        }
    }

    private static Block blockPorId(String ns, String path) {
        return BuiltInRegistries.BLOCK.getValue(Identifier.fromNamespaceAndPath(ns, path));
    }

    /** Escaneo de bloques a tu alrededor (radio máx. 16) marcándolos con partículas. */
    private static void escanear(ServerLevel l, ServerPlayer p, int radio, boolean minerales, boolean cofres, boolean vetas) {
        radio = Math.min(radio, 16);
        Block veta = blockPorId("svz-telarroto", "veta_del_telar");
        BlockPos o = p.blockPosition();
        int n = 0;
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int dx = -radio; dx <= radio && n < 80; dx++) {
            for (int dy = -radio; dy <= radio && n < 80; dy++) {
                for (int dz = -radio; dz <= radio && n < 80; dz++) {
                    m.set(o.getX() + dx, o.getY() + dy, o.getZ() + dz);
                    BlockState s = l.getBlockState(m);
                    boolean hit = (minerales && (s.is(BlockTags.COAL_ORES) || s.is(BlockTags.IRON_ORES) || s.is(BlockTags.COPPER_ORES)
                            || s.is(BlockTags.GOLD_ORES) || s.is(BlockTags.REDSTONE_ORES) || s.is(BlockTags.LAPIS_ORES)
                            || s.is(BlockTags.DIAMOND_ORES) || s.is(BlockTags.EMERALD_ORES)))
                            || (cofres && (s.is(Blocks.CHEST) || s.is(Blocks.TRAPPED_CHEST) || s.is(Blocks.BARREL)))
                            || (vetas && veta != Blocks.AIR && s.is(veta));
                    if (hit) {
                        l.sendParticles(ParticleTypes.HAPPY_VILLAGER, m.getX() + 0.5, m.getY() + 0.5, m.getZ() + 0.5, 4, 0.2, 0.2, 0.2, 0.0);
                        n++;
                    }
                }
            }
        }
        p.displayClientMessage(Component.literal("§7Detectas " + n + " punto(s) de interés."), true);
    }

    static Fx minerales(int radio) {
        return (l, p) -> escanear(l, p, radio, true, false, false);
    }

    static Fx cofres(int radio) {
        return (l, p) -> escanear(l, p, radio, false, true, false);
    }

    static Fx vetas(int radio) {
        return (l, p) -> escanear(l, p, radio, false, false, true);
    }

    static Fx todoDetectado(int radio) {
        return (l, p) -> {
            escanear(l, p, radio, true, true, true);
            resaltar(l, p, radio * 2, 20, true, true);
        };
    }

    /** Muestra el estado (hilos, clase, posesión) del ser al que miras o, si no hay, el tuyo. */
    static Fx inspeccionar(double alcance) {
        return (l, p) -> {
            LivingEntity e = enFrente(l, p, alcance);
            if (e instanceof ServerPlayer sp) {
                p.displayClientMessage(Component.literal(sp.getName().getString() + ": hilos " + SVZCoreAPI.getHilos(sp) + "/" + SVZCoreAPI.getMaxHilos(sp)
                        + " · " + SVZCoreAPI.getClase(sp).getSerializedName() + " · " + (SVZCoreAPI.isPoseido(sp) ? "POSEÍDO" : "libre")), false);
            } else if (e != null) {
                p.displayClientMessage(Component.literal(SVZActions.esMarcado(e) ? "§cEl espejo muestra una posesión en este ser." : "§7El espejo no muestra posesión."), false);
            } else {
                p.displayClientMessage(Component.literal("Tus hilos: " + SVZCoreAPI.getHilos(p) + "/" + SVZCoreAPI.getMaxHilos(p)
                        + " · " + (SVZCoreAPI.isPoseido(p) ? "POSEÍDO" : "libre")), false);
            }
        };
    }

    /** Lista el estado de todos los jugadores cercanos. */
    static Fx escanerAlma(double radio) {
        return (l, p) -> {
            for (ServerPlayer o : l.getEntitiesOfClass(ServerPlayer.class, p.getBoundingBox().inflate(radio), o -> o != p && !o.isSpectator())) {
                p.displayClientMessage(Component.literal(o.getName().getString() + ": hilos " + SVZCoreAPI.getHilos(o) + "/" + SVZCoreAPI.getMaxHilos(o)
                        + (SVZCoreAPI.isPoseido(o) ? " §c(POSEÍDO)" : "")), false);
            }
        };
    }

    /** Análisis de todos los marcados cercanos. */
    static Fx analisisHilo(double radio) {
        return (l, p) -> {
            int n = 0;
            for (LivingEntity e : l.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(radio), e -> e != p && SVZActions.esMarcado(e))) {
                n++;
                p.displayClientMessage(Component.literal("§cMarcado: " + e.getName().getString() + " a " + (int) e.distanceTo(p) + " bloques."), false);
            }
            if (n == 0) p.displayClientMessage(Component.literal("§7Ningún hilo corrupto cerca."), true);
        };
    }
}