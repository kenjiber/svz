#!/usr/bin/env python3
"""Genera texturas pixel art 16x16, modelos, lang y recetas de SVZ-Items."""
import os, json, math, random
from PIL import Image

MOD = "svz-items"
R = os.path.dirname(os.path.abspath(__file__))
A = f"{R}/src/main/resources/assets/{MOD}"
D = f"{R}/src/main/resources/data/{MOD}"
for p in ["textures/item", "items", "models/item", "lang", "equipment",
          "textures/entity/equipment/humanoid", "textures/entity/equipment/humanoid_leggings"]:
    os.makedirs(f"{A}/{p}", exist_ok=True)
os.makedirs(f"{D}/recipe", exist_ok=True)

# ---------------------------------------------------------------- utilidades
def mix(a, b, t): return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))
def lighter(c, t=.4): return mix(c, (255, 255, 255), t)
def darker(c, t=.4): return mix(c, (0, 0, 0), t)

# colores
YEL = (255, 204, 0); BLU = (0, 36, 125); RED = (207, 20, 43)           # bandera
GOLD = (240, 190, 60); STEEL = (170, 178, 190); DSTEEL = (95, 100, 115)
WOOD = (130, 85, 45); LEAF = (60, 140, 55); CREAM = (240, 225, 190)
SPEC = (110, 225, 240); VIO = (160, 110, 235); NIGHT = (40, 30, 60)
BLACK = (45, 38, 55); BONE = (230, 220, 200); TAN = (214, 160, 80)

def disc(cx, cy, r): return {(x, y) for x in range(16) for y in range(16) if (x + .5 - cx) ** 2 + (y + .5 - cy) ** 2 <= r * r}
def ell(cx, cy, rx, ry): return {(x, y) for x in range(16) for y in range(16) if ((x + .5 - cx) / rx) ** 2 + ((y + .5 - cy) / ry) ** 2 <= 1}
def rect(x0, y0, x1, y1): return {(x, y) for x in range(x0, x1 + 1) for y in range(y0, y1 + 1)}
def ring(cx, cy, ro, ri): return disc(cx, cy, ro) - disc(cx, cy, ri)
def line(x0, y0, x1, y1, w=1):
    n = max(abs(x1 - x0), abs(y1 - y0), 1); m = set()
    for i in range(n + 1):
        x = round(x0 + (x1 - x0) * i / n); y = round(y0 + (y1 - y0) * i / n)
        m.add((x, y))
        if w >= 2: m.add((x + 1, y))
        if w >= 3: m.add((x, y + 1))
    return m

class Cv:
    def __init__(s): s.p = {}
    def mask(s, m, col, bevel=True):
        for (x, y) in m:
            if not (0 <= x < 16 and 0 <= y < 16): continue
            if not bevel: c = col
            elif (x - 1, y) not in m or (x, y - 1) not in m: c = lighter(col, .35)
            elif (x + 1, y) not in m or (x, y + 1) not in m: c = darker(col, .3)
            else: c = col
            s.p[(x, y)] = c
    def dot(s, x, y, c):
        if 0 <= x < 16 and 0 <= y < 16: s.p[(x, y)] = c
    def dots(s, pts, c):
        for x, y in pts: s.dot(x, y, c)
    def sparkle(s, pts, c=(255, 255, 255)):
        s.dots(pts, c)
    def image(s):
        im = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
        for (x, y), c in s.p.items(): im.putpixel((x, y), c + (255,))
        for x in range(16):
            for y in range(16):
                if (x, y) in s.p: continue
                nb = [s.p[(x + dx, y + dy)] for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)) if (x + dx, y + dy) in s.p]
                if nb:
                    base = nb[0]
                    im.putpixel((x, y), darker(base, .72) + (255,))
        return im

def spk(c, col): c.sparkle([(2, 2), (13, 3), (3, 12), (12, 13)], col)

# ---------------------------------------------------------------- materiales
def d_thread(c, col, spec=False):
    m = set()
    for i in range(15):
        x = 1 + i; y = int(round(13 - i * .8 + 1.6 * math.sin(i * .8)))
        m |= line(x, y, x, y, 2)
    c.mask(m, col)
    c.dots([(4, 12), (8, 8), (11, 5)], lighter(col, .6))
    c.mask(disc(3, 14, 1.2), col)
    if spec: spk(c, lighter(col, .8))

def d_knot(c, col, spec=False):
    c.mask(line(4, 12, 1, 15, 2), darker(col, .15)); c.mask(line(11, 12, 14, 15, 2), darker(col, .15))
    c.mask(ring(6, 6.5, 4.5, 2), col); c.mask(ring(10, 8, 4.5, 2), lighter(col, .1))
    c.mask(disc(8, 7.5, 1.6), darker(col, .2))
    if spec: spk(c, lighter(col, .8))

def d_core(c, col, spec=False):
    c.mask(disc(8, 8, 6.5), col)
    for (x, y) in list(c.p):
        if (x + y) % 4 == 0: c.p[(x, y)] = darker(col, .35)
        if (x - y) % 7 == 0: c.p[(x, y)] = lighter(col, .15)
    c.dots([(5, 4), (6, 4), (4, 5)], (255, 240, 240))
    c.mask(disc(8, 8, 1.5), lighter(col, .5), False)
    if spec: spk(c, lighter(col, .8))

def d_ash(c, col, spec=False):
    c.mask(ell(8, 11.5, 6.5, 4) & {(x, y) for x in range(16) for y in range(16) if y >= 8}, col)
    c.mask(ell(8, 9, 3.5, 2.5) & {(x, y) for x in range(16) for y in range(16) if y >= 7}, lighter(col, .15))
    c.dots([(4, 11), (11, 12), (7, 13), (9, 10)], darker(col, .5)); c.dots([(6, 9), (10, 11)], lighter(col, .6))
    c.dots([(7, 4), (9, 2), (8, 6)], SPEC if spec else (255, 150, 60))

def d_cloth(c, col, spec=False):
    m = rect(2, 3, 13, 12) - {(x, 12) for x in range(3, 14, 2)} - {(2, 3), (13, 3)}
    c.mask(m, col)
    c.dots([(x, 5) for x in range(3, 13, 2)], lighter(col, .6))
    c.dots([(x, 9) for x in range(4, 13, 3)], darker(col, .4)); c.dots([(5, 7), (6, 7), (7, 7)], darker(col, .25))
    c.dots([(10, 8), (11, 9)], (30, 25, 40))
    if spec: spk(c, SPEC)

def d_tear(c, col, spec=False):
    m = disc(8, 10, 4.5) | {(x, y) for y in range(2, 7) for x in range(8 - (y - 2) // 2 - 1, 8 + (y - 2) // 2 + 1)}
    c.mask(m, col)
    c.dots([(6, 9), (6, 10), (7, 8)], (240, 255, 255)); c.dots([(10, 12), (9, 13)], darker(col, .35))
    if spec: spk(c, SPEC)

def d_corn(c, col, spec=False):
    c.mask(line(8, 14, 3, 6, 2), LEAF if not spec else (140, 190, 190)); c.mask(line(8, 14, 12, 6, 2), darker(LEAF, .1) if not spec else (110, 160, 170))
    c.mask(ell(8, 7, 3, 6), col)
    for (x, y) in list(c.p):
        if (x + y) % 2 == 0 and 5 <= x <= 10 and y <= 11: c.p[(x, y)] = lighter(col, .35)
    c.dots([(7, 3), (8, 4)], (255, 255, 235))
    if spec: spk(c, SPEC)

def d_metal(c, col, spec=False):
    c.mask(rect(3, 7, 12, 11), col); c.mask(rect(5, 5, 13, 6) | rect(4, 6, 12, 6), lighter(col, .25))
    c.dots([(4, 8), (5, 8), (6, 8)], lighter(col, .6)); c.dots([(9, 10), (10, 10)], darker(col, .35))
    c.dots([(7, 2), (5, 3), (10, 3)], VIO if spec else GOLD)
    if spec: spk(c, VIO)

# ---------------------------------------------------------------- especiales
def d_ringthread(c, col, spec=False, extra=None):
    c.mask(line(5, 12, 3, 15, 2), darker(col, .2)); c.mask(line(11, 12, 13, 15, 2), darker(col, .2))
    c.mask(ring(8, 7.5, 6, 3.8), col)
    c.dots([(4, 4), (5, 3), (3, 6)], lighter(col, .6))
    if extra: extra(c)
    if spec: spk(c, lighter(col, .8))

def d_vida(c, col, spec=False):
    d_ringthread(c, col, spec)
    c.mask({(7, 6), (9, 6), (6, 7), (7, 7), (8, 7), (9, 7), (10, 7), (7, 8), (8, 8), (9, 8), (8, 9)}, (255, 235, 235), False)

def d_cofre(c, col, spec=False):
    d_ringthread(c, col, spec)
    c.mask(rect(6, 6, 10, 9), (150, 95, 45)); c.dots([(x, 7) for x in range(6, 11)], (60, 40, 20)); c.dot(8, 8, YEL)

def d_resur(n):
    gems = [(7, 0), (0, 7), (14, 7)][:n]
    cols = [(210, 120, 60), (200, 210, 225), (110, 240, 255)][n - 1]
    def f(c, col, spec=False):
        def extra(cc):
            for gx, gy in gems: cc.mask(rect(gx, gy, gx + 1, gy + 1), cols, False)
            if n == 3: cc.dots([(8, 7), (7, 7), (8, 8), (7, 8)], (255, 255, 255))
        d_ringthread(c, col, spec, extra)
    return f

def d_anclaje(c, col, spec=False):
    c.mask(rect(7, 3, 8, 12), DSTEEL); c.mask(rect(4, 5, 11, 6), DSTEEL); c.mask(ring(7.5, 2.2, 2, 1), DSTEEL)
    c.mask(line(2, 9, 7, 13) | line(13, 9, 8, 13), DSTEEL); c.mask({(1, 8), (2, 8), (13, 8), (14, 8)}, STEEL)
    for y in (4, 8, 11): c.mask({(7, y), (8, y)}, col, False)
    c.dots([(6, 5)], lighter(STEEL, .5))

def d_liberacion(c, col, spec=False):
    c.mask(line(8, 8, 3, 2, 1) | line(8, 8, 13, 2, 1), STEEL, False)
    c.mask(ring(4.5, 12.5, 3, 1.4), col); c.mask(ring(11.5, 12.5, 3, 1.4), col)
    c.mask(line(8, 8, 5, 11) | line(8, 8, 11, 11), DSTEEL, False)
    c.dots([(1, 5), (2, 5), (3, 5), (5, 5)], (230, 60, 70)); c.dots([(11, 5), (13, 5), (14, 5)], (230, 60, 70)); c.dot(8, 8, YEL)

def d_vela(c, col, spec=False):
    c.mask(rect(4, 14, 11, 15), BLACK); c.mask(rect(6, 7, 9, 13), CREAM)
    c.dots([(7, 9), (7, 10), (7, 11)], lighter(CREAM, .5)); c.dots([(8, 12), (8, 13)], darker(CREAM, .3)); c.dot(7, 6, BLACK)
    c.mask(ell(7.5, 4, 1.8, 3), col); c.mask(ell(7.5, 4.5, .9, 1.6), (240, 255, 255), False)
    c.dots([(3, 3), (12, 2), (12, 7)], SPEC)

def d_ojo(c, col, spec=False):
    for x in (4, 8, 12): c.mask(line(x, 11, x, 15), (30, 25, 40) if x != 8 else (210, 30, 50), False)
    c.mask(ell(8, 7, 7, 4), (235, 235, 245)); c.mask(disc(8, 7, 3), col); c.mask(rect(7, 5, 8, 9), (10, 5, 20), False)
    c.dots([(4, 6), (3, 7), (12, 8), (13, 7)], (210, 90, 110)); c.dots([(6, 6)], (255, 255, 255))
    if spec: spk(c, SPEC)

def d_espejo(c, col, spec=False):
    c.mask(rect(7, 11, 8, 15), WOOD); c.mask(rect(6, 10, 9, 10), GOLD)
    c.mask(disc(8, 6, 5.5), GOLD); c.mask(disc(8, 6, 4), col, False)
    c.dots([(6, 4), (7, 3), (5, 5)], (255, 255, 255)); c.dots([(10, 8), (9, 9)], lighter(col, .5))
    c.dots([(13, 2), (14, 4)], (255, 140, 40))

# armas
def sword(c, blade, guard=GOLD, grip=WOOD, wide=2, edge=None, tip=True):
    m = line(13, 2, 6, 9, wide)
    c.mask(m, blade)
    if edge: c.mask(line(14, 2, 7, 9, 1) - m, edge, False)
    c.dots([(12, 3), (10, 5), (8, 7)], lighter(blade, .55))
    c.mask(line(3, 8, 7, 12, 2), guard); c.mask(line(5, 10, 2, 13, 1), grip); c.mask(line(2, 13, 1, 14, 2), guard)

def machete(c, blade, spec=False):
    sword(c, blade, DSTEEL, WOOD, 3)
    c.mask(line(8, 7, 14, 2, 1), darker(blade, .1), False)
    c.dots([(2, 13), (3, 12)], YEL)

def d_machete(col, spec=False):
    return lambda c, pal=None, s=False: (machete(c, col), spk(c, SPEC) if s else None)

def spear(c, head, shaft=WOOD, spec=False):
    c.mask(line(1, 14, 11, 4, 1), shaft); c.mask(line(2, 14, 12, 4, 1) - line(1, 14, 11, 4, 1), darker(shaft, .3), False)
    c.mask({(11, 4), (12, 3), (13, 2), (14, 1), (12, 4), (13, 3), (14, 2), (13, 4), (12, 2), (11, 3)}, head)
    c.dots([(13, 3), (12, 3)], lighter(head, .6)); c.dots([(3, 12), (4, 11)], YEL); c.dots([(5, 10), (6, 9)], BLU); c.dots([(7, 8)], RED)

def hammer(c, head, shaft=WOOD):
    c.mask(line(3, 13, 10, 6, 1), shaft); c.mask(rect(7, 2, 13, 6), head)
    c.dots([(8, 3), (9, 3), (8, 4)], lighter(head, .55)); c.dots([(12, 5), (11, 6)], darker(head, .3)); c.mask(line(2, 14, 3, 13), YEL, False)

def axe(c, head, shaft=WOOD):
    c.mask(line(3, 14, 10, 5, 1), shaft)
    c.mask({(x, y) for y in range(2, 9) for x in range(7, 14) if (x - 7) + abs(y - 5) * 1.0 <= 6 and x >= 8 - (3 - abs(y - 5)) // 1 + 0}, head)
    c.dots([(9, 4), (10, 3)], lighter(head, .55)); c.dots([(3, 14)], YEL)

def shield(c, col, trim=True, spec=False):
    m = rect(3, 2, 12, 9) | rect(4, 10, 11, 11) | rect(5, 12, 10, 12) | rect(6, 13, 9, 13)
    c.mask(m, DSTEEL)
    c.mask(rect(4, 3, 11, 5), YEL, False); c.mask(rect(4, 6, 11, 8), BLU, False); c.mask(rect(4, 9, 11, 10) | rect(5, 11, 10, 11) | rect(6, 12, 9, 12), RED, False)
    c.dots([(7, 6), (8, 6), (7, 7), (8, 7)], (255, 255, 255)); c.dots([(3, 2), (12, 2), (3, 9), (12, 9)], STEEL)
    if spec: c.dots([(5, 4), (10, 7)], SPEC)

def helmet(c, col, trim, spec=False):
    c.mask(ell(8, 8, 6.5, 6) & {(x, y) for x in range(16) for y in range(16) if y <= 12}, col)
    c.mask(rect(3, 12, 12, 12), darker(col, .15)); c.mask(rect(5, 9, 10, 10), (20, 15, 30), False)
    c.mask(rect(7, 2, 8, 8), trim, False); c.dots([(5, 4), (4, 6)], lighter(col, .6))
    if spec: spk(c, SPEC)

def chest(c, col, trim, spec=False):
    m = rect(4, 3, 11, 13) | rect(1, 3, 4, 7) | rect(11, 3, 14, 7)
    m -= rect(6, 3, 9, 4)
    c.mask(m, col); c.mask(rect(7, 5, 8, 13), trim, False); c.mask(rect(4, 12, 11, 13), darker(col, .15))
    c.dots([(2, 4), (3, 4), (5, 5)], lighter(col, .6)); c.dots([(1, 7), (14, 7)], trim)
    if spec: spk(c, SPEC)

def legs(c, col, trim, spec=False):
    c.mask(rect(3, 2, 12, 5), col); c.mask(rect(3, 6, 6, 14), col); c.mask(rect(9, 6, 12, 14), col)
    c.mask(rect(3, 3, 12, 3), trim, False); c.dots([(4, 7), (4, 8), (10, 7)], lighter(col, .6)); c.dots([(5, 13), (11, 13)], darker(col, .3))
    if spec: spk(c, SPEC)

def boots(c, col, trim, spec=False):
    c.mask(rect(2, 7, 6, 12) | rect(1, 12, 7, 14), col); c.mask(rect(9, 7, 13, 12) | rect(8, 12, 14, 14), col)
    c.mask(rect(2, 8, 6, 8) | rect(9, 8, 13, 8), trim, False); c.dots([(3, 9), (10, 9)], lighter(col, .6))
    if spec: spk(c, SPEC)

# comidas
def d_arepa(col=TAN, filling=None, rim=None, spec=False):
    def f(c, _p=None, s=spec):
        c.mask(disc(8, 8, 6.5), col)
        if rim: c.mask(ring(8, 8, 6.5, 5.2), rim, False)
        c.dots([(5, 5), (6, 4), (4, 6)], lighter(col, .55)); c.dots([(10, 6), (11, 9), (7, 11), (5, 9), (9, 4)], darker(col, .3))
        if filling:
            c.mask(rect(3, 8, 12, 9), darker(col, .45), False)
            c.mask(rect(4, 8, 11, 8), filling, False); c.dots([(5, 9), (8, 9), (10, 9)], lighter(filling, .3))
        if s: spk(c, SPEC)
    return f

def d_cachapa(spec=False):
    def f(c, _p=None, s=spec):
        col = (250, 215, 70) if not s else (190, 235, 235)
        c.mask(ell(8, 10, 7, 6) & {(x, y) for x in range(16) for y in range(16) if y <= 10}, col)
        c.dots([(4, 7), (7, 6), (10, 7), (12, 9), (6, 9), (9, 9), (5, 5), (11, 5)], darker(col, .28))
        c.dots([(5, 6), (8, 5), (10, 6)], lighter(col, .55))
        c.mask(rect(2, 11, 13, 12), (255, 250, 225), False); c.dots([(4, 13), (5, 14), (10, 13)], (255, 250, 225)); c.dots([(7, 12), (11, 12)], (245, 220, 140))
        if s: spk(c, SPEC)
    return f

def d_tequeno(spec=False, glow=False):
    def f(c, _p=None, s=spec):
        col = (225, 165, 55) if not s else (200, 220, 240)
        c.mask(line(3, 13, 12, 4, 3), col)
        c.dots([(5, 11), (7, 9), (9, 7), (6, 12), (8, 10), (10, 8)], darker(col, .3))
        c.dots([(4, 11), (6, 9), (8, 7), (10, 5)], lighter(col, .5))
        c.mask({(12, 3), (13, 3), (13, 4), (12, 2)}, (255, 245, 210), False)
        if s: spk(c, SPEC)
    return f

def d_pabellon(rim=(245, 245, 245), extra=False, spec=False):
    def f(c, _p=None, s=spec):
        c.mask(disc(8, 8, 7), rim)
        c.mask(disc(8, 8, 5.6), lighter(rim, .1) if not s else (200, 225, 240), False)
        rice, beans, plat, meat = (250, 250, 240), (45, 25, 45), (250, 200, 50), (170, 70, 40)
        if s: rice, beans, plat, meat = (210, 245, 250), (60, 40, 90), (180, 230, 240), (150, 110, 200)
        for x in range(3, 13):
            for y in range(3, 13):
                if (x - 7.5) ** 2 + (y - 7.5) ** 2 > 28: continue
                if x < 8 and y < 8: c.dot(x, y, rice if (x + y) % 3 else darker(rice, .08))
                elif x >= 8 and y < 8: c.dot(x, y, beans if (x * y) % 5 else lighter(beans, .3))
                elif x >= 8 and y >= 8: c.dot(x, y, plat if (x + y) % 2 else darker(plat, .2))
                else: c.dot(x, y, meat if (x + y) % 3 else lighter(meat, .25))
        if extra: c.mask(disc(8, 8, 1.8), (255, 250, 240), False); c.dot(8, 8, YEL)
        if s: spk(c, SPEC)
    return f

def d_tizana(spec=False):
    def f(c, _p=None, s=spec):
        liq = (240, 140, 70) if not s else (130, 220, 240)
        c.mask(rect(5, 3, 10, 13), (200, 225, 240))
        c.mask(rect(6, 6, 9, 12), liq, False); c.mask(rect(6, 5, 9, 5), lighter(liq, .35), False)
        c.dots([(6, 7), (6, 8)], (255, 255, 255)); c.dots([(8, 9), (9, 10)], darker(liq, .3))
        c.mask(rect(7, 8, 8, 9), (230, 245, 255), False)
        c.mask(disc(11, 4, 1.8), (230, 60, 60), False); c.dots([(3, 2), (4, 1)], LEAF)
        c.mask(rect(5, 13, 10, 14), DSTEEL if not s else (90, 120, 140))
        if s: spk(c, SPEC)
    return f

def d_hallaca(string=(210, 170, 110), spec=False):
    def f(c, _p=None, s=spec):
        leaf = LEAF if not s else (110, 190, 200)
        c.mask(rect(3, 4, 12, 12), leaf)
        for y in (6, 9, 11): c.dots([(x, y) for x in range(4, 12)], darker(leaf, .22))
        c.mask(rect(7, 4, 8, 12), string, False); c.mask(rect(3, 7, 12, 8), string, False); c.dot(7, 7, lighter(string, .4))
        c.mask({(4, 4), (5, 4), (4, 5), (5, 5), (6, 5)}, (225, 90, 40) if not s else (200, 140, 255), False)
        c.dots([(9, 5), (10, 10)], lighter(leaf, .4))
        if s: spk(c, SPEC)
    return f

def d_banquete(spec=False, gold=False):
    def f(c, _p=None, s=spec):
        c.mask(ell(8, 11, 7.5, 3.5), (210, 215, 225) if not gold else GOLD)
        c.mask(ell(8, 8, 4.3, 3.2), (150, 75, 40) if not s else (150, 110, 200)); c.dots([(6, 6), (7, 6)], (230, 150, 90))
        c.mask(disc(3.5, 8.5, 2.3), TAN if not s else (190, 235, 240)); c.mask(disc(12.5, 8.5, 2.3), TAN if not s else (190, 235, 240))
        c.dots([(3, 8), (12, 8)], lighter(TAN, .5)); c.dots([(8, 4), (7, 3), (9, 3)], LEAF); c.dot(8, 2, (230, 40, 40))
        c.dots([(5, 12), (8, 12), (11, 12)], (250, 200, 50))
        if s: spk(c, SPEC)
    return f

def d_cafe(spec=False):
    def f(c, _p=None, s=spec):
        mug = (240, 235, 220) if not s else (180, 230, 240)
        c.mask(rect(4, 6, 10, 13), mug); c.mask(ring(12, 9, 2.6, 1.2), mug)
        c.mask(rect(5, 6, 9, 7), (80, 45, 25), False); c.dots([(6, 6)], (150, 95, 55)); c.mask(rect(4, 10, 10, 10), RED if not s else VIO, False)
        for (x, y) in [(6, 4), (7, 3), (6, 2), (8, 1), (9, 3), (9, 2)]: c.dot(x, y, (225, 225, 235))
        c.dots([(5, 8), (5, 9)], (255, 255, 255))
        if s: spk(c, SPEC)
    return f

def d_plato2(c, _p=None, s=False):
    c.mask(disc(8, 9, 6.5), (245, 245, 245)); c.mask(disc(8, 9, 4.8), (225, 230, 240), False)
    c.mask(disc(8, 9, 3.3), TAN); c.dots([(7, 8), (6, 9)], lighter(TAN, .5))
    c.mask(ring(8, 6.5, 4, 3), (210, 30, 50), False); c.mask(line(5, 11, 3, 14, 1), (210, 30, 50), False); c.dot(8, 2, (255, 120, 120))

# ---------------------------------------------------------------- catálogo
# (id, nombre, tooltip, función(c), modelo-padre)
ITEMS = []
def add(i, name, tip, fn, parent="generated"): ITEMS.append((i, name, tip, fn, parent))
RJ = (205, 35, 50); NG = (50, 40, 60)
# materiales
add("hilo_rojo", "Hilo Rojo", "Hilo arrancado a un poseído. Base de casi todo tejido del alma.", lambda c: d_thread(c, RJ))
add("nudo_rojo", "Nudo Rojo", "Nudo apretado por un mini-jefe. Une hilos de gran fuerza.", lambda c: d_knot(c, RJ))
add("nucleo_de_hilo", "Núcleo de Hilo", "Corazón de hilo de un jefe mayor. Aún palpita.", lambda c: d_core(c, (190, 30, 60)))
add("hilo_negro", "Hilo Negro", "Fibra oscura de un Espectro Títere. Tuerce todo lo que toca.", lambda c: d_thread(c, NG))
add("hilo_espectral", "Hilo Espectral", "Hilo del Telar Roto. Brilla con luz de otro mundo.", lambda c: d_thread(c, SPEC, True))
add("nudo_de_alma", "Nudo de Alma", "Un alma anudada que flota en el Telar Roto.", lambda c: d_knot(c, VIO, True))
add("ceniza_de_titere", "Ceniza de Títere", "Restos de un títere consumido en el Telar Roto.", lambda c: d_ash(c, (120, 115, 130), True))
add("tela_de_difunto", "Tela de Difunto", "Mortaja tejida con hilos del más allá.", lambda c: d_cloth(c, (150, 140, 175), True))
add("lagrima_de_tejedor", "Lágrima de Tejedor", "Dicen que el Tejedor aún llora su telar roto.", lambda c: d_tear(c, (90, 190, 255), True))
add("maiz_olvidado", "Maíz Olvidado", "Grano del Telar Roto. Solo un Chef sabe molerlo.", lambda c: d_corn(c, (225, 215, 150), True))
add("metal_olvidado", "Metal Olvidado", "Metal frío del Telar Roto. Solo un Herrero sabe forjarlo.", lambda c: d_metal(c, (110, 100, 150), True))
# especiales
add("hilo_de_vida", "Hilo de Vida", "Como un tótem: sostenlo en la mano principal o secundaria. Si mueres, vuelves a la vida (se consume). No se apila.", lambda c: d_vida(c, (235, 60, 80)))
add("hilo_de_cofre", "Hilo de Cofre", "Como un tótem: sostenlo en la mano principal o secundaria. Al morir conservas tu inventario (se consume). No se apila.", lambda c: d_cofre(c, GOLD))
add("hilo_resurreccion_menor", "Hilo de Resurrección Menor", "Devuelve 3 hilos del alma a un jugador no poseído. Solo Guerreros.", lambda c: d_resur(1)(c, (230, 160, 90)))
add("hilo_resurreccion_mayor", "Hilo de Resurrección Mayor", "Devuelve 7 hilos del alma y libera a un poseído. Solo Guerreros.", lambda c: d_resur(2)(c, (225, 225, 240)))
add("hilo_resurreccion_perfecto", "Hilo de Resurrección Perfecto", "Restaura todos los hilos del alma y libera a un poseído. Solo Guerreros.", lambda c: d_resur(3)(c, GOLD))
add("hilo_de_anclaje", "Hilo de Anclaje", "Llévalo en el inventario: evita la aparición de un Espectro Títere (se consume).", lambda c: d_anclaje(c, RJ))
add("hilo_de_liberacion", "Hilo de Liberación", "Clic derecho sobre un poseído para liberarlo.", lambda c: d_liberacion(c, RJ))
add("vela_de_anima", "Vela de Ánima", "Enciéndela sobre el Altar del Tejedor para abrir un portal al Telar Roto.", lambda c: d_vela(c, SPEC))
add("ojo_de_titere", "Ojo de Títere", "Revela las marcas de posesión cercanas (resaltado 10 s).", lambda c: d_ojo(c, VIO, True))
add("espejo_de_forja", "Espejo de Forja", "Muestra si alguien está poseído. Clic en el aire para verte a ti.", lambda c: d_espejo(c, (150, 220, 240)))
add("filo_oscuro", "Filo Oscuro", "Arma maldita: roba vida, pero a veces se cobra un hilo de tu alma.", lambda c: sword(c, (45, 30, 70), (80, 20, 40), (50, 30, 40), 2, (200, 30, 60)), "handheld")
# comidas del chef
add("arepa_basica", "Arepa Básica", "Una arepa calientita. Sacia el hambre.", d_arepa(TAN, (255, 245, 200)))
add("cachapa_veloz", "Cachapa Veloz", "Con queso de mano. Velocidad I durante 60 s.", d_cachapa())
add("tequeno_de_absorcion", "Tequeño de Absorción", "Crujiente por fuera. Absorción II durante 2 min.", d_tequeno())
add("pabellon_criollo", "Pabellón Criollo", "Fuerza I y Resistencia I durante 2 min.", d_pabellon())
add("tizana_de_los_andes", "Tizana de los Andes", "Limpia todos tus efectos y da Visión Nocturna 3 min.", d_tizana())
add("hallaca_legendaria", "Hallaca Legendaria", "Regeneración, Saturación y resistencia al control de posesión.", d_hallaca(GOLD))
add("pabellon_supremo", "Pabellón Supremo", "Fuerza II, Resistencia II y Velocidad I durante 3 min.", d_pabellon((250, 215, 90), True))
add("banquete_criollo", "Banquete Criollo", "Bendice a los aliados cercanos y les restaura 1 hilo del alma.", d_banquete())
add("arepa_de_la_resistencia", "Arepa de la Resistencia", "Frena el drenaje de hilos (la posesión) durante 2 min.", d_arepa(TAN, None, (60, 110, 220)))
add("cafe_de_los_andes", "Café de los Andes", "Despierta a un poseído: lo libera y le deja 1 hilo.", d_cafe())
add("plato_del_segundo_hilo", "Plato del Segundo Hilo", "Revive tu alma sin pasar por el Telar: libera y deja al menos 3 hilos.", d_plato2)
# comidas olvidadas
add("arepa_espectral", "Arepa Espectral", "Solo en el Telar Roto: +25 de Hilo de Vida interno.", d_arepa((190, 235, 240), (230, 250, 255), None, True))
add("cachapa_de_los_caidos", "Cachapa de los Caídos", "Solo en el Telar Roto: +15 de Hilo de Vida y Velocidad II.", d_cachapa(True))
add("tequeno_de_hilo", "Tequeño de Hilo", "Solo en el Telar Roto: +15 de Hilo de Vida y Absorción III.", d_tequeno(True))
add("pabellon_del_mas_alla", "Pabellón del Más Allá", "Solo en el Telar Roto: +30 de Hilo de Vida, Fuerza II y Resistencia II.", d_pabellon((200, 225, 245), False, True))
add("hallaca_eterna", "Hallaca Eterna", "Solo en el Telar Roto: +50 de Hilo de Vida, Regeneración y resistencia al control.", d_hallaca((190, 140, 255), True))
add("banquete_del_segundo_hilo", "Banquete del Segundo Hilo", "Solo en el Telar Roto: restaura por completo el Hilo de Vida de los aliados cercanos.", d_banquete(True, True))
# herrero
add("hacha_de_cobre", "Hacha de Cobre", "Hacha robusta de cobre llanero.", lambda c: axe(c, (200, 110, 70)), "handheld")
add("machete_de_hierro", "Machete de Hierro", "El compañero de todo llanero.", lambda c: machete(c, STEEL), "handheld")
add("lanza_llanera", "Lanza Llanera", "Lanza larga de vaquero, ideal para mantener la distancia.", lambda c: spear(c, STEEL), "handheld")
add("martillo_rompehilos", "Martillo Rompehilos", "Ralentiza a los poseídos que golpea.", lambda c: hammer(c, DSTEEL), "handheld")
add("espada_de_acero", "Espada de Acero", "Hoja de acero llanero.", lambda c: sword(c, (200, 208, 222), YEL, BLU, 2), "handheld")
add("escudo_de_acero_llanero", "Escudo de Acero Llanero", "Bloquea ataques. Lleva los colores de la tierra.", lambda c: shield(c, None))
add("filo_cortahilos", "Filo Cortahilos", "Debilita y marca a los poseídos que corta.", lambda c: sword(c, (215, 225, 240), RED, DSTEEL, 2, (255, 120, 130)), "handheld")
for nm, fn, tr in (("casco", helmet, "Casco"), ("peto", chest, "Peto"), ("pantalones", legs, "Pantalones"), ("botas", boots, "Botas")):
    add(f"{nm}_acero_llanero", f"{tr} de Acero Llanero", "Armadura de acero llanero con los colores de la bandera.",
        (lambda f: lambda c: f(c, (178, 186, 200), YEL))(fn))
add("hacha_espectral", "Hacha Espectral", "Solo en el Telar Roto: ralentiza al enemigo.", lambda c: (axe(c, (120, 200, 230)), spk(c, SPEC)), "handheld")
add("machete_de_alma", "Machete de Alma", "Solo en el Telar Roto: roba vida al golpear.", lambda c: (machete(c, (150, 120, 230)), spk(c, SPEC)), "handheld")
add("lanza_del_mas_alla", "Lanza del Más Allá", "Solo en el Telar Roto: debilita a quien alcanza.", lambda c: (spear(c, (140, 220, 240)), spk(c, SPEC)), "handheld")
add("martillo_de_nudos", "Martillo de Nudos", "Solo en el Telar Roto: inmoviliza a quien golpea.", lambda c: (hammer(c, (110, 90, 170)), spk(c, VIO)), "handheld")
add("filo_del_segundo_hilo", "Filo del Segundo Hilo", "Solo en el Telar Roto: cura a quien lo empuña.", lambda c: (sword(c, (190, 240, 250), (150, 110, 235), (60, 50, 110), 2, (255, 255, 255)), spk(c, SPEC)), "handheld")
for nm, fn, tr in (("casco", helmet, "Casco"), ("peto", chest, "Peto"), ("pantalones", legs, "Pantalones"), ("botas", boots, "Botas")):
    add(f"{nm}_del_tejedor", f"{tr} del Tejedor", "Armadura del Telar. Fuera del Telar Roto te ralentiza.",
        (lambda f: lambda c: f(c, (90, 70, 150), SPEC, True))(fn))

# ---------------------------------------------------------------- escribir
lang = {}
for i, name, tip, fn, parent in ITEMS:
    c = Cv(); fn(c)
    c.image().save(f"{A}/textures/item/{i}.png")
    json.dump({"model": {"type": "minecraft:model", "model": f"{MOD}:item/{i}"}}, open(f"{A}/items/{i}.json", "w"), indent=2)
    json.dump({"parent": f"minecraft:item/{parent}", "textures": {"layer0": f"{MOD}:item/{i}"}}, open(f"{A}/models/item/{i}.json", "w"), indent=2)
    lang[f"item.{MOD}.{i}"] = name
    lang[f"item.{MOD}.{i}.tooltip"] = tip
lang.update({
    f"itemGroup.{MOD}.materiales": "SVZ: Materiales", f"itemGroup.{MOD}.especiales": "SVZ: Hilos y Reliquias",
    f"itemGroup.{MOD}.comidas": "SVZ: Cocina Criolla", f"itemGroup.{MOD}.herrero": "SVZ: Herrería",
    f"{MOD}.tooltip.telar": "Solo funciona en el Telar Roto", f"{MOD}.tooltip.guerrero": "Solo Guerreros",
    f"{MOD}.tooltip.chef": "Recurso exclusivo del Chef", f"{MOD}.tooltip.herrero": "Recurso exclusivo del Herrero",
    f"{MOD}.msg.solo_telar": "Esto solo funciona en el Telar Roto.", f"{MOD}.msg.solo_guerrero": "Solo un Guerrero puede usar este hilo.",
    f"{MOD}.msg.telar_ausente": "El Telar Roto aún no existe en este mundo.", f"{MOD}.msg.ya_telar": "Ya estás en el Telar Roto.",
    f"{MOD}.msg.sin_efecto": "No tiene efecto sobre este objetivo.",
})
for code in ("es_ve", "es_es", "es_mx", "es_ar", "en_us"):
    json.dump(lang, open(f"{A}/lang/{code}.json", "w"), indent=2, ensure_ascii=False)

# capas de armadura (64x32)
def armor_layer(col, trim, name, leggings):
    im = Image.new("RGBA", (64, 32), (0, 0, 0, 0)); rnd = random.Random(name)
    def fill(x0, y0, x1, y1, bands=()):
        for x in range(x0, x1):
            for y in range(y0, y1):
                v = rnd.randint(-10, 10)
                c = tuple(max(0, min(255, col[k] + v)) for k in range(3))
                if (y - y0) in bands: c = trim
                elif x in (x0, x1 - 1) or y in (y0, y1 - 1): c = darker(col, .25)
                im.putpixel((x, y), c + (255,))
    if not leggings:
        fill(0, 0, 32, 16, bands=(7, 8)); fill(16, 16, 40, 32, bands=(15 - 8 + 8,)); fill(40, 16, 56, 32, bands=(2,)); fill(0, 16, 16, 32, bands=(11,))
    else:
        fill(16, 16, 40, 32, bands=(1,)); fill(0, 16, 16, 32, bands=(3,))
    im.save(f"{A}/textures/entity/equipment/humanoid{'_leggings' if leggings else ''}/{name}.png")
for name, col, trim in (("acero_llanero", (178, 186, 200), YEL), ("tejedor", (90, 70, 150), SPEC)):
    armor_layer(col, trim, name, False); armor_layer(col, trim, name, True)
    json.dump({"layers": {"humanoid": [{"texture": f"{MOD}:{name}"}], "humanoid_leggings": [{"texture": f"{MOD}:{name}"}]}},
              open(f"{A}/equipment/{name}.json", "w"), indent=2)

# ---------------------------------------------------------------- recetas
def mc(x): return x if ":" in x else f"minecraft:{x}"
def me(x): return f"{MOD}:{x}"
def shaped(name, pat, key, cat="misc", count=1):
    json.dump({"type": "minecraft:crafting_shaped", "category": cat, "pattern": pat, "key": key,
               "result": {"id": me(name), "count": count}}, open(f"{D}/recipe/{name}.json", "w"), indent=2)
def shapeless(name, ings, cat="misc", count=1):
    json.dump({"type": "minecraft:crafting_shapeless", "category": cat, "ingredients": ings,
               "result": {"id": me(name), "count": count}}, open(f"{D}/recipe/{name}.json", "w"), indent=2)

HR, NR, NH = me("hilo_rojo"), me("nudo_rojo"), me("nucleo_de_hilo")
HN, HE, NA = me("hilo_negro"), me("hilo_espectral"), me("nudo_de_alma")
CT, TD, LT = me("ceniza_de_titere"), me("tela_de_difunto"), me("lagrima_de_tejedor")
MZ, MT = me("maiz_olvidado"), me("metal_olvidado")
# resurrección: requiere aportes de Guerrero (núcleo), Herrero (metal) y Chef (maíz)
shapeless("hilo_resurreccion_menor", [HR, HR, NR, MZ, MT])
shapeless("hilo_resurreccion_mayor", [me("hilo_resurreccion_menor"), NH, NA, MZ, MT])
shapeless("hilo_resurreccion_perfecto", [me("hilo_resurreccion_mayor"), NH, NH, LT, MZ, MT])
shapeless("hilo_de_anclaje", [HN, HR, mc("iron_ingot")])
shapeless("hilo_de_liberacion", [HR, HE, NA, mc("iron_ingot")])
shapeless("vela_de_anima", [mc("candle"), HR, NR, NH])
shapeless("ojo_de_titere", [mc("spider_eye"), HN, HE, NR])
shaped("espejo_de_forja", [" I ", "IGI", " S "], {"I": mc("iron_ingot"), "G": mc("glass_pane"), "S": mc("stick")}, "equipment")
shapeless("filo_oscuro", [me("filo_cortahilos"), HN, HN, NH], "equipment")
# comidas
shapeless("arepa_basica", [mc("wheat"), mc("wheat"), mc("egg")])
shapeless("cachapa_veloz", [mc("wheat"), mc("sugar"), mc("egg"), mc("sweet_berries")])
shapeless("tequeno_de_absorcion", [mc("wheat"), mc("wheat"), mc("milk_bucket")])
shapeless("pabellon_criollo", [mc("cooked_beef"), mc("bowl"), mc("beetroot"), mc("cocoa_beans"), mc("wheat")])
shapeless("tizana_de_los_andes", [mc("glass_bottle"), mc("apple"), mc("sweet_berries"), mc("sugar")])
shapeless("hallaca_legendaria", [me("pabellon_criollo"), NR, mc("golden_carrot"), HR])
shapeless("pabellon_supremo", [me("pabellon_criollo"), NH, mc("cooked_beef"), mc("golden_carrot")])
shapeless("banquete_criollo", [me("pabellon_criollo"), me("hallaca_legendaria"), mc("cake"), NR])
shapeless("arepa_de_la_resistencia", [me("arepa_basica"), HR, HR])
shapeless("cafe_de_los_andes", [mc("cocoa_beans"), mc("cocoa_beans"), mc("sugar"), mc("glass_bottle")])
shapeless("plato_del_segundo_hilo", [mc("bowl"), HR, NR, mc("cooked_chicken")])
shapeless("arepa_espectral", [MZ, MZ, HE])
shapeless("cachapa_de_los_caidos", [MZ, CT, mc("sugar")])
shapeless("tequeno_de_hilo", [MZ, HE, mc("milk_bucket")])
shapeless("pabellon_del_mas_alla", [MZ, TD, NA, mc("cooked_beef")])
shapeless("hallaca_eterna", [MZ, TD, LT, NA])
shapeless("banquete_del_segundo_hilo", [me("hallaca_eterna"), me("pabellon_del_mas_alla"), LT, NA, NH])
# armas del herrero
I, S_, C_ = mc("iron_ingot"), mc("stick"), mc("coal")
shaped("hacha_de_cobre", ["CC", "CS", " S"], {"C": mc("copper_ingot"), "S": S_}, "equipment")
shaped("machete_de_hierro", ["  I", " I ", "S  "], {"I": I, "S": S_}, "equipment")
shaped("lanza_llanera", ["  I", " S ", "S  "], {"I": I, "S": S_}, "equipment")
shaped("martillo_rompehilos", ["IHI", " S ", " S "], {"I": I, "H": HR, "S": S_}, "equipment")
shaped("espada_de_acero", ["C", "I", "S"], {"C": C_, "I": mc("iron_block"), "S": S_}, "equipment")
shaped("escudo_de_acero_llanero", ["ICI", "III", " I "], {"I": I, "C": C_}, "equipment")
shapeless("filo_cortahilos", [me("espada_de_acero"), HR, NR], "equipment")
pat = {"casco": ["III", "ICI"], "peto": ["I I", "ICI", "III"], "pantalones": ["III", "ICI", "I I"], "botas": ["I I", "ICI"]}
for nm, p in pat.items(): shaped(f"{nm}_acero_llanero", p, {"I": I, "C": C_}, "equipment")
shaped("hacha_espectral", ["MH", "MS", " S"], {"M": MT, "H": HE, "S": S_}, "equipment")
shaped("machete_de_alma", ["  M", " N ", "S  "], {"M": MT, "N": NA, "S": S_}, "equipment")
shaped("lanza_del_mas_alla", ["  M", " S ", "H  "], {"M": MT, "S": S_, "H": HE}, "equipment")
shaped("martillo_de_nudos", ["MNM", " S ", " S "], {"M": MT, "N": NA, "S": S_}, "equipment")
shaped("filo_del_segundo_hilo", ["T", "M", "S"], {"T": LT, "M": MT, "S": S_}, "equipment")
pat2 = {"casco": ["MTM", "M M"], "peto": ["M M", "MTM", "MMM"], "pantalones": ["MTM", "M M", "M M"], "botas": ["M M", "T T"]}
for nm, p in pat2.items(): shaped(f"{nm}_del_tejedor", p, {"M": MT, "T": TD}, "equipment")
print("items:", len(ITEMS), "recetas:", len(os.listdir(f"{D}/recipe")))

# hoja de contacto para revisar
sheet = Image.new("RGBA", (16 * 10 * 6, 16 * ((len(ITEMS) + 9) // 10) * 6), (70, 70, 80, 255))
for n, (i, *_r) in enumerate(ITEMS):
    t = Image.open(f"{A}/textures/item/{i}.png").resize((96, 96), Image.NEAREST)
    sheet.alpha_composite(t, ((n % 10) * 96, (n // 10) * 96))
sheet.save("/home/claude/contact.png")
