# SVZ-Items (svz-items)
Ítems, comidas, armas y armaduras de Sobreviviendo a Venezuela. MC 1.21.11 · Fabric · Java 21. Requiere SVZ-Core.

## Compilar
1. Compila SVZ-Core y copia su jar a `libs/svz-core-1.0.0.jar` (usa el svz-core.zip actualizado).
2. `gradle wrapper && ./gradlew build`

## Regenerar texturas / recetas / lang
    python3 gen_assets.py     (necesita Pillow)
Edita ese script para cambiar texturas, textos o recetas.

## Contrato con otros mods
- SVZ-Mobs: marca a sus poseídos con el tag de entidad `svz_poseido` y llama a
  `SVZItemsAPI.consumirAnclaje(player)` antes de generar un Espectro Títere.
- El Telar Roto debe existir como dimensión (por defecto `svzcore:telar_roto`, o la que registres
  con `SVZCoreAPI.setTelarRotoDimension`). La Vela de Ánima te lleva allí.
- Recetas en `data/svz-items/recipe/` (en 1.21.x la carpeta es singular).

## Sistema de clases (antes SVZ-Clases, ahora dentro de SVZ-Items)
- Al entrar por primera vez se elige clase (Chef, Herrero o Guerrero; solo una vez). **K** abre el árbol de habilidades;
  los atajos son V / B / N. Todas las teclas se cambian en Controles > Varios.
- 78 habilidades en 3 ramas por clase, 3 definitivas (1 por día) y 10 combinadas. Nivel de clase = habilidades de ramas desbloqueadas / 3.
- API: `com.svz.clases.api.SVZClasesAPI` (`desbloquear`, `desbloquearSiguiente`, `tiene`, `nivelClase`, `usar`) para conectar misiones
  (por ejemplo con FTB Quests lanzando `/clases dar <jugador> <id>`).
- Admin: `/clases dar <jugador> <id|todo>`, `/clases reiniciar <jugador>`, `/clases cooldowns <jugador>`.
- Config: `config/svz-clases.json` (cooldowns, definitivas por día, radio de combinadas).
- Este jar declara `provides: svz-clases`: no instales también el zip antiguo `svz-clases`.
