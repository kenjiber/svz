# SVZ-Clases (svz-clases)
Chef, Herrero y Guerrero con árboles de habilidades. MC 1.21.11 · Fabric · Java 21. Requiere SVZ-Core y SVZ-Items.

## Compilar
1. Compila SVZ-Core y SVZ-Items y copia sus jars a `libs/`.
2. Añade `gradlew`, `gradlew.bat` y `gradle/` de la plantilla de Fabric y ejecuta `./gradlew build`.

## Jugar
- Al entrar por primera vez se abre la pantalla de selección de clase (solo una vez; usa `SVZCoreAPI.setClase`).
- **K** abre el árbol de habilidades. Selecciona una habilidad, pulsa Usar o equípala a un atajo (teclas V / B / N).
  Todas las teclas se cambian en Controles > Varios.
- Nivel de clase = habilidades de ramas desbloqueadas / 3 (máx. 8 Chef y Herrero, 10 Guerrero).
- Combinadas: se usan desde la pestaña "Combinadas" con los compañeros de las otras clases a menos de 12 bloques.

## SVZ-Quests
`SVZClasesAPI.desbloquearSiguiente(player, rama)` o `desbloquear(player, "chef_1_3")` al completar una misión.
Admin: `/clases dar <jugador> <id|todo>`, `/clases reiniciar <jugador>`, `/clases cooldowns <jugador>`.

## Configuración
`config/svz-clases.json`: multiplicador global de cooldown, cooldowns por id, definitiva por día, radio de combinadas.
