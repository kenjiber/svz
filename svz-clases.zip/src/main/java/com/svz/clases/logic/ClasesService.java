package com.svz.clases.logic;

import com.svz.clases.SVZClasesMod;
import com.svz.clases.data.ClasesPlayer;
import com.svz.clases.net.Net;
import com.svz.clases.skill.Skill;
import com.svz.clases.skill.Skills;
import com.svz.core.api.SVZClass;
import com.svz.core.api.SVZCoreAPI;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/** Lógica de servidor: elegir clase, desbloquear, usar habilidades, cooldowns y sincronía con el cliente. */
public final class ClasesService {
    private ClasesService() {}

    public static void register() {
        Net.registrarPaquetes();
        ServerPlayNetworking.registerGlobalReceiver(Net.ChooseC2S.TYPE, (payload, ctx) -> elegir(ctx.player(), payload.clase()));
        ServerPlayNetworking.registerGlobalReceiver(Net.UseC2S.TYPE, (payload, ctx) -> usar(ctx.player(), payload.id()));
        ServerPlayNetworking.registerGlobalReceiver(Net.RequestC2S.TYPE, (payload, ctx) -> sync(ctx.player(), !SVZCoreAPI.hasElegidoClase(ctx.player())));
        ServerPlayNetworking.registerGlobalReceiver(Net.EquipC2S.TYPE, (payload, ctx) -> {
            ServerPlayer p = ctx.player();
            Skill s = Skills.BY_ID.get(payload.id());
            if (payload.slot() < 0 || payload.slot() > 2 || s == null || !puedeUsar(p, s)) return;
            ClasesPlayer.get(p).equipadas[payload.slot()] = s.id();
            sync(p, false);
        });
        // Primera vez: se abre la pantalla de selección de clase
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayer p = handler.getPlayer();
            sync(p, !SVZCoreAPI.hasElegidoClase(p));
        });
    }

    // ------------------------------------------------------------ clase
    public static void elegir(ServerPlayer p, String nombre) {
        SVZClass c = SVZClass.byName(nombre);
        if (c == null || c == SVZClass.NINGUNA) return;
        if (SVZCoreAPI.hasElegidoClase(p)) {
            p.displayClientMessage(Component.literal("§cYa elegiste tu clase y no se puede cambiar."), true);
            return;
        }
        if (SVZCoreAPI.setClase(p, c)) {
            p.displayClientMessage(Component.literal("§6Has elegido la clase §e" + nombre(c) + "§6."), false);
            sync(p, false);
        }
    }

    public static String nombre(SVZClass c) {
        return switch (c) {
            case CHEF -> "Chef";
            case HERRERO -> "Herrero";
            case GUERRERO -> "Guerrero";
            default -> "Sin clase";
        };
    }

    /** Nivel de clase = habilidades de ramas desbloqueadas / 3 (máx. 8 Chef y Herrero, 10 Guerrero). */
    public static int nivelClase(ServerPlayer p) {
        SVZClass c = SVZCoreAPI.getClase(p);
        int n = 0;
        for (String id : ClasesPlayer.get(p).desbloqueadas) {
            Skill s = Skills.BY_ID.get(id);
            if (s != null && s.clase() == c && s.rama() <= 3) n++;
        }
        return n / 3;
    }

    // ------------------------------------------------------------ desbloqueo (SVZ-Quests)
    /** @return {@code true} si se desbloqueó. Sin {@code forzar}, exige el nivel anterior de la misma rama. */
    public static boolean desbloquear(ServerPlayer p, String id, boolean forzar) {
        Skill s = Skills.BY_ID.get(id);
        ClasesPlayer d = ClasesPlayer.get(p);
        if (s == null || s.esCombinada() || d.desbloqueadas.contains(id)) return false;
        if (s.clase() != SVZCoreAPI.getClase(p) && !forzar) return false;
        if (!forzar && s.rama() <= 3 && s.nivel() > 1) {
            Skill prev = Skills.BY_ID.get(s.clase().getSerializedName() + "_" + s.rama() + "_" + (s.nivel() - 1));
            if (prev != null && !d.desbloqueadas.contains(prev.id())) return false;
        }
        d.desbloqueadas.add(id);
        p.displayClientMessage(Component.literal("§aHabilidad desbloqueada: §f" + s.nombre()), false);
        sync(p, false);
        return true;
    }

    public static boolean puedeUsar(ServerPlayer p, Skill s) {
        if (s.esCombinada()) return true; // requisitos de grupo al usarla
        return s.clase() == SVZCoreAPI.getClase(p) && ClasesPlayer.get(p).desbloqueadas.contains(s.id());
    }

    // ------------------------------------------------------------ uso
    private static long dia(ServerLevel l) {
        return l.getGameTime() / 24000L;
    }

    public static long cooldownRestante(ServerPlayer p, String id) {
        Long fin = ClasesPlayer.get(p).cooldownFin.get(id);
        return fin == null ? 0 : Math.max(0, fin - p.level().getGameTime());
    }

    private static int segundos(Skill s) {
        Integer o = SVZClasesMod.CONFIG.cooldowns.get(s.id());
        return (int) Math.round((o != null ? o : s.cooldown()) * SVZClasesMod.CONFIG.cooldownMultiplicador);
    }

    public static void usar(ServerPlayer p, String id) {
        Skill s = Skills.BY_ID.get(id);
        if (s == null || p.isSpectator() || !(p.level() instanceof ServerLevel level)) return;
        ClasesPlayer d = ClasesPlayer.get(p);
        if (!SVZCoreAPI.hasElegidoClase(p)) return;

        if (!puedeUsar(p, s)) {
            p.displayClientMessage(Component.literal("§cAún no has desbloqueado esta habilidad."), true);
            return;
        }
        long resto = cooldownRestante(p, id);
        if (resto > 0) {
            p.displayClientMessage(Component.literal("§7En enfriamiento: " + (resto / 20 + 1) + " s"), true);
            return;
        }
        if (s.esDefinitiva() && SVZClasesMod.CONFIG.definitivaPorDia && d.definitivaDia == dia(level)) {
            p.displayClientMessage(Component.literal("§cYa usaste tu definitiva hoy."), true);
            return;
        }

        List<ServerPlayer> participantes = new ArrayList<>(List.of(p));
        if (s.esCombinada()) {
            participantes = reunir(level, p, s);
            if (participantes == null) return;
        }

        s.fx().run(level, p);
        efectoVisual(level, p, s);

        long fin = level.getGameTime() + segundos(s) * 20L;
        for (ServerPlayer o : participantes) {
            ClasesPlayer.get(o).cooldownFin.put(id, fin);
            if (o != p) {
                efectoVisual(level, o, s);
                o.displayClientMessage(Component.literal("§6Participas en §e" + s.nombre() + "§6."), true);
                sync(o, false);
            }
        }
        if (s.esDefinitiva()) d.definitivaDia = dia(level);
        p.displayClientMessage(Component.literal("§6" + s.nombre() + "!"), true);
        sync(p, false);
    }

    /** Reúne a los participantes de una combinada y comprueba los requisitos de nivel. Devuelve null si no se cumplen. */
    private static List<ServerPlayer> reunir(ServerLevel level, ServerPlayer p, Skill s) {
        SVZClass mia = SVZCoreAPI.getClase(p);
        if (!s.todos().containsKey(mia) && !s.alguno().containsKey(mia)) {
            p.displayClientMessage(Component.literal("§cTu clase no participa en esta habilidad."), true);
            return null;
        }
        List<ServerPlayer> cerca = level.getEntitiesOfClass(ServerPlayer.class, p.getBoundingBox().inflate(SVZClasesMod.CONFIG.radioCombinadas), o -> !o.isSpectator());
        Map<SVZClass, Integer> mejor = new EnumMap<>(SVZClass.class);
        Map<SVZClass, ServerPlayer> quien = new EnumMap<>(SVZClass.class);
        for (ServerPlayer o : cerca) {
            SVZClass c = SVZCoreAPI.getClase(o);
            int n = nivelClase(o);
            if (n >= mejor.getOrDefault(c, -1)) {
                mejor.put(c, n);
                quien.put(c, o);
            }
        }
        List<ServerPlayer> part = new ArrayList<>();
        for (var e : s.todos().entrySet()) {
            if (mejor.getOrDefault(e.getKey(), -1) < e.getValue()) {
                p.displayClientMessage(Component.literal("§cFalta un " + nombre(e.getKey()) + " de nivel " + e.getValue() + " cerca (" + SVZClasesMod.CONFIG.radioCombinadas + " bloques)."), true);
                return null;
            }
            part.add(quien.get(e.getKey()));
        }
        if (!s.alguno().isEmpty()) {
            ServerPlayer ok = null;
            for (var e : s.alguno().entrySet()) if (mejor.getOrDefault(e.getKey(), -1) >= e.getValue()) ok = quien.get(e.getKey());
            if (ok == null) {
                p.displayClientMessage(Component.literal("§cFalta un compañero de otra clase con nivel suficiente cerca."), true);
                return null;
            }
            part.add(ok);
        }
        if (!part.contains(p)) part.add(p);
        return new ArrayList<>(new java.util.LinkedHashSet<>(part));
    }

    // ------------------------------------------------------------ partículas propias de cada clase
    private static int color(SVZClass c) {
        return switch (c == null ? SVZClass.NINGUNA : c) {
            case CHEF -> 0xFFB000;
            case HERRERO -> 0x6FA8FF;
            case GUERRERO -> 0xE02020;
            default -> 0xC080FF;
        };
    }

    private static void efectoVisual(ServerLevel l, ServerPlayer p, Skill s) {
        DustParticleOptions dust = new DustParticleOptions(color(s.clase() != null ? s.clase() : SVZCoreAPI.getClase(p)), s.esDefinitiva() || s.esCombinada() ? 1.8F : 1.1F);
        double r = s.esDefinitiva() ? 3.5 : (s.esCombinada() ? 2.8 : 1.6);
        int n = s.esDefinitiva() ? 48 : 24;
        for (int i = 0; i < n; i++) {
            double a = i * Math.PI * 2 / n;
            l.sendParticles(dust, p.getX() + Math.cos(a) * r, p.getY() + 0.15 + (i % 3) * 0.5, p.getZ() + Math.sin(a) * r, 1, 0, 0.02, 0, 0.0);
        }
        l.sendParticles(dust, p.getX(), p.getY() + 1, p.getZ(), 14, 0.35, 0.8, 0.35, 0.03);
    }

    // ------------------------------------------------------------ sincronía
    public static void sync(ServerPlayer p, boolean abrirSeleccion) {
        if (p.connection == null) return;
        ClasesPlayer d = ClasesPlayer.get(p);
        List<String> cds = new ArrayList<>();
        for (String id : new ArrayList<>(d.cooldownFin.keySet())) {
            long r = cooldownRestante(p, id);
            if (r > 0) cds.add(id + "|" + r);
            else d.cooldownFin.remove(id);
        }
        boolean defUsada = SVZClasesMod.CONFIG.definitivaPorDia && d.definitivaDia == dia((ServerLevel) p.level());
        ServerPlayNetworking.send(p, new Net.SyncS2C(SVZCoreAPI.getClase(p).getSerializedName(), nivelClase(p), abrirSeleccion, defUsada,
                new ArrayList<>(d.desbloqueadas), cds, List.of(d.equipadas)));
    }
}
