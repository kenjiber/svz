package com.svz.clases.net;

import com.svz.clases.SVZClasesMod;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

import java.util.ArrayList;
import java.util.List;

/** Paquetes de SVZ-Clases. */
public final class Net {
    private Net() {}

    private static void escribir(RegistryFriendlyByteBuf b, List<String> l) {
        b.writeVarInt(l.size());
        for (String s : l) b.writeUtf(s);
    }

    private static List<String> leer(RegistryFriendlyByteBuf b) {
        int n = b.readVarInt();
        List<String> l = new ArrayList<>();
        for (int i = 0; i < n; i++) l.add(b.readUtf());
        return l;
    }

    /** Servidor -> cliente: estado completo. {@code cooldowns} = "id|ticksRestantes". */
    public record SyncS2C(String clase, int nivel, boolean abrirSeleccion, boolean definitivaUsada, List<String> desbloqueadas,
                          List<String> cooldowns, List<String> equipadas) implements CustomPacketPayload {
        public static final Type<SyncS2C> TYPE = new Type<>(SVZClasesMod.id("sync"));
        public static final StreamCodec<RegistryFriendlyByteBuf, SyncS2C> CODEC = StreamCodec.of(
                (b, p) -> {
                    b.writeUtf(p.clase);
                    b.writeVarInt(p.nivel);
                    b.writeBoolean(p.abrirSeleccion);
                    b.writeBoolean(p.definitivaUsada);
                    escribir(b, p.desbloqueadas);
                    escribir(b, p.cooldowns);
                    escribir(b, p.equipadas);
                },
                b -> new SyncS2C(b.readUtf(), b.readVarInt(), b.readBoolean(), b.readBoolean(), leer(b), leer(b), leer(b)));

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    public record ChooseC2S(String clase) implements CustomPacketPayload {
        public static final Type<ChooseC2S> TYPE = new Type<>(SVZClasesMod.id("elegir"));
        public static final StreamCodec<RegistryFriendlyByteBuf, ChooseC2S> CODEC =
                StreamCodec.of((b, p) -> b.writeUtf(p.clase), b -> new ChooseC2S(b.readUtf()));

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    public record UseC2S(String id) implements CustomPacketPayload {
        public static final Type<UseC2S> TYPE = new Type<>(SVZClasesMod.id("usar"));
        public static final StreamCodec<RegistryFriendlyByteBuf, UseC2S> CODEC =
                StreamCodec.of((b, p) -> b.writeUtf(p.id), b -> new UseC2S(b.readUtf()));

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    public record EquipC2S(int slot, String id) implements CustomPacketPayload {
        public static final Type<EquipC2S> TYPE = new Type<>(SVZClasesMod.id("equipar"));
        public static final StreamCodec<RegistryFriendlyByteBuf, EquipC2S> CODEC =
                StreamCodec.of((b, p) -> { b.writeVarInt(p.slot); b.writeUtf(p.id); }, b -> new EquipC2S(b.readVarInt(), b.readUtf()));

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    public record RequestC2S() implements CustomPacketPayload {
        public static final Type<RequestC2S> TYPE = new Type<>(SVZClasesMod.id("pedir"));
        public static final StreamCodec<RegistryFriendlyByteBuf, RequestC2S> CODEC =
                StreamCodec.of((b, p) -> { }, b -> new RequestC2S());

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    public static void registrarPaquetes() {
        PayloadTypeRegistry.playS2C().register(SyncS2C.TYPE, SyncS2C.CODEC);
        PayloadTypeRegistry.playC2S().register(ChooseC2S.TYPE, ChooseC2S.CODEC);
        PayloadTypeRegistry.playC2S().register(UseC2S.TYPE, UseC2S.CODEC);
        PayloadTypeRegistry.playC2S().register(EquipC2S.TYPE, EquipC2S.CODEC);
        PayloadTypeRegistry.playC2S().register(RequestC2S.TYPE, RequestC2S.CODEC);
    }
}
