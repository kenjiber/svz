package com.svz.clases.data;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.svz.clases.SVZClasesMod;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.minecraft.server.level.ServerPlayer;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Habilidades desbloqueadas, cooldowns (tick de juego en que terminan), última definitiva y atajos. */
public class ClasesPlayer {
    public final Set<String> desbloqueadas = new LinkedHashSet<>();
    public final Map<String, Long> cooldownFin = new LinkedHashMap<>();
    public long definitivaDia = -1;
    public final String[] equipadas = {"", "", ""};

    public static AttachmentType<ClasesPlayer> TYPE;

    public static final Codec<ClasesPlayer> CODEC = RecordCodecBuilder.create(i -> i.group(
            Codec.STRING.listOf().optionalFieldOf("desbloqueadas", List.of()).forGetter(d -> new ArrayList<>(d.desbloqueadas)),
            Codec.STRING.listOf().optionalFieldOf("cooldowns", List.of()).forGetter(ClasesPlayer::cooldownsComoLista),
            Codec.LONG.optionalFieldOf("definitiva_dia", -1L).forGetter(d -> d.definitivaDia),
            Codec.STRING.listOf().optionalFieldOf("equipadas", List.of("", "", "")).forGetter(d -> List.of(d.equipadas))
    ).apply(i, ClasesPlayer::new));

    public ClasesPlayer() {}

    private ClasesPlayer(List<String> des, List<String> cds, long defDia, List<String> eq) {
        desbloqueadas.addAll(des);
        for (String s : cds) {
            int k = s.lastIndexOf('|');
            if (k > 0) cooldownFin.put(s.substring(0, k), Long.parseLong(s.substring(k + 1)));
        }
        definitivaDia = defDia;
        for (int i = 0; i < 3 && i < eq.size(); i++) equipadas[i] = eq.get(i);
    }

    private List<String> cooldownsComoLista() {
        List<String> l = new ArrayList<>();
        cooldownFin.forEach((k, v) -> l.add(k + "|" + v));
        return l;
    }

    public static void register() {
        TYPE = AttachmentRegistry.<ClasesPlayer>create(SVZClasesMod.id("jugador"),
                b -> b.initializer(ClasesPlayer::new).persistent(CODEC).copyOnDeath());
    }

    public static ClasesPlayer get(ServerPlayer p) {
        return p.getAttachedOrCreate(TYPE);
    }
}
