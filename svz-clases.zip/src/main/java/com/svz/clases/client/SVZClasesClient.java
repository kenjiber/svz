package com.svz.clases.client;

import com.mojang.blaze3d.platform.InputConstants;
import com.svz.clases.net.Net;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;

/** Teclas configurables (Controles > Varios): K = árbol, V/B/N = atajos de habilidad. */
public class SVZClasesClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // NOTA 1.21.11: el constructor de KeyMapping pide una categoría (KeyMapping.Category). Si cambia, ajusta solo estas 4 líneas.
        KeyMapping abrir = KeyBindingHelper.registerKeyBinding(new KeyMapping("key.svz-clases.arbol", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_K, KeyMapping.Category.MISC));
        KeyMapping[] atajos = {
                KeyBindingHelper.registerKeyBinding(new KeyMapping("key.svz-clases.slot1", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_V, KeyMapping.Category.MISC)),
                KeyBindingHelper.registerKeyBinding(new KeyMapping("key.svz-clases.slot2", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_B, KeyMapping.Category.MISC)),
                KeyBindingHelper.registerKeyBinding(new KeyMapping("key.svz-clases.slot3", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_N, KeyMapping.Category.MISC))
        };

        ClientPlayNetworking.registerGlobalReceiver(Net.SyncS2C.TYPE, (payload, ctx) -> {
            ClasesClient.aplicar(payload);
            Minecraft mc = Minecraft.getInstance();
            if (payload.abrirSeleccion()) {
                if (!(mc.screen instanceof ClaseSeleccionScreen)) mc.setScreen(new ClaseSeleccionScreen());
            } else if (mc.screen instanceof ArbolScreen a) {
                a.refrescar();
            }
        });
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> ClasesClient.reiniciar());

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (mc.player == null) return;
            while (abrir.consumeClick()) {
                if (mc.screen != null) continue;
                if (ClasesClient.clase.equals("ninguna")) ClientPlayNetworking.send(new Net.RequestC2S());
                else {
                    ClientPlayNetworking.send(new Net.RequestC2S()); // refresca cooldowns antes de abrir
                    mc.setScreen(new ArbolScreen());
                }
            }
            for (int i = 0; i < 3; i++) {
                while (atajos[i].consumeClick()) {
                    String id = ClasesClient.equipadas[i];
                    if (!id.isEmpty() && mc.screen == null) ClientPlayNetworking.send(new Net.UseC2S(id));
                }
            }
        });
    }
}
