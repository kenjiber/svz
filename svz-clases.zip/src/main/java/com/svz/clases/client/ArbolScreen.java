package com.svz.clases.client;

import com.svz.clases.net.Net;
import com.svz.clases.skill.Skill;
import com.svz.clases.skill.Skills;
import com.svz.core.api.SVZClass;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.MultiLineTextWidget;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.List;

/**
 * Árbol de habilidades. Pestañas: 3 ramas, definitiva y combinadas. Clic en una habilidad = seleccionarla;
 * a la derecha: usar, equiparla a un atajo rápido (1-3) y ver su cooldown. Hecho solo con widgets estándar.
 */
public class ArbolScreen extends Screen {
    private int tab = 1;
    private String seleccion = "";
    private int ticks;

    public ArbolScreen() {
        super(Component.literal("Habilidades"));
    }

    public void refrescar() {
        rebuild();
    }

    private void rebuild() {
        this.clearWidgets();
        this.init();
    }

    @Override
    public void tick() {
        if (++ticks % 20 == 0) rebuild(); // refresca los cooldowns una vez por segundo
    }

    private SVZClass clase() {
        SVZClass c = SVZClass.byName(ClasesClient.clase);
        return c == null ? SVZClass.NINGUNA : c;
    }

    private List<Skill> lista() {
        return tab <= 4 ? Skills.deRama(clase(), tab) : Skills.combinadas();
    }

    private String etiqueta(Skill s) {
        String pref = s.esCombinada() ? "" : (s.esDefinitiva() ? "★ " : s.nivel() + ". ");
        boolean ok = s.esCombinada() || ClasesClient.desbloqueadas.contains(s.id());
        int cd = ClasesClient.cooldownSeg(s.id());
        String sel = s.id().equals(seleccion) ? "§e> " : "";
        if (!ok) return sel + "§8" + pref + s.nombre() + " (bloqueada)";
        if (cd > 0) return sel + "§c" + pref + s.nombre() + " §7" + cd + "s";
        return sel + "§a" + pref + s.nombre();
    }

    @Override
    protected void init() {
        SVZClass c = clase();
        if (c == SVZClass.NINGUNA) {
            addRenderableWidget(new StringWidget(20, 30, this.width - 40, 12, Component.literal("§7Aún no has elegido clase."), this.font));
            return;
        }
        String[] ramas = Skills.RAMAS.get(c);
        addRenderableWidget(new StringWidget(10, 8, this.width - 20, 12,
                Component.literal("§6" + com.svz.clases.logic.ClasesService.nombre(c) + " §7· nivel " + ClasesClient.nivel
                        + (ClasesClient.definitivaUsada ? " · §cdefinitiva usada hoy" : "")), this.font));

        // pestañas
        String[] nombres = {ramas[0], ramas[1], ramas[2], "Definitiva", "Combinadas"};
        int tw = Math.max(50, (this.width - 20) / 5 - 2);
        for (int i = 0; i < 5; i++) {
            final int t = i + 1;
            Button b = Button.builder(Component.literal((tab == t ? "§e" : "") + nombres[i]), x -> { tab = t; seleccion = ""; rebuild(); })
                    .bounds(10 + i * (tw + 2), 22, tw, 18).build();
            addRenderableWidget(b);
        }

        // lista de habilidades
        List<Skill> skills = lista();
        int n = Math.max(1, skills.size());
        int step = Math.max(14, Math.min(22, (this.height - 90) / n));
        int colW = Math.min(170, this.width / 2 - 14);
        for (int i = 0; i < skills.size(); i++) {
            Skill s = skills.get(i);
            addRenderableWidget(Button.builder(Component.literal(etiqueta(s)), x -> { seleccion = s.id(); rebuild(); })
                    .bounds(10, 48 + i * step, colW, step - 2).build());
        }

        // panel de detalle
        int px = 10 + colW + 10, pw = this.width - px - 10;
        Skill s = Skills.BY_ID.get(seleccion);
        if (s != null) {
            addRenderableWidget(new StringWidget(px, 48, pw, 12, Component.literal("§l" + s.nombre()), this.font));
            addRenderableWidget(new MultiLineTextWidget(px, 64, Component.literal(s.desc()), this.font).setMaxWidth(pw));
            int y = 64 + 12 * 4 + 6;
            String req = "";
            if (s.esCombinada()) req = "§7Requiere cerca: " + reqTexto(s) + "\n";
            int cd = ClasesClient.cooldownSeg(s.id());
            addRenderableWidget(new MultiLineTextWidget(px, y, Component.literal(req + "§7Enfriamiento base: " + s.cooldown() + " s"
                    + (cd > 0 ? "\n§cEn enfriamiento: " + cd + " s" : "\n§aLista")), this.font).setMaxWidth(pw));
            y += 34;
            boolean ok = s.esCombinada() || ClasesClient.desbloqueadas.contains(s.id());
            Button usar = Button.builder(Component.literal("Usar"), x -> ClientPlayNetworking.send(new Net.UseC2S(s.id())))
                    .bounds(px, y, Math.min(pw, 100), 20).build();
            usar.active = ok;
            addRenderableWidget(usar);
            for (int k = 0; k < 3; k++) {
                final int slot = k;
                String actual = ClasesClient.equipadas[k];
                Skill eq = Skills.BY_ID.get(actual);
                Button b = Button.builder(Component.literal("Atajo " + (k + 1) + (eq != null ? ": " + eq.nombre() : ": vacío")),
                        x -> ClientPlayNetworking.send(new Net.EquipC2S(slot, s.id()))).bounds(px, y + 24 + k * 22, Math.min(pw, 170), 20).build();
                b.active = ok && !s.esCombinada();
                addRenderableWidget(b);
            }
        } else {
            addRenderableWidget(new MultiLineTextWidget(px, 48, Component.literal("§7Selecciona una habilidad para ver su descripción.\n"
                    + "§7Las habilidades se desbloquean completando misiones."), this.font).setMaxWidth(pw));
        }
        addRenderableWidget(Button.builder(Component.literal("Cerrar"), x -> this.onClose()).bounds(this.width - 70, this.height - 26, 60, 18).build());
    }

    private static String reqTexto(Skill s) {
        StringBuilder sb = new StringBuilder();
        s.todos().forEach((c, n) -> sb.append(com.svz.clases.logic.ClasesService.nombre(c)).append(' ').append(n).append(" + "));
        if (!s.alguno().isEmpty()) {
            StringBuilder o = new StringBuilder();
            s.alguno().forEach((c, n) -> o.append(o.length() > 0 ? "/" : "").append(com.svz.clases.logic.ClasesService.nombre(c)).append(' ').append(n));
            sb.append(o);
        } else if (sb.length() > 3) {
            sb.setLength(sb.length() - 3);
        }
        return sb.toString();
    }
}
