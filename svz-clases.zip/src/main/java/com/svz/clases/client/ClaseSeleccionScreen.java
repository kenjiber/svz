package com.svz.clases.client;

import com.svz.clases.net.Net;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.MultiLineTextWidget;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Pantalla de selección de clase (solo se puede elegir una vez). Hecha solo con widgets estándar. */
public class ClaseSeleccionScreen extends Screen {
    private static final String[] IDS = {"chef", "herrero", "guerrero"};
    private static final String[] NOMBRES = {"Chef", "Herrero", "Guerrero"};
    private static final String[] DESC = {
            "§6Cocina para la liberación.§r\nSus platos dan fuerza, protegen del drenaje y despiertan a los poseídos. "
                    + "Ramas: Sabores de Combate, Ojo del Cocinero y Cocina de Liberación. Definitiva: El Gran Banquete.",
            "§bForja contra los hilos.§r\nSus armas hieren a los poseídos, repara el equipo y ve lo que otros no ven. "
                    + "Ramas: Forja de Guerra, Ojo del Forjador y Forja de Liberación. Definitiva: La Gran Forja.",
            "§cEl escudo del pueblo.§r\nResiste, lazo y rescate: inmoviliza al poseído para que los demás lo liberen. "
                    + "Ramas: Furia Criolla, Piel de Cobre y Lazo y Rescate. Definitiva: El Último Bastión."
    };

    public ClaseSeleccionScreen() {
        super(Component.literal("Elige tu clase"));
    }

    @Override
    protected void init() {
        int w = Math.min(120, (this.width - 40) / 3 - 6);
        int total = 3 * w + 2 * 10;
        int x0 = (this.width - total) / 2;

        // ← CAMBIO: en 1.21.11 no existe alignCenter(). Centramos manualmente.
        Component tituloTexto = Component.literal("§6Elige tu clase §7(solo puedes elegir una vez)");
        StringWidget titulo = new StringWidget(0, 14, this.width, 12, tituloTexto, this.font);
        int tituloAncho = this.font.width(tituloTexto);
        titulo.setX((this.width - tituloAncho) / 2);
        addRenderableWidget(titulo);

        for (int i = 0; i < 3; i++) {
            int x = x0 + i * (w + 10);
            addRenderableWidget(new StringWidget(x, 40, w, 12, Component.literal("§l" + NOMBRES[i]), this.font));
            addRenderableWidget(new MultiLineTextWidget(x, 58, Component.literal(DESC[i]), this.font).setMaxWidth(w));
            final String id = IDS[i];
            addRenderableWidget(Button.builder(Component.literal("Ser " + NOMBRES[i]), b -> {
                ClientPlayNetworking.send(new Net.ChooseC2S(id));
                this.onClose();
            }).bounds(x, this.height - 44, w, 20).build());
        }
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false; // hay que elegir
    }
}