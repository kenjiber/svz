package com.svz.clases.client;

import com.svz.clases.net.Net;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/** Copia en el cliente del estado del jugador (la rellena el paquete de sincronía). */
public final class ClasesClient {
    private ClasesClient() {}

    public static String clase = "ninguna";
    public static int nivel;
    public static boolean definitivaUsada;
    public static final Set<String> desbloqueadas = new HashSet<>();
    public static final String[] equipadas = {"", "", ""};
    /** Instante (ms) en que termina cada cooldown. */
    private static final Map<String, Long> cooldownFinMs = new HashMap<>();

    public static void aplicar(Net.SyncS2C p) {
        clase = p.clase();
        nivel = p.nivel();
        definitivaUsada = p.definitivaUsada();
        desbloqueadas.clear();
        desbloqueadas.addAll(p.desbloqueadas());
        cooldownFinMs.clear();
        long ahora = System.currentTimeMillis();
        for (String s : p.cooldowns()) {
            int k = s.lastIndexOf('|');
            if (k > 0) cooldownFinMs.put(s.substring(0, k), ahora + Long.parseLong(s.substring(k + 1)) * 50L);
        }
        for (int i = 0; i < 3; i++) equipadas[i] = i < p.equipadas().size() ? p.equipadas().get(i) : "";
    }

    public static void reiniciar() {
        clase = "ninguna";
        nivel = 0;
        desbloqueadas.clear();
        cooldownFinMs.clear();
    }

    /** Segundos de cooldown que quedan (0 = listo). */
    public static int cooldownSeg(String id) {
        Long fin = cooldownFinMs.get(id);
        if (fin == null) return 0;
        long r = fin - System.currentTimeMillis();
        return r <= 0 ? 0 : (int) (r / 1000) + 1;
    }
}
