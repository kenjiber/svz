package com.svz.clases.command;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.svz.clases.data.ClasesPlayer;
import com.svz.clases.logic.ClasesService;
import com.svz.clases.skill.Skill;
import com.svz.clases.skill.Skills;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

import java.util.function.Predicate;

/** /clases dar <jugador> <id|todo> · /clases reiniciar <jugador> · /clases cooldowns <jugador> (admin). */
public final class ClasesCommands {
    private ClasesCommands() {}

    // NOTA 1.21.11: igual que en SVZ-Core, esta línea depende del sistema de permisos.
    private static final Predicate<CommandSourceStack> ADMIN = Commands.hasPermission(Commands.LEVEL_GAMEMASTERS);

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(Commands.literal("clases").requires(ADMIN)
                        .then(Commands.literal("dar")
                                .then(Commands.argument("jugador", EntityArgument.player())
                                        .then(Commands.argument("id", StringArgumentType.word())
                                                .suggests((c, b) -> SharedSuggestionProvider.suggest(Skills.BY_ID.keySet().stream().filter(k -> !k.startsWith("combo")), b))
                                                .executes(ctx -> {
                                                    ServerPlayer p = EntityArgument.getPlayer(ctx, "jugador");
                                                    String id = StringArgumentType.getString(ctx, "id");
                                                    int n = 0;
                                                    if (id.equals("todo")) {
                                                        for (Skill s : Skills.ALL) if (!s.esCombinada() && s.clase() == com.svz.core.api.SVZCoreAPI.getClase(p)) n += ClasesService.desbloquear(p, s.id(), true) ? 1 : 0;
                                                    } else n = ClasesService.desbloquear(p, id, true) ? 1 : 0;
                                                    int total = n;
                                                    ctx.getSource().sendSuccess(() -> Component.literal("Habilidades desbloqueadas: " + total), true);
                                                    return total;
                                                }))))
                        .then(Commands.literal("reiniciar")
                                .then(Commands.argument("jugador", EntityArgument.player()).executes(ctx -> {
                                    ServerPlayer p = EntityArgument.getPlayer(ctx, "jugador");
                                    ClasesPlayer d = ClasesPlayer.get(p);
                                    d.desbloqueadas.clear();
                                    d.cooldownFin.clear();
                                    d.definitivaDia = -1;
                                    ClasesService.sync(p, false);
                                    ctx.getSource().sendSuccess(() -> Component.literal("Habilidades reiniciadas."), true);
                                    return 1;
                                })))
                        .then(Commands.literal("cooldowns")
                                .then(Commands.argument("jugador", EntityArgument.player()).executes(ctx -> {
                                    ServerPlayer p = EntityArgument.getPlayer(ctx, "jugador");
                                    ClasesPlayer.get(p).cooldownFin.clear();
                                    ClasesPlayer.get(p).definitivaDia = -1;
                                    ClasesService.sync(p, false);
                                    ctx.getSource().sendSuccess(() -> Component.literal("Cooldowns limpiados."), true);
                                    return 1;
                                })))));
    }
}
