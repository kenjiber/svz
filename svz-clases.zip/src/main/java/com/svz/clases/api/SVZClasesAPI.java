package com.svz.clases.api;

import com.svz.clases.data.ClasesPlayer;
import com.svz.clases.logic.ClasesService;
import com.svz.clases.skill.Skill;
import com.svz.clases.skill.Skills;
import com.svz.core.api.SVZClass;
import com.svz.core.api.SVZCoreAPI;
import net.minecraft.server.level.ServerPlayer;

/**
 * API pública para SVZ-Quests y otros mods. Una misión completada debe llamar a
 * {@link #desbloquearSiguiente(ServerPlayer, int)} (o a {@link #desbloquear(ServerPlayer, String)} con un id concreto).
 * Ids: {clase}_{rama}_{nivel} (chef_1_8, herrero_3_2, guerrero_2_10), {clase}_def para la definitiva.
 */
public final class SVZClasesAPI {
    private SVZClasesAPI() {}

    /** Desbloquea una habilidad concreta respetando el orden de la rama. */
    public static boolean desbloquear(ServerPlayer p, String id) {
        return ClasesService.desbloquear(p, id, false);
    }

    /** Desbloquea el siguiente nivel pendiente de la rama (1-3) de la clase del jugador. */
    public static boolean desbloquearSiguiente(ServerPlayer p, int rama) {
        SVZClass c = SVZCoreAPI.getClase(p);
        for (Skill s : Skills.deRama(c, rama)) {
            if (!ClasesPlayer.get(p).desbloqueadas.contains(s.id())) return ClasesService.desbloquear(p, s.id(), false);
        }
        return false;
    }

    public static boolean tiene(ServerPlayer p, String id) {
        return ClasesPlayer.get(p).desbloqueadas.contains(id);
    }

    /** Nivel de clase (habilidades de ramas desbloqueadas / 3). */
    public static int nivelClase(ServerPlayer p) {
        return ClasesService.nivelClase(p);
    }

    /** Usa una habilidad por código (misiones, otros mods). */
    public static void usar(ServerPlayer p, String id) {
        ClasesService.usar(p, id);
    }
}
