package com.svz.clases.skill;

import com.svz.core.api.SVZClass;

import java.util.Map;

/**
 * Una habilidad. {@code rama}: 1-3 = ramas, 4 = definitiva, 5 = combinada (clase == null).
 * Las combinadas usan {@code todos} (clases que deben estar presentes con ese nivel) y {@code alguno} (basta una de ellas).
 */
public record Skill(String id, SVZClass clase, int rama, int nivel, String nombre, String desc, int cooldown,
                    Fx fx, Map<SVZClass, Integer> todos, Map<SVZClass, Integer> alguno) {
    public boolean esDefinitiva() {
        return rama == 4;
    }

    public boolean esCombinada() {
        return rama == 5;
    }
}
