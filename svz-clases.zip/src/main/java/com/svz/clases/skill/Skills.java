package com.svz.clases.skill;

import com.svz.core.api.SVZClass;
import net.minecraft.world.effect.MobEffects;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static com.svz.clases.skill.Fx.*;

/**
 * Catálogo completo: Chef 24 + Herrero 24 + Guerrero 30 habilidades, 3 definitivas y 10 combinadas.
 * Ids: {clase}_{rama}_{nivel} (p. ej. chef_1_8), {clase}_def y combo_1..combo_10.
 */
public final class Skills {
    private Skills() {}

    public static final List<Skill> ALL = new ArrayList<>();
    public static final Map<String, Skill> BY_ID = new LinkedHashMap<>();
    public static final Map<SVZClass, String[]> RAMAS = new EnumMap<>(SVZClass.class);

    private static void add(Skill s) {
        ALL.add(s);
        BY_ID.put(s.id(), s);
    }

    /** Constructor de ramas: cada llamada a {@link #s} añade el siguiente nivel. */
    private static final class Rama {
        final SVZClass clase;
        final int rama;
        int nivel = 0;

        Rama(SVZClass clase, int rama) {
            this.clase = clase;
            this.rama = rama;
        }

        Rama s(String nombre, String desc, int cd, Fx fx) {
            nivel++;
            add(new Skill(clase.getSerializedName() + "_" + rama + "_" + nivel, clase, rama, nivel, nombre, desc, cd, fx, Map.of(), Map.of()));
            return this;
        }
    }

    private static void def(SVZClass c, String nombre, String desc, int cd, Fx fx) {
        add(new Skill(c.getSerializedName() + "_def", c, 4, 1, nombre, desc, cd, fx, Map.of(), Map.of()));
    }

    private static int combo = 0;

    private static void combo(String nombre, String desc, int cd, Fx fx, Map<SVZClass, Integer> todos, Map<SVZClass, Integer> alguno) {
        combo++;
        add(new Skill("combo_" + combo, null, 5, combo, nombre, desc, cd, fx, todos, alguno));
    }

    private static Map<SVZClass, Integer> m(Object... kv) {
        Map<SVZClass, Integer> r = new EnumMap<>(SVZClass.class);
        for (int i = 0; i < kv.length; i += 2) r.put((SVZClass) kv[i], (Integer) kv[i + 1]);
        return r;
    }

    static {
        RAMAS.put(SVZClass.CHEF, new String[]{"Sabores de Combate", "Ojo del Cocinero", "Cocina de Liberación"});
        RAMAS.put(SVZClass.HERRERO, new String[]{"Forja de Guerra", "Ojo del Forjador", "Forja de Liberación"});
        RAMAS.put(SVZClass.GUERRERO, new String[]{"Furia Criolla", "Piel de Cobre", "Lazo y Rescate"});

        // ============================================================ CHEF
        new Rama(SVZClass.CHEF, 1)
                .s("Arepa Básica", "Comida de campaña: te cura 2 corazones y sacia el hambre.", 60, yo(curar(2), saciar(8)))
                .s("Cachapa Veloz", "Velocidad I (60 s) a los aliados cercanos.", 75, aliados(4, buff(MobEffects.SPEED, 60, 0)))
                .s("Tequeño", "Absorción II (2 min) a los aliados cercanos.", 90, aliados(4, buff(MobEffects.ABSORPTION, 120, 1)))
                .s("Pabellón", "Fuerza I y Resistencia I (2 min) a los aliados.", 120, aliados(5, buff(MobEffects.STRENGTH, 120, 0), buff(MobEffects.RESISTANCE, 120, 0)))
                .s("Tizana", "Limpia efectos negativos y da Visión Nocturna.", 90, aliados(5, limpiar(), buff(MobEffects.NIGHT_VISION, 180, 0)))
                .s("Hallaca", "Regeneración II, saturación y resistencia al control.", 150, aliados(6, buff(MobEffects.REGENERATION, 20, 1), saciar(6), resControl(60)))
                .s("Pabellón Supremo", "Fuerza II, Resistencia II y Velocidad I (3 min).", 200, aliados(6, buff(MobEffects.STRENGTH, 180, 1), buff(MobEffects.RESISTANCE, 180, 1), buff(MobEffects.SPEED, 180, 0)))
                .s("Banquete Criollo", "Gran buff en área y +1 hilo del alma a los aliados.", 300, aliados(8, buff(MobEffects.REGENERATION, 30, 0), buff(MobEffects.STRENGTH, 60, 0), buff(MobEffects.RESISTANCE, 60, 0), hilos(1)));
        new Rama(SVZClass.CHEF, 2)
                .s("Olfato de Mercado", "Resalta aldeanos y comerciantes en 32 bloques.", 60, aldeanos(32, 20))
                .s("Ojo de Títere", "Revela las marcas de posesión en 24 bloques.", 90, detectar(24, 10))
                .s("Rastro de Hilo", "Una línea de luz te guía al poseído más cercano.", 60, rastro(64))
                .s("Paladar Fino", "Percibe el veneno: limpia tus efectos negativos y te protege.", 120, aliados(6, limpiar(), buff(MobEffects.RESISTANCE, 30, 0)))
                .s("Visión de Banquete", "Resalta a tus aliados cercanos para encontrarlos.", 60, resaltarAliados(24, 15))
                .s("Susurro Detectado", "Detecta a los jugadores con síntomas de posesión (32 bloques).", 120, detectar(32, 15))
                .s("Ojo del Tejedor", "Revela marcas y vetas del Telar en 16 bloques.", 150, varios(detectar(32, 15), vetas(16)))
                .s("Percepción Total", "Todo a la vez: marcas, vetas, aldeanos y rastro.", 240, varios(todoDetectado(16), rastro(64)));
        new Rama(SVZClass.CHEF, 3)
                .s("Sopa Reconfortante", "Cura 4 corazones y limpia efectos negativos a los aliados.", 90, aliados(6, curar(4), limpiar()))
                .s("Arepa de la Resistencia", "Frena el drenaje de hilos (2 min) a los aliados.", 120, aliados(6, resControl(120)))
                .s("Tizana Purificadora", "Limpia y libera a los jugadores poseídos cercanos.", 240, aliados(6, limpiar(), liberar(1)))
                .s("Hallaca Espectral", "Regeneración II, Resistencia II y resistencia al control.", 180, aliados(6, buff(MobEffects.REGENERATION, 30, 1), buff(MobEffects.RESISTANCE, 30, 1), resControl(60)))
                .s("Papelón Energético", "Velocidad II y Prisa II (1 min) y saciedad.", 120, aliados(8, buff(MobEffects.SPEED, 60, 1), buff(MobEffects.HASTE, 60, 1), saciar(8)))
                .s("Café de los Andes", "Despierta a los poseídos cercanos y les deja 1 hilo.", 240, aliados(8, liberar(1)))
                .s("Banquete de Liberación", "Libera, protege del drenaje (3 min) y da +1 hilo.", 360, aliados(10, liberar(2), resControl(180), hilos(1)))
                .s("Plato del Segundo Hilo", "Revive tu alma: +2 hilos, libera y regenera al grupo.", 480, aliados(10, hilos(2), liberar(3), buff(MobEffects.REGENERATION, 20, 1)));
        def(SVZClass.CHEF, "El Gran Banquete", "Banquete legendario: cura total, buffs mayores y +2 hilos en 12 bloques. (1 por día)", 600,
                aliados(12, curar(20), saciar(20), buff(MobEffects.REGENERATION, 60, 1), buff(MobEffects.STRENGTH, 90, 1), buff(MobEffects.RESISTANCE, 90, 1), hilos(2), resControl(120)));

        // ============================================================ HERRERO
        new Rama(SVZClass.HERRERO, 1)
                .s("Hacha de Cobre", "Fuerza I y Prisa I (1 min): el filo de cobre te sigue.", 60, yo(buff(MobEffects.STRENGTH, 60, 0), buff(MobEffects.HASTE, 60, 0)))
                .s("Machete de Hierro", "Fuerza I y Velocidad I (1 min).", 60, yo(buff(MobEffects.STRENGTH, 60, 0), buff(MobEffects.SPEED, 60, 0)))
                .s("Lanza Llanera", "Te lanzas hacia delante y hieres a quien encuentres.", 45, varios(impulso(1.2), dano(3, 6, false)))
                .s("Martillo Rompehilos", "Golpe en área (8 de daño) que ralentiza a los poseídos.", 90, dano(4, 8, false, ef(MobEffects.SLOWNESS, 4, 1)))
                .s("Espada de Acero", "Fuerza II y Prisa II (1 min).", 90, yo(buff(MobEffects.STRENGTH, 60, 1), buff(MobEffects.HASTE, 60, 1)))
                .s("Escudo de Acero", "Resistencia II (1 min) y Absorción.", 90, yo(buff(MobEffects.RESISTANCE, 60, 1), buff(MobEffects.ABSORPTION, 60, 1)))
                .s("Filo Cortahilos", "Corta a los poseídos cercanos: 10 de daño, debilidad y resplandor.", 120, dano(6, 10, true, ef(MobEffects.WEAKNESS, 8, 0), ef(MobEffects.GLOWING, 8, 0)))
                .s("Armadura Acero", "Resistencia III, Absorción III y resistencia al fuego (1 min).", 180, yo(buff(MobEffects.RESISTANCE, 60, 2), buff(MobEffects.ABSORPTION, 60, 2), buff(MobEffects.FIRE_RESISTANCE, 60, 0)));
        new Rama(SVZClass.HERRERO, 2)
                .s("Ojo de Mineral", "Marca los minerales en 12 bloques.", 60, minerales(12))
                .s("Espejo de Forja", "Muestra el estado de posesión del ser que miras.", 30, inspeccionar(12))
                .s("Análisis de Hilo", "Informa de todos los hilos corruptos en 16 bloques.", 60, analisisHilo(16))
                .s("Lectura de Planos", "Marca los cofres y barriles en 16 bloques.", 90, cofres(16))
                .s("Visión de Nudo", "Revela marcas y vetas del Telar.", 120, varios(detectar(24, 10), vetas(16)))
                .s("Escáner de Alma", "Muestra los hilos y la posesión de los jugadores cercanos.", 90, escanerAlma(24))
                .s("Ojo del Tejedor Oscuro", "Minerales, cofres y vetas a la vez (16 bloques).", 180, varios(minerales(16), cofres(16), vetas(16)))
                .s("Percepción de Forja", "Todo lo oculto a tu alrededor.", 240, varios(todoDetectado(16), analisisHilo(32)));
        new Rama(SVZClass.HERRERO, 3)
                .s("Yunque Portátil", "Repara por completo tu equipo.", 180, yo(reparar()))
                .s("Cuchillo de Hilo", "Hiere a los poseídos cercanos (8) y los debilita.", 60, dano(5, 8, true, ef(MobEffects.WEAKNESS, 6, 0)))
                .s("Templar", "Repara tu equipo y te da Resistencia II (1 min).", 240, yo(reparar(), buff(MobEffects.RESISTANCE, 60, 1)))
                .s("Ancla de Hilo", "Frena el drenaje de hilos (90 s).", 120, yo(resControl(90)))
                .s("Corte Preciso", "Golpe de 20 de daño al ser que miras.", 90, golpeFrente(8, 20))
                .s("Ancla de Alma", "Frena el drenaje de hilos (2,5 min) a los aliados.", 240, aliados(8, resControl(150)))
                .s("Filo Oscuro", "Fuerza III y regeneración (30 s): el filo se alimenta del enemigo.", 180, yo(buff(MobEffects.STRENGTH, 30, 2), buff(MobEffects.REGENERATION, 10, 2)))
                .s("Forja del Segundo Hilo", "Repara el equipo del grupo, libera y da +1 hilo.", 480, aliados(8, reparar(), liberar(2), hilos(1)));
        def(SVZClass.HERRERO, "La Gran Forja", "Forja legendaria: repara y potencia al grupo, +2 hilos y resistencia al control. (1 por día)", 600,
                aliados(12, reparar(), buff(MobEffects.STRENGTH, 90, 2), buff(MobEffects.HASTE, 90, 2), buff(MobEffects.RESISTANCE, 90, 1), hilos(2), resControl(120)));

        // ============================================================ GUERRERO
        new Rama(SVZClass.GUERRERO, 1)
                .s("Golpe Firme", "Fuerza I (20 s).", 20, yo(buff(MobEffects.STRENGTH, 20, 0)))
                .s("Embestida", "Cargas hacia delante hiriendo a los enemigos (6).", 30, varios(impulso(1.4), dano(2.5, 6, false)))
                .s("Machete doble", "Prisa II y Velocidad I (30 s): golpeas dos veces más rápido.", 45, yo(buff(MobEffects.HASTE, 30, 1), buff(MobEffects.SPEED, 30, 0)))
                .s("Grito de Guerra", "Fuerza y Velocidad a los aliados; debilita a los enemigos.", 90, varios(aliados(8, buff(MobEffects.STRENGTH, 30, 0), buff(MobEffects.SPEED, 30, 0)), dano(8, 0, false, ef(MobEffects.WEAKNESS, 8, 0))))
                .s("Corte Cruzado", "Doble tajo en área (10 de daño).", 40, dano(3.5, 10, false))
                .s("Furia Llanera", "Fuerza II y Velocidad II (30 s).", 90, yo(buff(MobEffects.STRENGTH, 30, 1), buff(MobEffects.SPEED, 30, 1)))
                .s("Torbellino", "Giras y apartas a los enemigos (12 de daño).", 60, torbellino(5, 12))
                .s("Golpe Rompenudos", "25 de daño a los poseídos cercanos y los debilita.", 90, dano(5, 25, true, ef(MobEffects.WEAKNESS, 8, 1)))
                .s("Furia del Segundo Hilo", "Fuerza III, Regeneración II y protección del control.", 180, yo(buff(MobEffects.STRENGTH, 30, 2), buff(MobEffects.REGENERATION, 10, 1), resControl(30)))
                .s("Golpe Final", "Golpe devastador (40) al ser que miras.", 120, golpeFrente(6, 40));
        new Rama(SVZClass.GUERRERO, 2)
                .s("Piel Dura", "Resistencia I (30 s).", 30, yo(buff(MobEffects.RESISTANCE, 30, 0)))
                .s("Escudo Firme", "Absorción II (30 s).", 45, yo(buff(MobEffects.ABSORPTION, 30, 1)))
                .s("Muro de Escudos", "Resistencia I (20 s) a los aliados cercanos.", 60, aliados(6, buff(MobEffects.RESISTANCE, 20, 0)))
                .s("Resistencia Criolla", "Limpia efectos negativos y frena el drenaje (30 s).", 90, yo(limpiar(), resControl(30)))
                .s("Aguante Llanero", "Regeneración I (30 s) y saciedad.", 90, yo(buff(MobEffects.REGENERATION, 30, 0), saciar(6)))
                .s("Piel de Acero", "Resistencia II (30 s).", 90, yo(buff(MobEffects.RESISTANCE, 30, 1)))
                .s("Fortaleza", "Absorción III (1 min) y Resistencia I.", 120, yo(buff(MobEffects.ABSORPTION, 60, 2), buff(MobEffects.RESISTANCE, 60, 0)))
                .s("Corazón del Pueblo", "Cura 5 corazones y regenera a los aliados.", 150, aliados(8, curar(5), buff(MobEffects.REGENERATION, 10, 0)))
                .s("Escudo del Segundo Hilo", "Frena el drenaje (2 min) y Resistencia II a los aliados.", 240, aliados(8, resControl(120), buff(MobEffects.RESISTANCE, 30, 1)))
                .s("Inquebrantable", "Resistencia IV, Absorción IV y fuego inofensivo (10 s).", 300, yo(buff(MobEffects.RESISTANCE, 10, 3), buff(MobEffects.ABSORPTION, 10, 3), buff(MobEffects.FIRE_RESISTANCE, 10, 0)));
        new Rama(SVZClass.GUERRERO, 3)
                .s("Lazo Básico", "Arrastra hacia ti al enemigo que miras (8 bloques).", 20, lazo(8))
                .s("Tiro de Lazo", "Lanzas el lazo a 14 bloques.", 30, lazo(14))
                .s("Captura Firme", "Ralentiza fuertemente al objetivo (5 s).", 45, inmovilizar(10, 5, 3, false))
                .s("Lazo Reforzado", "Ralentiza y debilita al objetivo (8 s).", 60, inmovilizar(12, 8, 4, true))
                .s("Inmovilización Total", "Deja casi inmóvil al objetivo (8 s).", 90, inmovilizar(12, 8, 6, true))
                .s("Red de Contención", "Ralentiza a todos los enemigos en 8 bloques (6 s).", 120, dano(8, 0, false, ef(MobEffects.SLOWNESS, 6, 4)))
                .s("Anclaje", "Frena el drenaje (1 min) a los aliados cercanos.", 90, aliados(6, resControl(60)))
                .s("Rescate Rápido", "Libera y cura a los aliados poseídos en 16 bloques.", 150, aliados(16, liberar(1), curar(3)))
                .s("Cadenas del Segundo Hilo", "Inmoviliza a los poseídos cercanos (10 s).", 240, dano(10, 0, true, ef(MobEffects.SLOWNESS, 10, 6), ef(MobEffects.WEAKNESS, 10, 0)))
                .s("Abrazo del Escudo", "Resistencia IV y Absorción III al grupo (10 s).", 180, aliados(6, buff(MobEffects.RESISTANCE, 10, 3), buff(MobEffects.ABSORPTION, 10, 2)));
        def(SVZClass.GUERRERO, "El Último Bastión", "Te plantas: Resistencia máxima al grupo y apartas a los enemigos. (1 por día)", 600,
                varios(aliados(10, buff(MobEffects.RESISTANCE, 20, 3), buff(MobEffects.ABSORPTION, 20, 4), resControl(60)), torbellino(8, 15)));

        // ============================================================ COMBINADAS
        SVZClass C = SVZClass.CHEF, H = SVZClass.HERRERO, G = SVZClass.GUERRERO;
        combo("Comida Forjada", "Chef 5 + Herrero 5: platos forjados. Fuerza II y Resistencia II (90 s) al grupo.", 240,
                aliados(8, buff(MobEffects.STRENGTH, 90, 1), buff(MobEffects.RESISTANCE, 90, 1), buff(MobEffects.HASTE, 90, 1)), m(C, 5, H, 5), m());
        combo("Ritual de Liberación", "Chef 6 + Herrero 6: libera a los poseídos en 10 bloques.", 360,
                aliados(10, liberar(3), limpiar()), m(C, 6, H, 6), m());
        combo("Ancla Espectral", "Chef 7 + Herrero 7: frena el drenaje (3 min) y entrega un Hilo de Anclaje.", 420,
                aliados(10, resControl(180), dar("hilo_de_anclaje", 1)), m(C, 7, H, 7), m());
        combo("Segundo Hilo", "Chef 8 + Herrero 8: +2 hilos, libera y regenera al grupo.", 600,
                aliados(12, hilos(2), liberar(3), buff(MobEffects.REGENERATION, 30, 1)), m(C, 8, H, 8), m());
        combo("Escolta de Mazmorra", "Guerrero 4 + Chef/Herrero 4: Resistencia III y Velocidad II (1 min).", 240,
                aliados(10, buff(MobEffects.RESISTANCE, 60, 2), buff(MobEffects.SPEED, 60, 1)), m(G, 4), m(C, 4, H, 4));
        combo("Liberación Protegida", "Guerrero 6 + Chef 6: libera a los poseídos y los protege (20 s).", 360,
                aliados(10, liberar(3), buff(MobEffects.RESISTANCE, 20, 3), resControl(60)), m(G, 6, C, 6), m());
        combo("Corte y Captura", "Guerrero 7 + Herrero 7: 15 de daño y captura total en 8 bloques.", 300,
                dano(8, 15, false, ef(MobEffects.SLOWNESS, 8, 6), ef(MobEffects.WEAKNESS, 8, 1)), m(G, 7, H, 7), m());
        combo("Banquete de Guerra", "Guerrero 8 + Chef 8: Fuerza III, Regeneración III y Resistencia III (30 s).", 480,
                aliados(10, buff(MobEffects.STRENGTH, 30, 2), buff(MobEffects.REGENERATION, 30, 2), buff(MobEffects.RESISTANCE, 30, 2)), m(G, 8, C, 8), m());
        combo("Trío del Segundo Hilo", "Guerrero 10 + Chef 8 + Herrero 8: +3 hilos, cura total y todos los buffs.", 900,
                aliados(14, hilos(3), liberar(5), curar(20), reparar(), buff(MobEffects.REGENERATION, 60, 2), buff(MobEffects.STRENGTH, 60, 2), buff(MobEffects.RESISTANCE, 60, 2), resControl(180)),
                m(G, 10, C, 8, H, 8), m());
        combo("Ritual de Rescate Mayor", "Chef 8 + Herrero 8 + Guerrero 8: libera a todos los poseídos y restaura sus hilos.", 1200,
                aliados(16, liberar(5), limpiar(), hilos(3), curar(20)), m(C, 8, H, 8, G, 8), m());
    }

    /** @return las habilidades de una clase y rama (1-3), 4 = definitiva. */
    public static List<Skill> deRama(SVZClass clase, int rama) {
        List<Skill> r = new ArrayList<>();
        for (Skill s : ALL) if (s.clase() == clase && s.rama() == rama) r.add(s);
        return r;
    }

    public static List<Skill> combinadas() {
        List<Skill> r = new ArrayList<>();
        for (Skill s : ALL) if (s.esCombinada()) r.add(s);
        return r;
    }
}
