package com.svz.clases;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

/** config/svz-clases.json. Los cooldowns se pueden sobrescribir por habilidad: "cooldowns": {"chef_1_8": 120}. */
public class ClasesConfig {
    /** Multiplica todos los cooldowns (0.5 = la mitad). */
    public double cooldownMultiplicador = 1.0;
    /** Cooldown en segundos por id de habilidad (sobrescribe el de fábrica). */
    public Map<String, Integer> cooldowns = new LinkedHashMap<>();
    /** Las definitivas se pueden usar una vez por día de servidor (24000 ticks). Pon false para una sola vez por sesión de servidor. */
    public boolean definitivaPorDia = true;
    /** Radio para reunir a los participantes de una habilidad combinada. */
    public int radioCombinadas = 12;

    public static ClasesConfig load() {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        Path file = FabricLoader.getInstance().getConfigDir().resolve("svz-clases.json");
        try {
            if (Files.exists(file)) {
                ClasesConfig c = gson.fromJson(Files.readString(file), ClasesConfig.class);
                if (c != null) return c;
            }
            ClasesConfig def = new ClasesConfig();
            Files.writeString(file, gson.toJson(def));
            return def;
        } catch (Exception e) {
            SVZClasesMod.LOGGER.warn("No se pudo leer svz-clases.json, usando valores por defecto", e);
            return new ClasesConfig();
        }
    }
}
