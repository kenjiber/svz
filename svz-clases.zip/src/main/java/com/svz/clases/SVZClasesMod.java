package com.svz.clases;

import com.svz.clases.command.ClasesCommands;
import com.svz.clases.data.ClasesPlayer;
import com.svz.clases.logic.ClasesService;
import net.fabricmc.api.ModInitializer;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SVZClasesMod implements ModInitializer {
    public static final String MOD_ID = "svz-clases";
    public static final Logger LOGGER = LoggerFactory.getLogger("SVZ-Clases");
    public static ClasesConfig CONFIG;

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        CONFIG = ClasesConfig.load();
        ClasesPlayer.register();
        ClasesService.register();
        ClasesCommands.register();
        LOGGER.info("SVZ-Clases cargado.");
    }
}
