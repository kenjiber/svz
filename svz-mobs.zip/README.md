# SVZ-Mobs (svz-mobs)
Mobs poseídos, títeres, espectros y jefes de Sobreviviendo a Venezuela. MC 1.21.11 · Fabric · Java 21.
Requiere SVZ-Core y SVZ-Items.

## Compilar
1. Compila SVZ-Core y SVZ-Items; copia sus jars a `libs/` (svz-core-1.0.0.jar, svz-items-1.0.0.jar).
2. `gradle wrapper && ./gradlew build`
Si el compilador no encuentra una clase vanilla (Cow, Zombie, Warden...), Mojang pudo moverla de paquete en
1.21.11: usa Alt+Enter en IntelliJ para corregir el import.

## Probar
- `/svzmobs spawn <id>` (admin) genera cualquier mob; `SVZMobsAPI.spawn(...)` hace lo mismo desde otros mods.
- Config en `config/svz-mobs.json` (golpes por drenaje, spawn diario, probabilidades, ritual).

## Ritual de liberación
Clic derecho en un poseído con Hilo de Liberación → fase 1 (adds) → fase 2 (el Herrero golpea el Núcleo flotante)
→ fase 3 (soga + Arepa de la Resistencia). Si el poseído muere antes, se transforma en mini-jefe.

## Pendiente: modelos y animaciones propios
Ahora cada mob reutiliza el modelo vanilla de su base (ojos rojos e hilos son partículas). Para modelos propios con
GeckoLib: crea los .geo.json/.animation.json en Blockbench, añade GeckoLib y cambia los renderers en SVZMobsClient.
