package com.svz.mobs.entity;

import com.svz.mobs.SVZMobsMod;
import com.svz.mobs.entity.boss.BossProfile;
import com.svz.mobs.entity.boss.BossProfiles;
import com.svz.mobs.entity.boss.SVZBoss;
import com.svz.mobs.entity.possessed.*;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;

import java.util.LinkedHashMap;
import java.util.Map;

/** Registro de las 24 entidades de SVZ-Mobs con Fabric API. */
public final class ModEntities {
    private ModEntities() {}

    public static final Map<String, EntityType<? extends Mob>> ALL = new LinkedHashMap<>();
    public static final Map<String, EntityType<SVZBoss>> BOSSES = new LinkedHashMap<>();

    public static EntityType<PossessedCow> VACA;
    public static EntityType<PossessedPig> CERDO;
    public static EntityType<PossessedSheep> OVEJA;
    public static EntityType<PossessedVillager> ALDEANO;
    public static EntityType<PossessedWolf> LOBO;
    public static EntityType<PossessedCreeper> CREEPER;
    public static EntityType<PossessedGolem> GOLEM;
    public static EntityType<PossessedPiglin> PIGLIN;
    public static EntityType<PossessedWarden> WARDEN;

    private static <T extends Mob> EntityType<T> reg(String id, EntityType.EntityFactory<T> factory, float w, float h, AttributeSupplier.Builder attrs) {
        ResourceKey<EntityType<?>> key = ResourceKey.create(Registries.ENTITY_TYPE, SVZMobsMod.id(id));
        EntityType<T> type = EntityType.Builder.of(factory, MobCategory.MONSTER).sized(w, h).clientTrackingRange(10).build(key);
        Registry.register(BuiltInRegistries.ENTITY_TYPE, key, type);
        FabricDefaultAttributeRegistry.register(type, attrs);
        ALL.put(id, type);
        return type;
    }

    public static void register() {
        // Hilo Menor
        VACA = reg("vaca_poseida", PossessedCow::new, 0.9F, 1.4F, PossessedCow.attributes());
        CERDO = reg("cerdo_poseido", PossessedPig::new, 0.9F, 0.9F, PossessedPig.attributes());
        OVEJA = reg("oveja_poseida", PossessedSheep::new, 0.9F, 1.3F, PossessedSheep.attributes());
        // Hilo Medio
        ALDEANO = reg("aldeano_poseido", PossessedVillager::new, 0.6F, 1.95F, PossessedVillager.attributes());
        LOBO = reg("lobo_poseido", PossessedWolf::new, 0.6F, 0.85F, PossessedWolf.attributes());
        CREEPER = reg("creeper_poseido", PossessedCreeper::new, 0.6F, 1.7F, PossessedCreeper.attributes());
        // Hilo Mayor
        GOLEM = reg("golem_poseido", PossessedGolem::new, 1.4F, 2.7F, PossessedGolem.attributes());
        PIGLIN = reg("piglin_poseido", PossessedPiglin::new, 0.6F, 1.95F, PossessedPiglin.attributes());
        WARDEN = reg("warden_poseido", PossessedWarden::new, 0.9F, 2.9F, PossessedWarden.attributes());

        // mini-jefes, espectros y jefes de zona (una clase dirigida por perfil)
        for (BossProfile p : BossProfiles.ALL) {
            EntityType<SVZBoss> t = reg(p.id, (type, level) -> new SVZBoss(type, level, p), 0.6F, 1.95F, SVZBoss.attributes(p));
            BOSSES.put(p.id, t);
        }
    }
}
