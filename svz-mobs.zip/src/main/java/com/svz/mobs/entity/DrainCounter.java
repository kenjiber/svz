package com.svz.mobs.entity;

/** Cuenta golpes: cada {@code perHits} golpes drena {@code amount} hilos del alma. */
public class DrainCounter {
    public int hits;
    public final int amount;
    public final int perHits;

    public DrainCounter(int amount, int perHits) {
        this.amount = amount;
        this.perHits = Math.max(1, perHits);
    }
}
