package com.svz.mobs.entity.boss;

import net.minecraft.world.BossEvent.BossBarColor;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.List;

import static com.svz.mobs.entity.boss.Habilidad.*;

/** Todos los mini-jefes, espectros y jefes de zona. */
public final class BossProfiles {
    private BossProfiles() {}

    public static final List<BossProfile> ALL = new ArrayList<>();

    private static BossProfile add(BossProfile p) {
        ALL.add(p);
        return p;
    }

    // id, nombre, vida, daño, velocidad, escala, armadura, drenaje, golpes, barra, color, aura
    // ---- mini-jefes (de poseídos)
    public static final BossProfile TITERE_SIMPLE = add(new BossProfile("titere_simple", "Títere Simple", 80, 5, 0.26, 1.0F, 2, 2, 2, true, BossBarColor.RED, false)
            .con(EMBESTIDA, PULSO, SALTO).suelta("nudo_rojo", 1, 1, 1f).suelta("hilo_rojo", 1, 2, 1f).equipa(EquipmentSlot.HEAD, Items.LEATHER_HELMET));
    public static final BossProfile TITERE_GUERRERO = add(new BossProfile("titere_guerrero", "Títere Guerrero", 160, 8, 0.27, 1.2F, 6, 2, 2, true, BossBarColor.RED, false)
            .con(EMBESTIDA, PULSO, SALTO, TELEPORT).suelta("nudo_rojo", 1, 2, 1f).suelta("hilo_rojo", 2, 3, 1f)
            .equipa(EquipmentSlot.HEAD, Items.IRON_HELMET).equipa(EquipmentSlot.CHEST, Items.IRON_CHESTPLATE).equipa(EquipmentSlot.MAINHAND, Items.IRON_SWORD));
    public static final BossProfile TITERE_COLOSAL = add(new BossProfile("titere_colosal", "Títere Colosal", 320, 12, 0.24, 2.2F, 8, 3, 2, true, BossBarColor.PURPLE, false)
            .con(SALTO, ADDS, PULSO, CURACION).suelta("nudo_rojo", 2, 2, 1f).suelta("hilo_rojo", 3, 4, 1f)
            .equipa(EquipmentSlot.HEAD, Items.IRON_HELMET).equipa(EquipmentSlot.CHEST, Items.IRON_CHESTPLATE).equipa(EquipmentSlot.LEGS, Items.IRON_LEGGINGS));
    public static final BossProfile TITERE_JUGADOR = add(new BossProfile("titere_jugador", "Títere Jugador", 140, 7, 0.30, 1.0F, 4, 2, 1, true, BossBarColor.RED, false)
            .con(EMBESTIDA, TELEPORT, PULSO).suelta("nudo_rojo", 1, 1, 1f).suelta("hilo_rojo", 1, 3, 1f));

    // ---- Telar Roto
    public static final BossProfile ESPECTRO_TITERE = add(new BossProfile("espectro_titere", "Espectro Títere", 90, 6, 0.28, 1.0F, 0, 1, 2, false, BossBarColor.BLUE, false)
            .con(TELEPORT, EMBESTIDA).suelta("hilo_negro", 1, 2, 1f));
    public static final BossProfile ESPECTRO_ERRANTE = add(new BossProfile("espectro_errante", "Espectro Errante", 30, 3, 0.30, 0.8F, 0, 1, 3, false, BossBarColor.BLUE, false)
            .suelta("hilo_espectral", 1, 1, 0.5f));
    public static final BossProfile GUARDIAN_DEL_NUDO = add(new BossProfile("guardian_del_nudo", "Guardián del Nudo", 400, 10, 0.25, 1.6F, 10, 2, 2, true, BossBarColor.PURPLE, false)
            .con(PULSO, ADDS, SALTO, CURACION).suelta("nudo_de_alma", 1, 2, 1f).suelta("nudo_rojo", 1, 2, 1f)
            .equipa(EquipmentSlot.HEAD, Items.CHAINMAIL_HELMET).equipa(EquipmentSlot.CHEST, Items.CHAINMAIL_CHESTPLATE));
    public static final BossProfile PRIMER_TITERE = add(new BossProfile("primer_titere", "El Primer Títere", 900, 14, 0.27, 2.0F, 14, 3, 2, true, BossBarColor.PURPLE, true)
            .con(ADDS, TELEPORT, PULSO, EMBESTIDA, SILBIDO, CURACION).suelta("nucleo_de_hilo", 2, 2, 1f).suelta("lagrima_de_tejedor", 1, 2, 1f)
            .equipa(EquipmentSlot.HEAD, Items.DIAMOND_HELMET).equipa(EquipmentSlot.CHEST, Items.DIAMOND_CHESTPLATE));

    // ---- jefes de zona
    public static final BossProfile ESPANTAPAJAROS = add(new BossProfile("espantapajaros", "El Espantapájaros", 500, 9, 0.24, 1.5F, 6, 2, 2, true, BossBarColor.YELLOW, false)
            .con(ADDS, EMBESTIDA, SALTO, CURACION).suelta("nucleo_de_hilo", 1, 1, 1f).suelta("hilo_rojo", 2, 4, 1f)
            .equipa(EquipmentSlot.HEAD, Items.CARVED_PUMPKIN));
    public static final BossProfile SILBON_TITERE = add(new BossProfile("silbon_titere", "El Silbón Títere", 600, 10, 0.30, 1.8F, 6, 2, 2, true, BossBarColor.WHITE, false)
            .con(SILBIDO, TELEPORT, EMBESTIDA, PULSO).suelta("nucleo_de_hilo", 1, 1, 1f).suelta("hilo_negro", 1, 3, 1f));
    public static final BossProfile CANGREJO_MANO_ROJA = add(new BossProfile("cangrejo_mano_roja", "El Cangrejo Mano Roja", 700, 12, 0.22, 1.6F, 12, 2, 2, true, BossBarColor.RED, false)
            .con(EMBESTIDA, SALTO, PULSO, CURACION).suelta("nucleo_de_hilo", 1, 1, 1f).suelta("nudo_rojo", 1, 3, 1f));
    public static final BossProfile CACHICAMA_BLINDADA = add(new BossProfile("cachicama_blindada", "La Cachicama Blindada", 900, 11, 0.20, 1.7F, 20, 2, 2, true, BossBarColor.GREEN, false)
            .con(SALTO, PULSO, CURACION, EMBESTIDA).suelta("nucleo_de_hilo", 1, 1, 1f).suelta("nudo_rojo", 1, 3, 1f)
            .equipa(EquipmentSlot.HEAD, Items.IRON_HELMET).equipa(EquipmentSlot.CHEST, Items.IRON_CHESTPLATE).equipa(EquipmentSlot.LEGS, Items.IRON_LEGGINGS).equipa(EquipmentSlot.FEET, Items.IRON_BOOTS));
    public static final BossProfile SAYONA_DE_HILOS = add(new BossProfile("sayona_de_hilos", "La Sayona de Hilos", 650, 11, 0.31, 1.4F, 4, 3, 2, true, BossBarColor.PINK, false)
            .con(SILBIDO, TELEPORT, ADDS, PULSO).suelta("nucleo_de_hilo", 1, 1, 1f).suelta("hilo_negro", 2, 3, 1f));
    public static final BossProfile GUARDIAN_DE_NUDOS = add(new BossProfile("guardian_de_nudos", "Guardián de Nudos", 1100, 13, 0.24, 2.0F, 16, 3, 2, true, BossBarColor.PURPLE, false)
            .con(PULSO, ADDS, SALTO, CURACION).suelta("nucleo_de_hilo", 2, 2, 1f).suelta("nudo_rojo", 2, 4, 1f)
            .equipa(EquipmentSlot.HEAD, Items.IRON_HELMET).equipa(EquipmentSlot.CHEST, Items.IRON_CHESTPLATE).equipa(EquipmentSlot.MAINHAND, Items.IRON_AXE));
    public static final BossProfile MANO_ROJA = add(new BossProfile("mano_roja", "La Mano Roja", 2400, 16, 0.26, 3.0F, 20, 4, 1, true, BossBarColor.RED, true)
            .con(EMBESTIDA, ADDS, PULSO, SALTO, TELEPORT, SILBIDO, CURACION).suelta("nucleo_de_hilo", 3, 3, 1f).suelta("hilo_de_vida", 1, 1, 1f)
            .equipa(EquipmentSlot.HEAD, Items.NETHERITE_HELMET).equipa(EquipmentSlot.CHEST, Items.NETHERITE_CHESTPLATE));

    public static BossProfile byId(String id) {
        for (BossProfile p : ALL) if (p.id.equals(id)) return p;
        return null;
    }
}
