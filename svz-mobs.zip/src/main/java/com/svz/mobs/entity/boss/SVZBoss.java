package com.svz.mobs.entity.boss;

import com.svz.core.api.SVZCoreAPI;
import com.svz.items.api.SVZItemsAPI;
import com.svz.mobs.api.SVZMobsAPI;
import com.svz.mobs.entity.DrainCounter;
import com.svz.mobs.entity.SVZMobMarker;
import com.svz.mobs.SVZMobsMod;
import com.svz.mobs.entity.SVZPossessedLogic;
import com.svz.mobs.util.SVZItemRefs;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Mini-jefe / espectro / jefe de zona. Una sola clase dirigida por un {@link BossProfile}:
 * barra de jefe, 3 fases según la vida, Núcleo de Hilo flotante (partículas), drenaje y habilidades.
 */
public class SVZBoss extends Zombie implements SVZMobMarker {
    private final BossProfile profile;
    private final ServerBossEvent bossEvent;
    private final DrainCounter drain;
    private final List<UUID> adds = new ArrayList<>();
    private int fase = 1;
    private int edad;
    private boolean salto;
    private int aire;

    public SVZBoss(EntityType<? extends Zombie> type, Level level, BossProfile profile) {
        super(type, level);
        this.profile = profile;
        this.drain = new DrainCounter(profile.drenaje, profile.hitsPorDrenaje);
        this.bossEvent = new ServerBossEvent(Component.literal(profile.nombre), profile.color, BossEvent.BossBarOverlay.NOTCHED_10);
        this.bossEvent.setVisible(profile.barra);
        this.setCustomName(Component.literal(profile.nombre));
        this.addTag(SVZItemsAPI.TAG_POSEIDO);
        this.setBaby(false);
        if (profile.barra) this.setPersistenceRequired();
        profile.equipo.forEach((slot, item) -> this.setItemSlot(slot, new ItemStack(item)));
    }

    public static AttributeSupplier.Builder attributes(BossProfile p) {
        return Zombie.createAttributes()
                .add(Attributes.MAX_HEALTH, p.vida)
                .add(Attributes.ATTACK_DAMAGE, p.dano)
                .add(Attributes.MOVEMENT_SPEED, p.velocidad)
                .add(Attributes.SCALE, p.escala)
                .add(Attributes.ARMOR, p.armadura)
                .add(Attributes.KNOCKBACK_RESISTANCE, p.barra ? 0.7 : 0.0)
                .add(Attributes.FOLLOW_RANGE, 40.0);
    }

    public BossProfile profile() {
        return profile;
    }

    @Override
    public Mob svzSelf() {
        return this;
    }

    @Override
    public DrainCounter svzDrain() {
        return drain;
    }

    // ------------------------------------------------------------ comportamiento base de Zombie desactivado
    @Override
    protected boolean isSunSensitive() {
        return false;
    }

    @Override
    protected boolean convertsInWater() {
        return false;
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return !profile.barra && super.removeWhenFarAway(distance);
    }

    // ------------------------------------------------------------ IA personalizada
    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new BossCombatGoal(this));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 12.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
        this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, Villager.class, true));
    }

    @Override
    public void setTarget(LivingEntity target) {
        if (target instanceof SVZMobMarker) return;
        super.setTarget(target);
    }

    public float multiplicadorFase() {
        return 1.0F + 0.25F * (fase - 1);
    }

    public int cooldownHabilidad() {
        return Math.max(40, 140 - 30 * (fase - 1) - (profile.barra ? 0 : 20));
    }

    /** Golpe cuerpo a cuerpo (el drenaje lo aplica el evento de daño de SVZ-Mobs). */
    public void golpear(LivingEntity t) {
        if (!(level() instanceof ServerLevel sl)) return;
        float dmg = (float) getAttributeValue(Attributes.ATTACK_DAMAGE) * multiplicadorFase();
        if (t.hurtServer(sl, damageSources().mobAttack(this), dmg)) {
            Vec3 d = t.position().subtract(position()).normalize();
            t.knockback(0.5, -d.x, -d.z);
        }
    }

    // ------------------------------------------------------------ fases, barra y partículas
    @Override
    public void aiStep() {
        super.aiStep();
        if (level() instanceof ServerLevel sl) servidor(sl);
    }

    private void servidor(ServerLevel sl) {
        edad++;
        bossEvent.setProgress(Math.max(0f, Math.min(1f, getHealth() / getMaxHealth())));
        float f = getHealth() / getMaxHealth();
        int nueva = f > 0.66F ? 1 : (f > 0.33F ? 2 : 3);
        if (nueva > fase) cambiarFase(sl, nueva);

        if (profile.barra && edad % 5 == 0) nucleoFlotante(sl);
        if (salto) {
            if (!onGround()) aire++;
            else if (aire > 3 || edad % 100 == 0) {
                impactoSalto(sl);
            }
        }
        if (profile.aura && fase == 3 && edad % 40 == 0) {
            for (ServerPlayer p : jugadores(sl, 7)) SVZCoreAPI.drenarHilos(p, 1, this);
            sl.sendParticles(SVZPossessedLogic.ROJO, getX(), getY() + 1, getZ(), 30, 3, 0.5, 3, 0.02);
        }
    }

    private void cambiarFase(ServerLevel sl, int nueva) {
        fase = nueva;
        for (ServerPlayer p : jugadores(sl, 48)) {
            p.displayClientMessage(Component.literal(profile.nombre + " entra en la fase " + nueva + "!"), false);
        }
        sl.sendParticles(ParticleTypes.EXPLOSION, getX(), getY() + getBbHeight() / 2, getZ(), 6, 1, 1, 1, 0.1);
        if (nueva == 3) addEffect(new MobEffectInstance(MobEffects.SPEED, MobEffectInstance.INFINITE_DURATION, 0, false, false));
    }

    /** Núcleo de Hilo flotante sobre la cabeza (anillo de partículas). */
    private void nucleoFlotante(ServerLevel sl) {
        double y = getY() + getBbHeight() + 0.7;
        double ang = edad * 0.35;
        for (int i = 0; i < 2; i++) {
            double a = ang + i * Math.PI;
            sl.sendParticles(SVZPossessedLogic.ROJO, getX() + Math.cos(a) * 0.4, y, getZ() + Math.sin(a) * 0.4, 1, 0, 0, 0, 0);
        }
        sl.sendParticles(ParticleTypes.END_ROD, getX(), y, getZ(), 1, 0.05, 0.05, 0.05, 0.0);
    }

    private List<ServerPlayer> jugadores(ServerLevel sl, double r) {
        return sl.getEntitiesOfClass(ServerPlayer.class, getBoundingBox().inflate(r), p -> !p.isSpectator());
    }

    // ------------------------------------------------------------ habilidades
    public void usarHabilidad(LivingEntity t) {
        if (!(level() instanceof ServerLevel sl)) return;
        List<Habilidad> posibles = new ArrayList<>();
        for (Habilidad h : profile.habilidades) if (h.minFase <= fase) posibles.add(h);
        if (posibles.isEmpty()) return;
        Habilidad h = posibles.get(random.nextInt(posibles.size()));
        Vec3 d = t.position().subtract(position()).normalize();
        switch (h) {
            case EMBESTIDA -> setDeltaMovement(d.x * 1.1, 0.25, d.z * 1.1);
            case SALTO -> {
                setDeltaMovement(d.x * 0.7, 0.9, d.z * 0.7);
                salto = true;
                aire = 0;
            }
            case PULSO -> {
                for (ServerPlayer p : jugadores(sl, 8)) {
                    p.hurtServer(sl, damageSources().mobAttack(this), 4.0F * multiplicadorFase());
                }
                sl.sendParticles(ParticleTypes.SONIC_BOOM, getX(), getY() + 1, getZ(), 1, 0, 0, 0, 0);
            }
            case ADDS -> invocar(sl, 1 + fase);
            case CURACION -> {
                heal(getMaxHealth() * 0.04F);
                sl.sendParticles(ParticleTypes.HEART, getX(), getY() + getBbHeight(), getZ(), 8, 0.5, 0.5, 0.5, 0.0);
            }
            case TELEPORT -> {
                Vec3 b = t.position().subtract(t.getLookAngle().scale(2.0));
                randomTeleport(b.x, t.getY(), b.z, true);
            }
            case SILBIDO -> {
                for (ServerPlayer p : jugadores(sl, 16)) {
                    p.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 60, 1));
                    p.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100, 0));
                    p.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 40, 0));
                }
                sl.sendParticles(ParticleTypes.NOTE, getX(), getY() + getBbHeight() + 0.3, getZ(), 12, 1, 0.5, 1, 1.0);
            }
        }
        drenarPorHabilidad(sl);
    }

    /** Cada habilidad drena hilos a los jugadores cercanos: mini-jefes -2, jefes de zona -1 (configurable). */
    private void drenarPorHabilidad(ServerLevel sl) {
        if (!profile.barra) return; // los espectros sin barra no drenan por habilidad
        String id = profile.id;
        boolean mini = id.equals("titere_simple") || id.equals("titere_guerrero") || id.equals("titere_colosal") || id.equals("titere_jugador");
        int n = mini ? SVZMobsMod.CONFIG.drenajeHabilidadMini : SVZMobsMod.CONFIG.drenajeHabilidadJefe;
        if (n <= 0) return;
        for (ServerPlayer p : jugadores(sl, 8)) SVZCoreAPI.drenarHilos(p, n, this);
    }

    private void impactoSalto(ServerLevel sl) {
        salto = false;
        for (ServerPlayer p : jugadores(sl, 5)) {
            p.hurtServer(sl, damageSources().mobAttack(this), 6.0F * multiplicadorFase());
            Vec3 d = p.position().subtract(position()).normalize();
            p.knockback(0.9, -d.x, -d.z);
        }
        sl.sendParticles(ParticleTypes.EXPLOSION, getX(), getY(), getZ(), 5, 2, 0.2, 2, 0.1);
    }

    private void invocar(ServerLevel sl, int n) {
        adds.removeIf(id -> {
            var e = sl.getEntity(id);
            return e == null || !e.isAlive();
        });
        for (int i = 0; i < n && adds.size() < 6; i++) {
            double a = random.nextDouble() * Math.PI * 2;
            Mob m = SVZMobsAPI.spawn(sl, "espectro_errante", getX() + Math.cos(a) * 3, getY(), getZ() + Math.sin(a) * 3);
            if (m != null) adds.add(m.getUUID());
        }
    }

    // ------------------------------------------------------------ barra de jefe
    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        if (profile.barra) bossEvent.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        bossEvent.removePlayer(player);
    }

    @Override
    public void setCustomName(Component name) {
        super.setCustomName(name);
        if (bossEvent != null && name != null) bossEvent.setName(name);
    }

    @Override
    public void remove(RemovalReason reason) {
        super.remove(reason);
        bossEvent.removeAllPlayers();
    }

    // ------------------------------------------------------------ muerte y loot
    @Override
    protected void dropAllDeathLoot(ServerLevel level, DamageSource source) {
        var copia = getAttached(com.svz.mobs.entity.ModAttachments.INVENTARIO_COPIA); // Títere Jugador: inventario del jugador
        if (copia != null) for (ItemStack s : copia) if (!s.isEmpty()) spawnAtLocation(level, s.copy());
        for (BossProfile.Drop d : profile.drops) {
            if (random.nextFloat() > d.prob()) continue;
            int n = d.min() + (d.max() > d.min() ? random.nextInt(d.max() - d.min() + 1) : 0);
            if (n > 0) spawnAtLocation(level, SVZItemRefs.stack(d.item(), n));
        }
    }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (!(level() instanceof ServerLevel sl)) return;
        for (UUID id : adds) {
            var e = sl.getEntity(id);
            if (e != null) e.discard();
        }
        if (profile.barra) {
            for (ServerPlayer p : sl.getEntitiesOfClass(ServerPlayer.class, getBoundingBox().inflate(64))) {
                p.addTag("svz_boss_" + profile.id);
                p.displayClientMessage(Component.literal(profile.nombre + " ha caído."), false);
            }
        }
    }
}
