package com.svz.mobs.entity;

import com.svz.mobs.SVZMobsMod;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.minecraft.world.item.ItemStack;

import java.util.List;

/** Datos persistentes en entidades de SVZ-Mobs. */
public final class ModAttachments {
    private ModAttachments() {}

    /** Copia del inventario de un jugador que lleva su Títere Jugador (se suelta al derrotarlo). */
    public static AttachmentType<List<ItemStack>> INVENTARIO_COPIA;

    public static void register() {
        INVENTARIO_COPIA = AttachmentRegistry.<List<ItemStack>>create(SVZMobsMod.id("inventario_copia"),
                b -> b.persistent(ItemStack.OPTIONAL_CODEC.listOf()));
    }
}
