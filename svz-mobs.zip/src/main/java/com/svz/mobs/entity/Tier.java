package com.svz.mobs.entity;

/** Nivel de hilo de un poseído: define el mini-jefe en el que se transforma y cuánto drena. */
public enum Tier {
    MENOR("titere_simple", 1, 2),
    MEDIO("titere_guerrero", 1, 3),
    MAYOR("titere_colosal", 2, 4);

    public final String mini;
    public final int drenaje;
    public final int adds;

    Tier(String mini, int drenaje, int adds) {
        this.mini = mini;
        this.drenaje = drenaje;
        this.adds = adds;
    }
}
