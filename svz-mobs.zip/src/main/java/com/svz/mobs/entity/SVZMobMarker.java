package com.svz.mobs.entity;

import net.minecraft.world.entity.Mob;

/** Marca a todos los mobs de SVZ-Mobs que drenan hilos. */
public interface SVZMobMarker {
    Mob svzSelf();

    DrainCounter svzDrain();
}
