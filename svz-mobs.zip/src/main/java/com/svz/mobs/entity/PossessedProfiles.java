package com.svz.mobs.entity;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.List;

public final class PossessedProfiles {
    private PossessedProfiles() {}

    public static final PossessedProfile VACA = new PossessedProfile("vaca_poseida", Tier.MENOR, () -> EntityType.COW,
            List.of(new ItemStack(Items.LEATHER, 2), new ItemStack(Items.BEEF, 3)), 0);
    public static final PossessedProfile CERDO = new PossessedProfile("cerdo_poseido", Tier.MENOR, () -> EntityType.PIG,
            List.of(new ItemStack(Items.PORKCHOP, 4)), 0);
    public static final PossessedProfile OVEJA = new PossessedProfile("oveja_poseida", Tier.MENOR, () -> EntityType.SHEEP,
            List.of(new ItemStack(Items.WHITE_WOOL, 3), new ItemStack(Items.MUTTON, 2)), 0);
    public static final PossessedProfile ALDEANO = new PossessedProfile("aldeano_poseido", Tier.MEDIO, () -> EntityType.VILLAGER,
            List.of(new ItemStack(Items.EMERALD, 3)), 0);
    public static final PossessedProfile LOBO = new PossessedProfile("lobo_poseido", Tier.MEDIO, () -> EntityType.WOLF,
            List.of(new ItemStack(Items.BONE, 4)), 0);
    public static final PossessedProfile CREEPER = new PossessedProfile("creeper_poseido", Tier.MEDIO, () -> EntityType.CREEPER,
            List.of(new ItemStack(Items.GUNPOWDER, 4)), 1);
    public static final PossessedProfile GOLEM = new PossessedProfile("golem_poseido", Tier.MAYOR, () -> EntityType.IRON_GOLEM,
            List.of(new ItemStack(Items.IRON_INGOT, 6), new ItemStack(Items.POPPY, 2)), 0);
    public static final PossessedProfile PIGLIN = new PossessedProfile("piglin_poseido", Tier.MAYOR, () -> EntityType.PIGLIN,
            List.of(new ItemStack(Items.GOLD_INGOT, 5)), 0);
    public static final PossessedProfile WARDEN = new PossessedProfile("warden_poseido", Tier.MAYOR, () -> EntityType.WARDEN,
            List.of(new ItemStack(Items.ECHO_SHARD, 2), new ItemStack(Items.SCULK, 6)), 0);
}
