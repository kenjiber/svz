package com.svz.mobs.entity.possessed;

import com.svz.items.api.SVZItemsAPI;
import com.svz.mobs.entity.PossessedProfiles;
import com.svz.mobs.entity.PossessedState;
import com.svz.mobs.entity.SVZPossessed;
import com.svz.mobs.entity.SVZPossessedLogic;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.monster.*;
import net.minecraft.world.entity.monster.warden.Warden;
import net.minecraft.world.entity.ai.goal.ZombieAttackGoal;
import net.minecraft.world.entity.animal.*;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/** Cow poseído: variante de Cow con IA, drenaje y ritual de liberación propios. */
public class PossessedCow extends Cow implements SVZPossessed {
    private final PossessedState state = new PossessedState(PossessedProfiles.VACA);

    public PossessedCow(EntityType<? extends Cow> type, Level level) {
        super(type, level);
        this.addTag(SVZItemsAPI.TAG_POSEIDO);
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder attributes() {
        return Cow.createAttributes()
                .add(Attributes.MAX_HEALTH, 24)
                .add(Attributes.ATTACK_DAMAGE, 4)
                .add(Attributes.MOVEMENT_SPEED, 0.26)
                .add(Attributes.FOLLOW_RANGE, 32.0);
    }

    @Override
    public PossessedState svzState() {
        return state;
    }

    @Override
    public Mob svzSelf() {
        return this;
    }

    @Override
    protected void registerGoals() {
        super.registerGoals();
        SVZPossessedLogic.metasCompletas(this, this.goalSelector, this.targetSelector);
    }

    @Override
    public void setTarget(LivingEntity target) {
        if (!SVZPossessedLogic.permiteObjetivo(this, target)) return;
        super.setTarget(target);
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level() instanceof ServerLevel sl) SVZPossessedLogic.tick(this, sl);
    }

    @Override
    public boolean hurtServer(ServerLevel level, DamageSource source, float amount) {
        boolean r = super.hurtServer(level, source, amount);
        if (r) SVZPossessedLogic.alHerir(this, level);
        return r;
    }

    /** Sin loot vanilla: suelta Hilo Rojo y se transforma en mini-jefe si no fue liberado. */
    @Override
    protected void dropAllDeathLoot(ServerLevel level, DamageSource source) {
        SVZPossessedLogic.muerte(this, level, source);
    }
}
