package com.svz.mobs.entity.boss;

/** Habilidades de jefes. {@code minFase}: primera fase en la que pueden usarse. */
public enum Habilidad {
    EMBESTIDA(1), ADDS(1), PULSO(1), SALTO(2), TELEPORT(2), SILBIDO(2), CURACION(3);

    public final int minFase;

    Habilidad(int minFase) {
        this.minFase = minFase;
    }
}
