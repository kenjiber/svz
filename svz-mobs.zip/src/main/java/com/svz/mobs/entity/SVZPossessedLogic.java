package com.svz.mobs.entity;

import com.svz.mobs.api.SVZMobsAPI;
import com.svz.mobs.ritual.SVZRitual;
import com.svz.mobs.util.SVZItemRefs;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.GoalSelector;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/** Comportamiento compartido por todos los poseídos. */
public final class SVZPossessedLogic {
    private SVZPossessedLogic() {}

    public static final ParticleOptions ROJO = new DustParticleOptions(0xFF2020, 1.0F);

    // ------------------------------------------------------------ IA personalizada
    /** Conjunto de metas propio para animales: sin pánico, sin cría, ataca a jugadores y aldeanos libres. */
    public static void metasCompletas(PathfinderMob m, GoalSelector goals, GoalSelector targets) {
        goals.removeAllGoals(g -> true);
        targets.removeAllGoals(g -> true);
        goals.addGoal(0, new FloatGoal(m));
        goals.addGoal(1, new MeleeAttackGoal(m, 1.35, true));
        goals.addGoal(2, new WaterAvoidingRandomStrollGoal(m, 1.0));
        goals.addGoal(3, new LookAtPlayerGoal(m, Player.class, 10.0F));
        goals.addGoal(4, new RandomLookAroundGoal(m));
        objetivos(m, targets);
    }

    /** Solo objetivos: jugadores y aldeanos libres (los demás SVZ nunca son objetivo). */
    public static void objetivos(PathfinderMob m, GoalSelector targets) {
        targets.removeAllGoals(g -> true);
        targets.addGoal(1, new HurtByTargetGoal(m));
        targets.addGoal(2, new NearestAttackableTargetGoal<>(m, Player.class, true));
        targets.addGoal(3, new NearestAttackableTargetGoal<>(m, Villager.class, true));
    }

    /** {@code false} si el objetivo es otro mob SVZ o si el poseído ya recuperó el control (ritual fase 3). */
    public static boolean permiteObjetivo(SVZPossessed p, LivingEntity target) {
        if (target == null) return true;
        if (target instanceof SVZMobMarker) return false;
        return p.svzState().ritualFase < 3;
    }

    // ------------------------------------------------------------ tick
    public static void tick(SVZPossessed p, ServerLevel level) {
        Mob m = p.svzSelf();
        PossessedState s = p.svzState();
        s.edad++;
        if (s.edad % 4 == 0) ojos(m, level);
        if (s.edad % 10 == 0) {
            level.sendParticles(ROJO, m.getX(), m.getY() + m.getBbHeight() * 0.5, m.getZ(), 3,
                    m.getBbWidth() * 0.5, m.getBbHeight() * 0.4, m.getBbWidth() * 0.5, 0.01);
            level.sendParticles(ParticleTypes.CRIMSON_SPORE, m.getX(), m.getY() + m.getBbHeight() * 0.8, m.getZ(), 1, 0.2, 0.2, 0.2, 0.0);
        }
        SVZRitual.tick(p, level);
    }

    /** "Ojos rojos": dos partículas rojas a la altura de los ojos. */
    private static void ojos(Mob m, ServerLevel level) {
        Vec3 look = m.getLookAngle();
        double w = Math.max(0.3, m.getBbWidth());
        Vec3 eye = m.getEyePosition().add(look.x * w * 0.45, 0, look.z * w * 0.45);
        Vec3 side = new Vec3(-look.z, 0, look.x).normalize().scale(w * 0.18);
        level.sendParticles(ROJO, eye.x + side.x, eye.y, eye.z + side.z, 1, 0, 0, 0, 0);
        level.sendParticles(ROJO, eye.x - side.x, eye.y, eye.z - side.z, 1, 0, 0, 0, 0);
    }

    /** Al recibir daño: partículas rojas. */
    public static void alHerir(SVZPossessed p, ServerLevel level) {
        Mob m = p.svzSelf();
        level.sendParticles(ROJO, m.getX(), m.getY() + m.getBbHeight() * 0.5, m.getZ(), 14,
                m.getBbWidth() * 0.4, m.getBbHeight() * 0.4, m.getBbWidth() * 0.4, 0.05);
    }

    // ------------------------------------------------------------ muerte
    /**
     * Sustituye al loot vanilla: no suelta nada normal. Suelta Hilo Rojo y, si no fue liberado,
     * se transforma en el mini-jefe de su nivel.
     */
    public static void muerte(SVZPossessed p, ServerLevel level, DamageSource source) {
        Mob m = p.svzSelf();
        PossessedState s = p.svzState();
        SVZRitual.limpiar(level, s);
        if (s.liberado) return;
        int n = 1 + m.getRandom().nextInt(2);
        m.spawnAtLocation(level, SVZItemRefs.stack("hilo_rojo", n));
        Mob mini = SVZMobsAPI.spawn(level, s.profile.tier().mini, m.getX(), m.getY(), m.getZ());
        if (mini != null) {
            for (ServerPlayer pl : level.getEntitiesOfClass(ServerPlayer.class, m.getBoundingBox().inflate(24))) {
                pl.displayClientMessage(Component.literal("¡El poseído no fue liberado y se transforma en un títere!"), true);
            }
        }
    }
}
