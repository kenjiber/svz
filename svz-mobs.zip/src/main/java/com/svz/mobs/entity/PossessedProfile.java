package com.svz.mobs.entity;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.ItemStack;

import java.util.List;
import java.util.function.Supplier;

/** Datos de cada poseído: nivel, mob vanilla al que vuelve al liberarse y recompensa. */
public record PossessedProfile(String id, Tier tier, Supplier<EntityType<? extends Mob>> libre,
                               List<ItemStack> recompensa, int hitsPorDrenaje) {}
