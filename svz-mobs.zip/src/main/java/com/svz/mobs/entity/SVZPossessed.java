package com.svz.mobs.entity;

/** Implementada por las 9 variantes poseídas de mobs vanilla. */
public interface SVZPossessed extends SVZMobMarker {
    PossessedState svzState();

    @Override
    default DrainCounter svzDrain() {
        return svzState().drain;
    }
}
