package com.svz.mobs.entity.boss;

import net.minecraft.world.BossEvent;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Item;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/** Definición de un mini-jefe, espectro o jefe de zona. */
public class BossProfile {
    public record Drop(String item, int min, int max, float prob) {}

    public final String id, nombre;
    public final double vida, dano, velocidad, armadura;
    public final float escala;
    public final int drenaje, hitsPorDrenaje;
    public final boolean barra;
    public final BossEvent.BossBarColor color;
    public final boolean aura;
    public final List<Habilidad> habilidades = new ArrayList<>();
    public final List<Drop> drops = new ArrayList<>();
    public final Map<EquipmentSlot, Item> equipo = new EnumMap<>(EquipmentSlot.class);

    public BossProfile(String id, String nombre, double vida, double dano, double velocidad, float escala, double armadura,
                       int drenaje, int hitsPorDrenaje, boolean barra, BossEvent.BossBarColor color, boolean aura) {
        this.id = id;
        this.nombre = nombre;
        this.vida = vida;
        this.dano = dano;
        this.velocidad = velocidad;
        this.escala = escala;
        this.armadura = armadura;
        this.drenaje = drenaje;
        this.hitsPorDrenaje = hitsPorDrenaje;
        this.barra = barra;
        this.color = color;
        this.aura = aura;
    }

    public BossProfile con(Habilidad... h) {
        habilidades.addAll(List.of(h));
        return this;
    }

    public BossProfile suelta(String item, int min, int max, float prob) {
        drops.add(new Drop(item, min, max, prob));
        return this;
    }

    public BossProfile equipa(EquipmentSlot slot, Item item) {
        equipo.put(slot, item);
        return this;
    }
}
