package com.svz.mobs.entity.boss;

import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;

import java.util.EnumSet;

/** IA de combate propia de los jefes: persigue, golpea con cooldown y lanza habilidades por fase. */
public class BossCombatGoal extends Goal {
    private final SVZBoss boss;
    private int ataqueCd;
    private int habilidadCd = 60;
    private int rutaCd;

    public BossCombatGoal(SVZBoss boss) {
        this.boss = boss;
        setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        LivingEntity t = boss.getTarget();
        return t != null && t.isAlive();
    }

    @Override
    public boolean canContinueToUse() {
        return canUse();
    }

    @Override
    public boolean requiresUpdateEveryTick() {
        return true;
    }

    @Override
    public void stop() {
        boss.getNavigation().stop();
    }

    @Override
    public void tick() {
        LivingEntity t = boss.getTarget();
        if (t == null) return;
        boss.getLookControl().setLookAt(t, 30.0F, 30.0F);
        if (--rutaCd <= 0) {
            rutaCd = 8;
            boss.getNavigation().moveTo(t, 1.15);
        }
        if (ataqueCd > 0) ataqueCd--;
        double alcance = boss.getBbWidth() + 1.6;
        double d2 = boss.distanceToSqr(t);
        if (d2 <= alcance * alcance && ataqueCd == 0 && boss.getSensing().hasLineOfSight(t)) {
            ataqueCd = 20;
            boss.swing(InteractionHand.MAIN_HAND);
            boss.golpear(t);
        }
        if (--habilidadCd <= 0 && d2 < 40 * 40) {
            habilidadCd = boss.cooldownHabilidad();
            boss.usarHabilidad(t);
        }
    }
}
