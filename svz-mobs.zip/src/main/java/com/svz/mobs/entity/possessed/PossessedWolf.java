package com.svz.mobs.entity.possessed;

import com.svz.items.api.SVZItemsAPI;
import com.svz.mobs.entity.PossessedProfiles;
import com.svz.mobs.entity.PossessedState;
import com.svz.mobs.entity.SVZPossessed;
import com.svz.mobs.entity.SVZPossessedLogic;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.animal.wolf.Wolf;
import net.minecraft.world.level.Level;

/** Wolf poseído: variante de Wolf con IA, drenaje y ritual de liberación propios. */
public class PossessedWolf extends Wolf implements SVZPossessed {
    private final PossessedState state = new PossessedState(PossessedProfiles.LOBO);

    public PossessedWolf(EntityType<? extends Wolf> type, Level level) {
        super(type, level);
        this.addTag(SVZItemsAPI.TAG_POSEIDO);
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder attributes() {
        return Wolf.createAttributes()
                .add(Attributes.MAX_HEALTH, 30)
                .add(Attributes.ATTACK_DAMAGE, 6)
                .add(Attributes.MOVEMENT_SPEED, 0.38)
                .add(Attributes.FOLLOW_RANGE, 32.0);
    }

    @Override
    public PossessedState svzState() {
        return state;
    }

    @Override
    public Mob svzSelf() {
        return this;
    }

    @Override
    protected void registerGoals() {
        super.registerGoals();
        SVZPossessedLogic.metasCompletas(this, this.goalSelector, this.targetSelector);
    }

    @Override
    public void setTarget(LivingEntity target) {
        if (!SVZPossessedLogic.permiteObjetivo(this, target)) return;
        super.setTarget(target);
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level() instanceof ServerLevel sl) SVZPossessedLogic.tick(this, sl);
    }

    @Override
    public boolean hurtServer(ServerLevel level, DamageSource source, float amount) {
        boolean r = super.hurtServer(level, source, amount);
        if (r) SVZPossessedLogic.alHerir(this, level);
        return r;
    }

    @Override
    protected void dropAllDeathLoot(ServerLevel level, DamageSource source) {
        SVZPossessedLogic.muerte(this, level, source);
    }
}