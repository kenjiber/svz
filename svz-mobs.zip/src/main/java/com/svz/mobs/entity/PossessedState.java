package com.svz.mobs.entity;

import com.svz.mobs.SVZMobsMod;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Estado de un poseído: contador de drenaje y ritual de liberación. */
public class PossessedState {
    public final PossessedProfile profile;
    public final DrainCounter drain;

    public int edad;
    /** 0 = sin ritual, 1 = adds, 2 = núcleo flotante, 3 = inmovilizar y alimentar. */
    public int ritualFase;
    public int ritualTicks;
    public int golpesNucleo;
    public int golpesNecesarios;
    public boolean atado;
    public boolean liberado;
    public UUID nucleo;
    public final List<UUID> adds = new ArrayList<>();

    public PossessedState(PossessedProfile profile) {
        this.profile = profile;
        int hits = profile.hitsPorDrenaje() > 0 ? profile.hitsPorDrenaje() : SVZMobsMod.CONFIG.hitsPorDrenajePoseido;
        this.drain = new DrainCounter(profile.tier().drenaje, hits);
    }
}
