package com.svz.mobs.spawn;

import com.svz.core.api.SVZCoreAPI;
import com.svz.mobs.SVZMobsMod;
import com.svz.mobs.api.SVZMobsAPI;
import com.svz.mobs.entity.SVZPossessed;
import com.svz.mobs.entity.boss.SVZBoss;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BiomeTags;
import net.minecraft.tags.StructureTags;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;

import java.util.ArrayList;
import java.util.List;

/** Spawn de poseídos (cada amanecer), espectros (solo Telar Roto) y jefes (en sus zonas). */
public final class SVZSpawner {
    private SVZSpawner() {}

    private static long ultimoDia = -1;

    private static final String[] MENOR = {"vaca_poseida", "cerdo_poseido", "oveja_poseida"};
    private static final String[] MEDIO = {"aldeano_poseido", "lobo_poseido", "creeper_poseido"};
    private static final String[] MAYOR = {"golem_poseido", "piglin_poseido", "warden_poseido"};

    public static void tick(MinecraftServer server) {
        int t = server.getTickCount();
        com.svz.mobs.logic.DeathSnapshot.tick(server);
        if (t % 20 == 0) amanecer(server);
        if (t % 100 == 0) telar(server);
        if (t % 600 == 0) zonas(server);
    }

    // ------------------------------------------------------------ poseídos: 1 por día, máx. acumulados
    private static void amanecer(MinecraftServer server) {
        ServerLevel ow = server.overworld();
        long dia = ow.getGameTime() / 24000L; // un "día" = 24000 ticks
        if (ultimoDia < 0) {
            ultimoDia = dia;
            return;
        }
        if (dia == ultimoDia) return;
        ultimoDia = dia;

        int vivos = 0;
        for (Entity e : ow.getAllEntities()) if (e instanceof SVZPossessed) vivos++;
        List<ServerPlayer> jugadores = new ArrayList<>(ow.players());
        jugadores.removeIf(p -> p.isSpectator());
        if (jugadores.isEmpty()) return;
        for (int i = 0; i < SVZMobsMod.CONFIG.poseidosPorDia && vivos < SVZMobsMod.CONFIG.maxPoseidosAcumulados; i++) {
            ServerPlayer p = jugadores.get(ow.random.nextInt(jugadores.size()));
            double r = ow.random.nextDouble();
            String[] lista = r < 0.60 ? MENOR : (r < 0.90 ? MEDIO : MAYOR);
            BlockPos pos = superficie(ow, p, 24, 40);
            if (SVZMobsAPI.spawn(ow, lista[ow.random.nextInt(lista.length)], pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5) != null) {
                vivos++;
                p.displayClientMessage(Component.literal("Al amanecer, un hilo rojo se tensa en la distancia..."), true);
            }
        }
    }

    // ------------------------------------------------------------ Telar Roto
    private static ServerLevel telarLevel(MinecraftServer server) {
        for (ResourceKey<Level> k : server.levelKeys()) {
            if (SVZCoreAPI.isTelarRoto(k)) return server.getLevel(k);
        }
        return null;
    }

    /** Misma partición que SVZ-TelarRoto: 150 bloques por zona a lo largo de +X. */
    private static int zonaTelar(double x) {
        return x < 0 ? 1 : Math.min(5, (int) (x / 150) + 1);
    }

    private static void telar(MinecraftServer server) {
        ServerLevel telar = telarLevel(server);
        if (telar == null) return;
        for (ServerPlayer p : telar.players()) {
            if (p.isSpectator()) continue;
            boolean protegido = SVZMobsAPI.spawnBloqueado(p); // zona segura o periodo de gracia tras llegar
            int zona = zonaTelar(p.getX());
            if (!protegido) {
                // Espectros Errantes: pocos y lejos en las primeras zonas
                int tope = zona == 1 ? Math.min(2, SVZMobsMod.CONFIG.maxErrantes) : (zona == 2 ? Math.min(3, SVZMobsMod.CONFIG.maxErrantes) : SVZMobsMod.CONFIG.maxErrantes);
                float prob = zona == 1 ? 0.15F : (zona == 2 ? 0.25F : 0.4F);
                int errantes = telar.getEntitiesOfClass(SVZBoss.class, p.getBoundingBox().inflate(48),
                        b2 -> b2.profile().id.equals("espectro_errante")).size();
                if (errantes < tope && telar.random.nextFloat() < prob) {
                    BlockPos pos = zona == 1 ? superficie(telar, p, 24, 36) : superficie(telar, p, 16, 26);
                    if (!SVZMobsAPI.posicionProtegida(telar, pos.getX(), pos.getZ())) {
                        SVZMobsAPI.spawn(telar, "espectro_errante", pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5);
                    }
                }
                // Guardián del Nudo (mini-jefe de zona): solo a partir de la Zona 2
                if (zona >= 2 && telar.random.nextFloat() < 0.02F && cercaDeJefe(telar, p, "guardian_del_nudo", 100) == 0) {
                    BlockPos pos = superficie(telar, p, 24, 36);
                    SVZMobsAPI.spawn(telar, "guardian_del_nudo", pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5);
                }
            }
            // El Primer Títere (zona 5 = lejos del origen del Telar)
            if (Math.hypot(p.getX(), p.getZ()) >= SVZMobsMod.CONFIG.zona5Radio && !p.getTags().contains("svz_boss_primer_titere")
                    && telar.random.nextFloat() < 0.03F && cercaDeJefe(telar, p, "primer_titere", 200) == 0) {
                BlockPos pos = superficie(telar, p, 28, 40);
                SVZMobsAPI.spawn(telar, "primer_titere", pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5);
            }
        }
    }

    // ------------------------------------------------------------ jefes de zona (Overworld)
    private static void zonas(MinecraftServer server) {
        if (SVZMobsMod.CONFIG.probJefeZona <= 0) return;
        ServerLevel ow = server.overworld();
        for (ServerPlayer p : ow.players()) {
            if (p.isSpectator()) continue;
            BlockPos at = p.blockPosition();
            if (ow.getBiome(at).is(BiomeTags.IS_SAVANNA)) intentar(ow, p, "silbon_titere");        // Llanos
            if (ow.getBiome(at).is(BiomeTags.IS_BEACH)) intentar(ow, p, "cangrejo_mano_roja");     // Costa
            if (ow.getBiome(at).is(BiomeTags.IS_MOUNTAIN)) intentar(ow, p, "cachicama_blindada");  // Andes
            if (ow.getBiome(at).is(BiomeTags.IS_JUNGLE)) intentar(ow, p, "sayona_de_hilos");       // Selva
            if (enFortaleza(ow, at)) intentar(ow, p, "guardian_de_nudos");                          // Fortaleza
        }
    }

    private static boolean enFortaleza(ServerLevel level, BlockPos pos) {
        return level.structureManager().getStructureWithPieceAt(pos, StructureTags.EYE_OF_ENDER_LOCATED).isValid();
    }

    private static void intentar(ServerLevel level, ServerPlayer p, String id) {
        if (p.getTags().contains("svz_boss_" + id)) return; // ya lo derrotó
        if (level.random.nextDouble() >= SVZMobsMod.CONFIG.probJefeZona) return;
        if (cercaDeJefe(level, p, id, 128) > 0) return;
        BlockPos pos = superficie(level, p, 28, 40);
        SVZMobsAPI.spawn(level, id, pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5);
        p.displayClientMessage(Component.literal("Algo enorme se mueve en esta tierra..."), true);
    }

    private static int cercaDeJefe(ServerLevel level, ServerPlayer p, String id, double radio) {
        return level.getEntitiesOfClass(SVZBoss.class, p.getBoundingBox().inflate(radio), b -> b.profile().id.equals(id)).size();
    }

    // ------------------------------------------------------------ utilidades
    private static BlockPos superficie(ServerLevel level, ServerPlayer p, double min, double max) {
        double ang = level.random.nextDouble() * Math.PI * 2;
        double d = min + level.random.nextDouble() * (max - min);
        int x = (int) Math.floor(p.getX() + Math.cos(ang) * d);
        int z = (int) Math.floor(p.getZ() + Math.sin(ang) * d);
        return level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, new BlockPos(x, 0, z));
    }
}
