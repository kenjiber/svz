package com.svz.mobs.command;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.svz.mobs.api.SVZMobsAPI;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Mob;

import java.util.function.Predicate;

/** /svzmobs spawn <id> (admin): genera cualquier mob de SVZ junto a ti. Útil para probar. */
public final class SVZMobsCommands {
    private SVZMobsCommands() {}

    // NOTA 1.21.11: igual que en SVZ-Core, esta línea depende del sistema de permisos.
    private static final Predicate<CommandSourceStack> ADMIN = Commands.hasPermission(Commands.LEVEL_GAMEMASTERS);

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(Commands.literal("svzmobs").requires(ADMIN)
                        .then(Commands.literal("spawn")
                                .then(Commands.argument("id", StringArgumentType.word())
                                        .suggests((c, b) -> SharedSuggestionProvider.suggest(SVZMobsAPI.ids(), b))
                                        .executes(ctx -> {
                                            ServerPlayer p = ctx.getSource().getPlayerOrException();
                                            String id = StringArgumentType.getString(ctx, "id");
                                            Mob m = SVZMobsAPI.spawn((ServerLevel) p.level(), id, p.getX() + 2, p.getY(), p.getZ() + 2);
                                            if (m == null) {
                                                ctx.getSource().sendFailure(Component.literal("Id desconocido: " + id));
                                                return 0;
                                            }
                                            ctx.getSource().sendSuccess(() -> Component.literal("Generado: " + id), true);
                                            return 1;
                                        })))));
    }
}
