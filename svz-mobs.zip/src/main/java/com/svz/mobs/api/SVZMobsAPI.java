package com.svz.mobs.api;

import com.svz.mobs.entity.ModEntities;
import com.svz.mobs.entity.SVZMobMarker;
import com.svz.mobs.entity.SVZPossessed;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;

import java.util.Set;

/**
 * API pública de SVZ-Mobs para misiones, mundo y otros mods.
 *
 * <p>Ids: vaca_poseida, cerdo_poseido, oveja_poseida, aldeano_poseido, lobo_poseido, creeper_poseido,
 * golem_poseido, piglin_poseido, warden_poseido, titere_simple, titere_guerrero, titere_colosal,
 * titere_jugador, espectro_titere, espectro_errante, guardian_del_nudo, primer_titere, espantapajaros,
 * silbon_titere, cangrejo_mano_roja, cachicama_blindada, sayona_de_hilos, guardian_de_nudos, mano_roja.</p>
 */
public final class SVZMobsAPI {
    private SVZMobsAPI() {}

    /** @return los ids de todos los mobs de SVZ. */
    public static Set<String> ids() {
        return ModEntities.ALL.keySet();
    }

    /**
     * Genera un mob de SVZ en la posición indicada (úsalo desde misiones: p. ej. {@code "espantapajaros"}
     * en la misión 2 o {@code "mano_roja"} para el jefe final).
     * @return el mob creado, o {@code null} si el id no existe
     */
    public static Mob spawn(ServerLevel level, String id, double x, double y, double z) {
        EntityType<? extends Mob> type = ModEntities.ALL.get(id);
        if (type == null) return null;
        Mob mob = type.create(level, EntitySpawnReason.EVENT);
        if (mob == null) return null;
        mob.setPos(x, y, z);
        mob.setYRot(level.random.nextFloat() * 360.0F);
        level.addFreshEntity(mob);
        return mob;
    }

    // ------------------------------------------------------------ Títere Jugador con copia del inventario
    /**
     * Crea el Títere Jugador de un jugador: lleva su nombre, viste su armadura y objetos de mano y y, si el jugador murió sin Hilo de Cofre y sin hilos
     * del alma, lleva todo su inventario y lo suelta al ser derrotado (con Hilo de Cofre es solo un doble, sin objetos).
     */
    public static Mob crearTitereJugador(net.minecraft.server.level.ServerPlayer p) {
        if (!(p.level() instanceof ServerLevel level)) return null;
        Mob m = spawn(level, "titere_jugador", p.getX(), p.getY(), p.getZ());
        if (m == null) return null;
        m.setCustomName(net.minecraft.network.chat.Component.literal("Títere de " + p.getName().getString()));
        m.addTag("svz_titere_de:" + p.getUUID());
        com.svz.mobs.logic.DeathSnapshot.Foto foto = com.svz.mobs.logic.DeathSnapshot.tomar(p);
        java.util.List<net.minecraft.world.item.ItemStack> inv;
        if (foto != null) {
            inv = foto.items();
        } else { // sin muerte reciente (admin, drenaje...): se viste con lo que lleva ahora
            inv = new java.util.ArrayList<>();
            for (int i = 0; i < p.getInventory().getContainerSize(); i++) inv.add(p.getInventory().getItem(i).copy());
        }
        // Aspecto: igual que el jugador (armadura, mano principal y secundaria)
        net.minecraft.world.entity.EquipmentSlot[] armadura = {net.minecraft.world.entity.EquipmentSlot.FEET, net.minecraft.world.entity.EquipmentSlot.LEGS,
                net.minecraft.world.entity.EquipmentSlot.CHEST, net.minecraft.world.entity.EquipmentSlot.HEAD};
        for (int k = 0; k < 4 && 36 + k < inv.size(); k++) {
            if (!inv.get(36 + k).isEmpty()) m.setItemSlot(armadura[k], inv.get(36 + k).copy());
        }
        if (inv.size() > 40 && !inv.get(40).isEmpty()) m.setItemSlot(net.minecraft.world.entity.EquipmentSlot.OFFHAND, inv.get(40).copy());
        for (int i = 0; i < 9 && i < inv.size(); i++) { // primer objeto de la barra rápida en la mano
            if (!inv.get(i).isEmpty()) {
                m.setItemSlot(net.minecraft.world.entity.EquipmentSlot.MAINHAND, inv.get(i).copy());
                break;
            }
        }
        // Solo si el inventario del jugador desapareció (sin Hilo de Cofre y sin hilos del alma) el Títere lo lleva y lo suelta.
        // Con Hilo de Cofre es un simple doble: no suelta objetos, así nada se duplica.
        if (foto != null && foto.modo() == com.svz.mobs.logic.DeathSnapshot.Modo.MOVER) {
            java.util.List<net.minecraft.world.item.ItemStack> copia = new java.util.ArrayList<>();
            for (net.minecraft.world.item.ItemStack st : inv) if (!st.isEmpty()) copia.add(st.copy());
            m.setAttached(com.svz.mobs.entity.ModAttachments.INVENTARIO_COPIA, copia);
        }
        return m;
    }

    // ------------------------------------------------------------ zonas seguras (las registra SVZ-TelarRoto)
    public interface ZonaSegura {
        /** {@code true} si no deben aparecer espectros cerca de este jugador (zona segura o periodo de gracia). */
        boolean protegido(net.minecraft.server.level.ServerPlayer p);

        /** {@code true} si esa posición está dentro de una zona segura (no se generan mobs allí). */
        boolean posicionSegura(ServerLevel level, double x, double z);
    }

    private static final java.util.List<ZonaSegura> ZONAS = new java.util.concurrent.CopyOnWriteArrayList<>();

    public static void registrarZonaSegura(ZonaSegura z) {
        ZONAS.add(z);
    }

    public static boolean spawnBloqueado(net.minecraft.server.level.ServerPlayer p) {
        for (ZonaSegura z : ZONAS) if (z.protegido(p)) return true;
        return false;
    }

    public static boolean posicionProtegida(ServerLevel level, double x, double z) {
        for (ZonaSegura s : ZONAS) if (s.posicionSegura(level, x, z)) return true;
        return false;
    }

    /** @return {@code true} si la entidad es un mob de SVZ (poseído, títere, espectro o jefe). */
    public static boolean esSVZ(Entity e) {
        return e instanceof SVZMobMarker;
    }

    /** @return {@code true} si es una de las 9 variantes poseídas (liberables con el ritual). */
    public static boolean esPoseidoLiberable(Entity e) {
        return e instanceof SVZPossessed;
    }
}
