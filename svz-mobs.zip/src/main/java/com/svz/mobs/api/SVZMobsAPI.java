package com.svz.mobs.api;

import com.svz.mobs.entity.ModEntities;
import com.svz.mobs.entity.SVZMobMarker;
import com.svz.mobs.entity.SVZPossessed;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;

import java.util.Set;

/**
 * API pública de SVZ-Mobs para misiones, mundo y otros mods.
 *
 * <p>Ids: vaca_poseida, cerdo_poseido, oveja_poseida, aldeano_poseido, lobo_poseido, creeper_poseido,
 * golem_poseido, piglin_poseido, warden_poseido, titere_simple, titere_guerrero, titere_colosal,
 * titere_jugador, espectro_titere, espectro_errante, guardian_del_nudo, primer_titere, espantapajaros,
 * silbon_titere, cangrejo_mano_roja, cachicama_blindada, sayona_de_hilos, guardian_de_nudos, mano_roja.</p>
 */
public final class SVZMobsAPI {
    private SVZMobsAPI() {}

    /** @return los ids de todos los mobs de SVZ. */
    public static Set<String> ids() {
        return ModEntities.ALL.keySet();
    }

    /**
     * Genera un mob de SVZ en la posición indicada (úsalo desde misiones: p. ej. {@code "espantapajaros"}
     * en la misión 2 o {@code "mano_roja"} para el jefe final).
     * @return el mob creado, o {@code null} si el id no existe
     */
    public static Mob spawn(ServerLevel level, String id, double x, double y, double z) {
        EntityType<? extends Mob> type = ModEntities.ALL.get(id);
        if (type == null) return null;
        Mob mob = type.create(level, EntitySpawnReason.EVENT);
        if (mob == null) return null;
        mob.setPos(x, y, z);
        mob.setYRot(level.random.nextFloat() * 360.0F);
        level.addFreshEntity(mob);
        return mob;
    }

    /** @return {@code true} si la entidad es un mob de SVZ (poseído, títere, espectro o jefe). */
    public static boolean esSVZ(Entity e) {
        return e instanceof SVZMobMarker;
    }

    /** @return {@code true} si es una de las 9 variantes poseídas (liberables con el ritual). */
    public static boolean esPoseidoLiberable(Entity e) {
        return e instanceof SVZPossessed;
    }
}
