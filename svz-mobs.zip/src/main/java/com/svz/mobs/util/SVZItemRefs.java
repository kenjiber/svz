package com.svz.mobs.util;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/** Acceso a los ítems de SVZ-Items por nombre (sin depender de sus clases internas). */
public final class SVZItemRefs {
    private SVZItemRefs() {}

    public static Item get(String path) {
        return BuiltInRegistries.ITEM.getValue(Identifier.fromNamespaceAndPath("svz-items", path));
    }

    public static ItemStack stack(String path, int count) {
        return new ItemStack(get(path), count);
    }
}
