package com.svz.mobs.client;

import com.svz.mobs.entity.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.world.entity.animal.*;
import net.minecraft.world.entity.animal.cow.Cow;
import net.minecraft.world.entity.animal.pig.Pig;
import net.minecraft.world.entity.animal.sheep.Sheep;
import net.minecraft.world.entity.animal.wolf.Wolf;
import net.minecraft.world.entity.animal.golem.IronGolem;
import net.minecraft.world.entity.monster.*;
import net.minecraft.world.entity.monster.zombie.Zombie;
import net.minecraft.world.entity.monster.zombie.ZombifiedPiglin;
import net.minecraft.world.entity.monster.zombie.ZombieVillager;
import net.minecraft.world.entity.monster.warden.Warden;

public class SVZMobsClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.<Cow>register(ModEntities.VACA, CowRenderer::new);
        EntityRendererRegistry.<Pig>register(ModEntities.CERDO, PigRenderer::new);
        EntityRendererRegistry.<Sheep>register(ModEntities.OVEJA, SheepRenderer::new);
        EntityRendererRegistry.<ZombieVillager>register(ModEntities.ALDEANO, ZombieVillagerRenderer::new);
        EntityRendererRegistry.<Wolf>register(ModEntities.LOBO, WolfRenderer::new);
        EntityRendererRegistry.<Creeper>register(ModEntities.CREEPER, CreeperRenderer::new);
        EntityRendererRegistry.<IronGolem>register(ModEntities.GOLEM, IronGolemRenderer::new);

        EntityRendererRegistry.register(ModEntities.PIGLIN, ctx -> new ZombifiedPiglinRenderer(
                ctx,
                ModelLayers.ZOMBIFIED_PIGLIN,
                ModelLayers.ZOMBIFIED_PIGLIN_INNER_ARMOR,
                ModelLayers.ZOMBIFIED_PIGLIN_OUTER_ARMOR
        ));

        EntityRendererRegistry.<Warden>register(ModEntities.WARDEN, WardenRenderer::new);

        ModEntities.BOSSES.values().forEach(t -> EntityRendererRegistry.<Zombie>register(t, ZombieRenderer::new));
    }
}