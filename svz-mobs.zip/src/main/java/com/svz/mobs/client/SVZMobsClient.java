package com.svz.mobs.client;

import com.svz.mobs.entity.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.world.entity.animal.*;
import net.minecraft.world.entity.monster.*;
import net.minecraft.world.entity.monster.warden.Warden;

/**
 * Renderers. Por ahora cada mob reutiliza el modelo/render de su base vanilla (ver README):
 * los modelos propios con GeckoLib se añadirán como renderers aquí sin tocar el resto del mod.
 */
public class SVZMobsClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.<Cow>register(ModEntities.VACA, CowRenderer::new);
        EntityRendererRegistry.<Pig>register(ModEntities.CERDO, PigRenderer::new);
        EntityRendererRegistry.<Sheep>register(ModEntities.OVEJA, SheepRenderer::new);
        EntityRendererRegistry.<ZombieVillager>register(ModEntities.ALDEANO, ZombieVillagerRenderer::new);
        EntityRendererRegistry.<Wolf>register(ModEntities.LOBO, WolfRenderer::new);
        EntityRendererRegistry.<Creeper>register(ModEntities.CREEPER, CreeperRenderer::new);
        EntityRendererRegistry.<IronGolem>register(ModEntities.GOLEM, IronGolemRenderer::new);
        EntityRendererRegistry.<ZombifiedPiglin>register(ModEntities.PIGLIN, ZombifiedPiglinRenderer::new);
        EntityRendererRegistry.<Warden>register(ModEntities.WARDEN, WardenRenderer::new);
        ModEntities.BOSSES.values().forEach(t -> EntityRendererRegistry.<Zombie>register(t, ZombieRenderer::new));
    }
}
