package com.svz.mobs.ritual;

import com.svz.core.api.SVZClass;
import com.svz.core.api.SVZCoreAPI;
import com.svz.mobs.SVZMobsMod;
import com.svz.mobs.api.SVZMobsAPI;
import com.svz.mobs.entity.PossessedState;
import com.svz.mobs.entity.SVZPossessed;
import com.svz.mobs.entity.SVZPossessedLogic;
import com.svz.mobs.util.SVZItemRefs;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.item.ItemStack;

import java.util.UUID;

/**
 * Ritual de liberación en 3 fases:
 * 1) el poseído sigue hostil y aparecen adds (Espectros Errantes);
 * 2) al caer los adds aparece el Núcleo de Hilo flotante: solo el Herrero puede golpearlo;
 * 3) el poseído recupera el control: hay que inmovilizarlo (soga/lead) y darle una Arepa de la Resistencia.
 */
public final class SVZRitual {
    private SVZRitual() {}

    public static final String TAG_NUCLEO = "svz_nucleo";
    public static final String TAG_NUCLEO_DE = "svz_nucleo_de:";

    // ------------------------------------------------------------ inicio
    public static void iniciar(ServerPlayer jugador, SVZPossessed p, ItemStack hilo) {
        PossessedState s = p.svzState();
        Mob m = p.svzSelf();
        if (s.ritualFase != 0) {
            jugador.displayClientMessage(Component.literal("El ritual ya está en curso."), true);
            return;
        }
        if (!jugador.getAbilities().instabuild) hilo.shrink(1);
        s.ritualFase = 1;
        s.ritualTicks = 0;
        s.adds.clear();
        ServerLevel level = (ServerLevel) m.level();
        for (int i = 0; i < s.profile.tier().adds; i++) {
            double a = level.random.nextDouble() * Math.PI * 2;
            Mob add = SVZMobsAPI.spawn(level, "espectro_errante", m.getX() + Math.cos(a) * 4, m.getY(), m.getZ() + Math.sin(a) * 4);
            if (add != null) s.adds.add(add.getUUID());
        }
        aviso(level, m, "Ritual - Fase 1: derrota a los hilos que lo rodean.");
    }

    // ------------------------------------------------------------ tick
    public static void tick(SVZPossessed p, ServerLevel level) {
        PossessedState s = p.svzState();
        if (s.ritualFase == 0) return;
        Mob m = p.svzSelf();
        s.ritualTicks++;
        if (s.ritualTicks > SVZMobsMod.CONFIG.ritualTimeoutSegundos * 20) {
            fallar(p, level, "El ritual se ha deshecho: el hilo recupera al poseído.");
            return;
        }
        switch (s.ritualFase) {
            case 1 -> {
                boolean todosMuertos = true;
                for (UUID id : s.adds) {
                    Entity e = level.getEntity(id);
                    if (e != null && e.isAlive()) todosMuertos = false;
                }
                if (todosMuertos) fase2(p, level);
            }
            case 2 -> {
                Entity core = s.nucleo == null ? null : level.getEntity(s.nucleo);
                if (core == null || !core.isAlive()) crearNucleo(p, level); // se rompió por otra causa: reaparece
                else core.setPos(m.getX(), m.getY() + m.getBbHeight() + 0.8, m.getZ());
            }
            case 3 -> {
                m.setTarget(null);
                if (s.atado) m.getNavigation().stop();
            }
            default -> { }
        }
    }

    private static void fase2(SVZPossessed p, ServerLevel level) {
        PossessedState s = p.svzState();
        Mob m = p.svzSelf();
        s.ritualFase = 2;
        s.golpesNucleo = 0;
        s.golpesNecesarios = 4 + s.profile.tier().ordinal() * 3;
        m.setInvulnerable(true);
        crearNucleo(p, level);
        aviso(level, m, "Ritual - Fase 2: ¡el Herrero debe golpear el Núcleo de Hilo (" + s.golpesNecesarios + " golpes)!");
    }

    private static void crearNucleo(SVZPossessed p, ServerLevel level) {
        PossessedState s = p.svzState();
        Mob m = p.svzSelf();
        ArmorStand a = new ArmorStand(level, m.getX(), m.getY() + m.getBbHeight() + 0.8, m.getZ());
        a.setNoGravity(true);
        a.setInvisible(true);
        a.setSilent(true);
        a.setGlowingTag(true);
        a.addTag(TAG_NUCLEO);
        a.addTag(TAG_NUCLEO_DE + m.getUUID());
        a.setItemSlot(EquipmentSlot.HEAD, SVZItemRefs.stack("nucleo_de_hilo", 1));
        a.setCustomName(Component.literal("Núcleo de Hilo"));
        level.addFreshEntity(a);
        s.nucleo = a.getUUID();
    }

    // ------------------------------------------------------------ fase 2: golpes al núcleo
    /** Llamado cuando un jugador ataca al Núcleo de Hilo flotante. */
    public static void golpearNucleo(ServerPlayer jugador, Entity nucleo) {
        ServerLevel level = (ServerLevel) nucleo.level();
        UUID duenio = null;
        for (String t : nucleo.getTags()) {
            if (t.startsWith(TAG_NUCLEO_DE)) duenio = UUID.fromString(t.substring(TAG_NUCLEO_DE.length()));
        }
        if (duenio == null || !(level.getEntity(duenio) instanceof SVZPossessed p)) return;
        if (SVZCoreAPI.getClase(jugador) != SVZClass.HERRERO) {
            jugador.displayClientMessage(Component.literal("Solo un Herrero puede golpear el Núcleo de Hilo."), true);
            return;
        }
        PossessedState s = p.svzState();
        s.golpesNucleo++;
        level.sendParticles(ParticleTypes.CRIT, nucleo.getX(), nucleo.getY() + 1, nucleo.getZ(), 15, 0.3, 0.3, 0.3, 0.2);
        jugador.displayClientMessage(Component.literal("Núcleo: " + s.golpesNucleo + "/" + s.golpesNecesarios), true);
        if (s.golpesNucleo >= s.golpesNecesarios) {
            nucleo.discard();
            s.nucleo = null;
            fase3(p, level);
        }
    }

    private static void fase3(SVZPossessed p, ServerLevel level) {
        PossessedState s = p.svzState();
        Mob m = p.svzSelf();
        s.ritualFase = 3;
        s.atado = false;
        m.setTarget(null);
        m.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, MobEffectInstance.INFINITE_DURATION, 3, false, false));
        aviso(level, m, "Ritual - Fase 3: recupera el control. ¡Inmovilízalo con una soga y dale una Arepa de la Resistencia (no lo mates)!");
    }

    // ------------------------------------------------------------ fase 3: inmovilizar y alimentar
    public static void intentarAtar(ServerPlayer jugador, SVZPossessed p, ItemStack soga) {
        PossessedState s = p.svzState();
        if (s.atado) {
            jugador.displayClientMessage(Component.literal("Ya está inmovilizado: dale la Arepa de la Resistencia."), true);
            return;
        }
        if (!jugador.getAbilities().instabuild) soga.shrink(1);
        s.atado = true;
        p.svzSelf().setNoAi(true);
        jugador.displayClientMessage(Component.literal("Lo inmovilizas con la soga."), true);
    }

    public static void intentarAlimentar(ServerPlayer jugador, SVZPossessed p, ItemStack arepa) {
        PossessedState s = p.svzState();
        if (s.ritualFase < 3) {
            jugador.displayClientMessage(Component.literal("Aún no es el momento: completa las fases anteriores."), true);
            return;
        }
        if (!s.atado) {
            jugador.displayClientMessage(Component.literal("Primero hay que inmovilizarlo (usa una soga)."), true);
            return;
        }
        if (!jugador.getAbilities().instabuild) arepa.shrink(1);
        liberar(p, (ServerLevel) p.svzSelf().level(), jugador);
    }

    // ------------------------------------------------------------ resultado
    /** Éxito: vuelve a su forma vanilla, loot doble + Nudo Rojo y queda agradecido. */
    public static void liberar(SVZPossessed p, ServerLevel level, ServerPlayer liberador) {
        PossessedState s = p.svzState();
        Mob m = p.svzSelf();
        s.liberado = true;
        limpiar(level, s);

        EntityType<? extends Mob> tipo = s.profile.libre().get();
        Mob libre = tipo.create(level, EntitySpawnReason.CONVERSION);
        if (libre != null) {
            libre.setPos(m.getX(), m.getY(), m.getZ());
            libre.setYRot(m.getYRot());
            libre.setCustomName(Component.literal("Agradecido"));
            libre.addEffect(new MobEffectInstance(MobEffects.GLOWING, 100, 0, false, false));
            level.addFreshEntity(libre);
        }
        for (ItemStack base : s.profile.recompensa()) {
            m.spawnAtLocation(level, new ItemStack(base.getItem(), base.getCount() * 2)); // loot doble
        }
        m.spawnAtLocation(level, SVZItemRefs.stack("nudo_rojo", 1));
        level.sendParticles(ParticleTypes.HEART, m.getX(), m.getY() + m.getBbHeight(), m.getZ(), 20, 0.6, 0.6, 0.6, 0.0);
        if (liberador != null) {
            liberador.addEffect(new MobEffectInstance(MobEffects.LUCK, 6000, 0));
            liberador.displayClientMessage(Component.literal("¡Liberado! El mob te lo agradece."), false);
        }
        m.discard();
    }

    private static void fallar(SVZPossessed p, ServerLevel level, String msg) {
        PossessedState s = p.svzState();
        Mob m = p.svzSelf();
        limpiar(level, s);
        s.ritualFase = 0;
        s.atado = false;
        m.setInvulnerable(false);
        m.setNoAi(false);
        m.removeEffect(MobEffects.SLOWNESS);
        aviso(level, m, msg);
    }

    /** Elimina adds y núcleo de un ritual (al morir, liberar o fallar). */
    public static void limpiar(ServerLevel level, PossessedState s) {
        for (UUID id : s.adds) {
            Entity e = level.getEntity(id);
            if (e != null) e.discard();
        }
        s.adds.clear();
        if (s.nucleo != null) {
            Entity e = level.getEntity(s.nucleo);
            if (e != null) e.discard();
            s.nucleo = null;
        }
    }

    private static void aviso(ServerLevel level, Mob m, String msg) {
        for (ServerPlayer pl : level.getEntitiesOfClass(ServerPlayer.class, m.getBoundingBox().inflate(32))) {
            pl.displayClientMessage(Component.literal(msg), false);
        }
    }
}
