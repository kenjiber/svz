package com.svz.mobs.logic;

import com.svz.core.api.SVZCoreAPI;
import com.svz.core.event.SVZMuerteTelarEvent;
import com.svz.core.event.SVZPosesionEvent;
import com.svz.items.api.SVZItemsAPI;
import com.svz.items.item.ModItems;
import com.svz.mobs.api.SVZMobsAPI;
import com.svz.mobs.entity.DrainCounter;
import com.svz.mobs.entity.SVZMobMarker;
import com.svz.mobs.entity.SVZPossessed;
import com.svz.mobs.ritual.SVZRitual;
import com.svz.mobs.spawn.SVZSpawner;
import com.svz.mobs.util.SVZItemRefs;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/** Integración: drenaje con SVZ-Core, ritual, Títere Jugador, Espectro Títere y Hilo de Anclaje. */
public final class SVZMobEvents {
    private SVZMobEvents() {}

    /** Jugadores cuyo Hilo de Anclaje ya se consumió para su muerte actual en el Telar Roto. */
    private static final Set<UUID> ANCLADOS = new HashSet<>();

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(SVZSpawner::tick);

        // ---- drenaje de hilos cada X golpes (SVZ-Core)
        ServerLivingEntityEvents.AFTER_DAMAGE.register((entity, source, base, taken, blocked) -> {
            if (!com.svz.mobs.SVZMobsMod.CONFIG.drenajeIntegrado) return;
            if (blocked || taken <= 0 || !(entity instanceof ServerPlayer victima)) return;
            if (victima.isSpectator() || victima.isCreative()) return;
            if (source.getEntity() instanceof SVZMobMarker m) {
                DrainCounter d = m.svzDrain();
                if (++d.hits >= d.perHits) {
                    d.hits = 0;
                    SVZCoreAPI.drenarHilos(victima, d.amount, m.svzSelf());
                }
            }
        });

        // ---- ritual: Hilo de Liberación, soga y Arepa de la Resistencia sobre poseídos
        UseEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (!(world instanceof ServerLevel) || !(player instanceof ServerPlayer sp)) return InteractionResult.PASS;
            if (entity instanceof ArmorStand && entity.getTags().contains(SVZRitual.TAG_NUCLEO)) return InteractionResult.SUCCESS;
            ItemStack stack = sp.getItemInHand(hand);
            if (stack.isEmpty()) return InteractionResult.PASS;
            boolean liberacion = stack.is(SVZItemRefs.get("hilo_de_liberacion"));
            if (entity instanceof SVZPossessed p) {
                if (liberacion) {
                    SVZRitual.iniciar(sp, p, stack);
                    return InteractionResult.SUCCESS;
                }
                if (p.svzState().ritualFase >= 3 && stack.is(Items.LEAD)) {
                    SVZRitual.intentarAtar(sp, p, stack);
                    return InteractionResult.SUCCESS;
                }
                if (stack.is(SVZItemRefs.get("arepa_de_la_resistencia")) && p.svzState().ritualFase > 0) {
                    SVZRitual.intentarAlimentar(sp, p, stack);
                    return InteractionResult.SUCCESS;
                }
            } else if (entity instanceof SVZMobMarker && liberacion) {
                sp.displayClientMessage(Component.literal("Este ser no se libera con un simple hilo."), true);
                return InteractionResult.FAIL;
            }
            return InteractionResult.PASS;
        });

        // ---- ritual fase 2: golpes al Núcleo de Hilo flotante (solo Herrero)
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (entity instanceof ArmorStand && entity.getTags().contains(SVZRitual.TAG_NUCLEO)) {
                if (world instanceof ServerLevel && player instanceof ServerPlayer sp) SVZRitual.golpearNucleo(sp, entity);
                return InteractionResult.SUCCESS;
            }
            return InteractionResult.PASS;
        });

        // ---- Títere Jugador: un jugador que se queda sin hilos se duplica como mini-jefe
        SVZPosesionEvent.EVENT.register((player, causa) -> {
            if (!com.svz.mobs.SVZMobsMod.CONFIG.titereJugadorAlPoseer) return;
            if (causa != SVZPosesionEvent.Causa.HILOS_AGOTADOS || !(player.level() instanceof ServerLevel level)) return;
            SVZMobsAPI.crearTitereJugador(player); // con copia completa del inventario
        });

        // ---- Hilo de Anclaje: se consume antes de que se vacíe el inventario al morir en el Telar Roto
        ServerLivingEntityEvents.ALLOW_DEATH.register((entity, source, amount) -> {
            if (entity instanceof ServerPlayer p && SVZCoreAPI.isInTelarRoto(p) && !llevaHiloVida(p)
                    && SVZItemsAPI.consumirAnclaje(p)) {
                ANCLADOS.add(p.getUUID());
            }
            return true;
        });

        // ---- Espectro Títere: jugador muerto en el Telar Roto, poseído
        SVZMuerteTelarEvent.EVENT.register((player, source, permanente) -> {
            if (ANCLADOS.remove(player.getUUID())) {
                player.displayClientMessage(Component.literal("Tu Hilo de Anclaje impidió que tu espectro se alzara."), true);
                return;
            }
            if (!(player.level() instanceof ServerLevel level)) return;
            Mob esp = SVZMobsAPI.spawn(level, "espectro_titere", player.getX(), player.getY(), player.getZ());
            if (esp != null) esp.setCustomName(Component.literal("Espectro de " + player.getName().getString()));
        });
    }

    private static boolean llevaHiloVida(ServerPlayer p) {
        return p.getMainHandItem().is(ModItems.HILO_VIDA) || p.getOffhandItem().is(ModItems.HILO_VIDA);
    }
}
