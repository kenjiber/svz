package com.svz.mobs.logic;

import com.svz.core.SVZConfig;
import com.svz.core.api.SVZCoreAPI;
import com.svz.items.item.ModItems;
import com.svz.mobs.SVZMobsMod;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.Event;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Foto del inventario de un jugador justo antes de morir y decisión de qué pasa con él al quedarse sin hilos del alma:
 * <ul>
 *   <li><b>COPIA_VISUAL</b>: muere con Hilo de Cofre. Conserva su inventario (lo devuelve SVZ-Items) y el Títere es solo un
 *       doble: viste lo mismo pero no suelta objetos (así no se duplican).</li>
 *   <li><b>MOVER</b>: muere sin Hilo de Cofre y sin hilos del alma. Su inventario desaparece y pasa íntegro al Títere, que
 *       lo suelta al ser derrotado (aunque el jugador reviva, tendrá que matarlo para recuperarlo).</li>
 *   <li><b>NINGUNO</b>: cualquier otra muerte (comportamiento normal).</li>
 * </ul>
 */
public final class DeathSnapshot {
    private DeathSnapshot() {}

    public enum Modo { NINGUNO, COPIA_VISUAL, MOVER_PENDIENTE, MOVER }

    public static final class Foto {
        final long tick;
        final List<ItemStack> items;
        final ServerLevel level;
        final Vec3 pos;
        Modo modo;

        Foto(long tick, List<ItemStack> items, ServerLevel level, Vec3 pos, Modo modo) {
            this.tick = tick;
            this.items = items;
            this.level = level;
            this.pos = pos;
            this.modo = modo;
        }

        public List<ItemStack> items() {
            return items;
        }

        public Modo modo() {
            return modo;
        }
    }

    private static final Map<UUID, Foto> FOTOS = new HashMap<>();

    public static void register() {
        Identifier primero = SVZMobsMod.id("foto_inventario");
        Identifier tarde = SVZMobsMod.id("inventario_perdido");
        ServerLivingEntityEvents.ALLOW_DEATH.addPhaseOrdering(primero, Event.DEFAULT_PHASE);
        ServerLivingEntityEvents.ALLOW_DEATH.addPhaseOrdering(Event.DEFAULT_PHASE, tarde);

        // Antes que nadie: foto del inventario y decisión
        ServerLivingEntityEvents.ALLOW_DEATH.register(primero, (entity, source, amount) -> {
            if (!(entity instanceof ServerPlayer p) || !(p.level() instanceof ServerLevel level)) return true;
            Inventory inv = p.getInventory();
            List<ItemStack> l = new ArrayList<>();
            boolean cofre = p.getMainHandItem().is(ModItems.HILO_COFRE) || p.getOffhandItem().is(ModItems.HILO_COFRE); // solo en las manos
            for (int i = 0; i < inv.getContainerSize(); i++) {
                ItemStack s = inv.getItem(i).copy();
                l.add(s);
            }
            // la muerte cuesta hilos del alma: si no quedan, el jugador queda poseído y sale el Títere
            boolean sinHilos = SVZCoreAPI.getHilos(p) <= SVZConfig.PERDIDA_MUERTE
                    && !SVZCoreAPI.isInTelarRoto(p) && !SVZCoreAPI.isMuertePermanente(p);
            Modo modo = !sinHilos ? Modo.NINGUNO : (cofre ? Modo.COPIA_VISUAL : Modo.MOVER_PENDIENTE);
            FOTOS.put(p.getUUID(), new Foto(level.getServer().getTickCount(), l, level, p.position(), modo));
            return true;
        });

        // Después de Hilo de Vida y Hilo de Cofre: si la muerte sigue adelante y no hay Cofre, el inventario desaparece
        ServerLivingEntityEvents.ALLOW_DEATH.register(tarde, (entity, source, amount) -> {
            if (entity instanceof ServerPlayer p) {
                Foto f = FOTOS.get(p.getUUID());
                if (f != null && f.modo == Modo.MOVER_PENDIENTE && f.tick == p.level().getServer().getTickCount()) {
                    p.getInventory().clearContent();
                    f.modo = Modo.MOVER;
                }
            }
            return true;
        });
    }

    /** @return la foto de la muerte reciente (menos de 2 s) o {@code null}. La foto se consume. */
    public static Foto tomar(ServerPlayer p) {
        Foto f = FOTOS.remove(p.getUUID());
        if (f == null || p.level().getServer().getTickCount() - f.tick > 40) return null;
        return f;
    }

    /**
     * Seguridad: si el inventario se quitó pero nadie creó el Títere (p. ej. la muerte no acabó en posesión),
     * los objetos se sueltan donde murió para que no se pierdan.
     */
    public static void tick(MinecraftServer server) {
        if (FOTOS.isEmpty()) return;
        long ahora = server.getTickCount();
        for (var e : new ArrayList<>(FOTOS.entrySet())) {
            Foto f = e.getValue();
            long edad = ahora - f.tick;
            if (f.modo == Modo.MOVER && edad > 10) {
                BlockPos bp = BlockPos.containing(f.pos);
                for (ItemStack s : f.items) if (!s.isEmpty()) Block.popResource(f.level, bp, s.copy());
                FOTOS.remove(e.getKey());
            } else if (edad > 400) {
                FOTOS.remove(e.getKey());
            }
        }
    }
}
