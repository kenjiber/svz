package com.svz.mobs;

import com.svz.mobs.command.SVZMobsCommands;
import com.svz.mobs.config.SVZMobsConfig;
import com.svz.mobs.entity.ModEntities;
import com.svz.mobs.logic.SVZMobEvents;
import net.fabricmc.api.ModInitializer;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SVZMobsMod implements ModInitializer {
    public static final String MOD_ID = "svz-mobs";
    public static final Logger LOGGER = LoggerFactory.getLogger("SVZ-Mobs");
    public static SVZMobsConfig CONFIG;

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        CONFIG = SVZMobsConfig.load();
        com.svz.mobs.entity.ModAttachments.register();
        com.svz.mobs.logic.DeathSnapshot.register();
        ModEntities.register();
        SVZMobEvents.register();
        SVZMobsCommands.register();
        LOGGER.info("SVZ-Mobs cargado.");
    }
}
