package com.svz.mobs.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.svz.mobs.SVZMobsMod;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** Configuración en config/svz-mobs.json (se crea sola la primera vez). */
public class SVZMobsConfig {
    /** Golpes de un poseído antes de drenar hilos (X). */
    public int hitsPorDrenajePoseido = 3;
    /** Golpes de un mini-jefe antes de drenar. */
    public int hitsPorDrenajeMini = 2;
    /** Golpes de un jefe antes de drenar. */
    public int hitsPorDrenajeJefe = 2;
    /** Poseídos que aparecen cada amanecer. */
    public int poseidosPorDia = 1;
    /** Máximo de poseídos vivos acumulados en el Overworld. */
    public int maxPoseidosAcumulados = 5;
    /** Máximo de Espectros Errantes cerca de un jugador en el Telar Roto. */
    public int maxErrantes = 6;
    /** Probabilidad (cada 30 s) de que aparezca un jefe de zona cerca de un jugador que está en su zona. */
    public double probJefeZona = 0.05;
    /** Distancia al origen del Telar Roto a partir de la cual empieza la zona 5 (El Primer Títere). */
    public int zona5Radio = 600;
    /** Tiempo máximo del ritual de liberación antes de fallar (segundos). */
    public int ritualTimeoutSegundos = 300;

    /** Drenaje por golpes integrado en SVZ-Mobs. SVZ-Posesion lo desactiva y aplica sus propias reglas. */
    public boolean drenajeIntegrado = true;
    /** Spawn del Títere Jugador al quedarse un jugador sin hilos (SVZ-Posesion lo gestiona él mismo). */
    public boolean titereJugadorAlPoseer = true;
    /** Hilos drenados por cada habilidad de un mini-jefe / de un jefe de zona. */
    public int drenajeHabilidadMini = 2;
    public int drenajeHabilidadJefe = 1;

    public static SVZMobsConfig load() {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        Path file = FabricLoader.getInstance().getConfigDir().resolve("svz-mobs.json");
        try {
            if (Files.exists(file)) {
                SVZMobsConfig c = gson.fromJson(Files.readString(file), SVZMobsConfig.class);
                if (c != null) return c;
            }
            SVZMobsConfig def = new SVZMobsConfig();
            Files.writeString(file, gson.toJson(def));
            return def;
        } catch (Exception e) {
            SVZMobsMod.LOGGER.warn("No se pudo leer la config, usando valores por defecto", e);
            return new SVZMobsConfig();
        }
    }
}
