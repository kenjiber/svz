# SVZ-Core (svzcore)
Base de los mods de Sobreviviendo a Venezuela. Minecraft 1.21.11 · Fabric · Java 21.

## Compilar
    gradle wrapper && ./gradlew build     (genera build/libs/svz-core-1.0.0.jar)
O abre la carpeta en IntelliJ IDEA e importa el proyecto Gradle.

## Usar la API desde otro mod
    modImplementation files("libs/svz-core-1.0.0.jar")
    // fabric.mod.json -> "depends": { "svzcore": "*" }

    SVZCoreAPI.getHilos(player); SVZCoreAPI.addHilos(player, 2);
    SVZCoreAPI.setTelarRotoDimension(miDimensionKey);   // por defecto svzcore:telar_roto
    SVZClaseChangeEvent.EVENT.register((p, vieja, nueva) -> { ... });
    SVZHud.registerElement(id, order, (g, dt, x, y) -> alturaUsada);

Mobs que drenan hilos: añádelos al tag `svzcore:drena_hilos` (entity_type).
Balance: edita SVZConfig.java.
