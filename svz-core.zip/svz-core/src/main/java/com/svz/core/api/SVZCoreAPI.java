package com.svz.core.api;

import com.svz.core.SVZConfig;
import com.svz.core.SVZCore;
import com.svz.core.data.SVZData;
import com.svz.core.data.SVZPlayerData;
import com.svz.core.event.SVZClaseChangeEvent;
import com.svz.core.event.SVZHilosChangeEvent;
import com.svz.core.event.SVZHilosChangeEvent.Reason;
import com.svz.core.event.SVZPosesionEvent;
import com.svz.core.net.SVZNetworking;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.Level;

/**
 * API pública de SVZ-Core. Todos los demás mods SVZ deben usar esta clase
 * en lugar de tocar los datos del jugador directamente.
 *
 * <p>Todos los métodos son <b>solo de servidor</b> (reciben {@link ServerPlayer}) y se
 * sincronizan automáticamente con el cliente para el HUD.</p>
 *
 * <p>Gradle: {@code modImplementation files("libs/svz-core-1.0.0.jar")} y declara
 * {@code "svzcore": "*"} en las dependencias de tu fabric.mod.json.</p>
 */
public final class SVZCoreAPI {
    private SVZCoreAPI() {}

    private static volatile ResourceKey<Level> telarRoto =
            ResourceKey.create(Registries.DIMENSION, Identifier.fromNamespaceAndPath(SVZCore.MOD_ID, "telar_roto"));

    // =====================================================================
    // HILOS DEL ALMA
    // =====================================================================

    /** @return Hilos del Alma actuales del jugador. */
    public static int getHilos(ServerPlayer player) {
        return SVZData.get(player).hilos;
    }

    /** @return máximo de hilos según su clase (10, o 20 para Guerrero). */
    public static int getMaxHilos(ServerPlayer player) {
        return SVZData.get(player).clase.getHilosIniciales();
    }

    /**
     * Fija los hilos (limitado a 0..máximo de la clase). Dispara {@link SVZHilosChangeEvent}.
     * Si llega a 0 el jugador pasa a poseído ({@link SVZPosesionEvent}).
     */
    public static void setHilos(ServerPlayer player, int value) {
        setHilos(player, value, Reason.API, null);
    }

    /**
     * Igual que {@link #setHilos(ServerPlayer, int)} indicando causa y fuente.
     * @param source entidad responsable (puede ser {@code null})
     */
    public static void setHilos(ServerPlayer player, int value, Reason reason, Entity source) {
        SVZPlayerData d = SVZData.get(player);
        int old = d.hilos;
        int nv = Mth.clamp(value, 0, d.clase.getHilosIniciales());
        if (nv == old) return;
        d.hilos = nv;
        SVZHilosChangeEvent.EVENT.invoker().onHilosChange(player, old, nv, reason, source);
        if (d.hilos == 0) setPoseido(player, true, SVZPosesionEvent.Causa.HILOS_AGOTADOS);
        SVZNetworking.sync(player);
    }

    /** Suma hilos (cantidad negativa se ignora). */
    public static void addHilos(ServerPlayer player, int amount) {
        addHilos(player, amount, Reason.API, null);
    }

    public static void addHilos(ServerPlayer player, int amount, Reason reason, Entity source) {
        setHilos(player, getHilos(player) + Math.max(0, amount), reason, source);
    }

    /** Resta hilos (cantidad negativa se ignora). */
    public static void removeHilos(ServerPlayer player, int amount) {
        removeHilos(player, amount, Reason.API, null);
    }

    public static void removeHilos(ServerPlayer player, int amount, Reason reason, Entity source) {
        setHilos(player, getHilos(player) - Math.max(0, amount), reason, source);
    }

    /**
     * Drena hilos a un jugador. Úsalo desde mobs poseídos u otros efectos de drenaje.
     * Los mobs del tag {@code svzcore:drena_hilos} y los jugadores poseídos ya drenan solos al golpear.
     */
    public static void drenarHilos(ServerPlayer victim, int amount, Entity source) {
        removeHilos(victim, amount, Reason.DRENAJE, source);
    }

    // =====================================================================
    // POSESIÓN
    // =====================================================================

    /** @return {@code true} si el jugador está marcado como poseído. */
    public static boolean isPoseido(ServerPlayer player) {
        return SVZData.get(player).poseido;
    }

    /** Marca (o libera) al jugador como poseído. Marcar dispara {@link SVZPosesionEvent}. */
    public static void setPoseido(ServerPlayer player, boolean poseido) {
        setPoseido(player, poseido, SVZPosesionEvent.Causa.API);
    }

    public static void setPoseido(ServerPlayer player, boolean poseido, SVZPosesionEvent.Causa causa) {
        SVZPlayerData d = SVZData.get(player);
        if (d.poseido == poseido) return;
        d.poseido = poseido;
        if (poseido) SVZPosesionEvent.EVENT.invoker().onPosesion(player, causa);
        SVZNetworking.sync(player);
    }

    // =====================================================================
    // CLASES
    // =====================================================================

    /** @return clase del jugador ({@link SVZClass#NINGUNA} si no ha elegido). */
    public static SVZClass getClase(ServerPlayer player) {
        return SVZData.get(player).clase;
    }

    /** @return {@code true} si el jugador ya eligió clase. */
    public static boolean hasElegidoClase(ServerPlayer player) {
        return SVZData.get(player).claseElegida;
    }

    /**
     * Elige la clase del jugador. Solo funciona <b>una vez</b>.
     * @return {@code true} si se aplicó; {@code false} si ya había elegido o se pasó NINGUNA.
     */
    public static boolean setClase(ServerPlayer player, SVZClass clase) {
        if (clase == SVZClass.NINGUNA || hasElegidoClase(player)) return false;
        forceSetClase(player, clase);
        return true;
    }

    /**
     * Asigna clase ignorando la restricción de "una sola vez" (admin/comandos).
     * Ajusta los hilos: Guerrero gana +10 (máximo 20); pasar a una clase de máximo 10 recorta el exceso.
     * Dispara {@link SVZClaseChangeEvent}.
     */
    public static void forceSetClase(ServerPlayer player, SVZClass clase) {
        SVZPlayerData d = SVZData.get(player);
        SVZClass old = d.clase;
        int bonus = clase.getHilosIniciales() - old.getHilosIniciales();
        d.clase = clase;
        d.claseElegida = clase != SVZClass.NINGUNA;
        int nh = d.hilos == 0 ? 0 : Mth.clamp(d.hilos + bonus, 1, clase.getHilosIniciales());
        setHilos(player, nh, Reason.CLASE, null);
        SVZClaseChangeEvent.EVENT.invoker().onClaseChange(player, old, clase);
        SVZNetworking.sync(player);
    }

    // =====================================================================
    // TELAR ROTO E HILO DE VIDA INTERNO
    // =====================================================================

    /** @return {@code true} si el jugador está en la dimensión del Telar Roto. */
    public static boolean isInTelarRoto(ServerPlayer player) {
        return isTelarRoto(((ServerLevel) player.level()).dimension());
    }

    public static boolean isTelarRoto(ResourceKey<Level> dimension) {
        return telarRoto.equals(dimension);
    }

    /**
     * Define qué dimensión es el Telar Roto (por defecto {@code svzcore:telar_roto}).
     * El mod que cree la dimensión debe llamar a esto en su inicialización.
     */
    public static void setTelarRotoDimension(ResourceKey<Level> dimension) {
        telarRoto = dimension;
    }

    /** @return Hilo de Vida interno (0..100). */
    public static int getHiloVidaInterno(ServerPlayer player) {
        return SVZData.get(player).hiloVidaInterno;
    }

    /**
     * Fija el Hilo de Vida interno (0..100). No provoca muerte permanente por sí mismo;
     * para gastar con consecuencias usa {@link #spendHiloVidaInterno(ServerPlayer, int)}.
     */
    public static void setHiloVidaInterno(ServerPlayer player, int value) {
        SVZData.get(player).hiloVidaInterno = Mth.clamp(value, 0, SVZConfig.HILO_VIDA_MAX);
        SVZNetworking.sync(player);
    }

    /**
     * Gasta Hilo de Vida interno. Solo actúa dentro del Telar Roto. Si llega a 0 el jugador
     * muere de forma <b>permanente</b> (pasa a espectador al reaparecer) y se dispara
     * {@link com.svz.core.event.SVZMuerteTelarEvent} con {@code permanente = true}.
     * Llámalo desde otros mods para acciones de "farmeo" propias.
     */
    public static void spendHiloVidaInterno(ServerPlayer player, int amount) {
        if (amount <= 0 || !isInTelarRoto(player)) return;
        SVZPlayerData d = SVZData.get(player);
        if (d.muertePermanente) return;
        d.hiloVidaInterno = Math.max(0, d.hiloVidaInterno - amount);
        SVZNetworking.sync(player);
        if (d.hiloVidaInterno == 0) {
            d.muertePermanente = true;
            if (player.isAlive()) player.kill((ServerLevel) player.level());
        }
    }

    /**
     * Inicializa el Hilo de Vida interno al entrar al Telar Roto: 100, o 0 si el jugador
     * llega poseído por pérdida total de hilos. Se llama solo al cambiar de dimensión.
     */
    public static void iniciarHiloVidaInterno(ServerPlayer player) {
        SVZPlayerData d = SVZData.get(player);
        d.hiloVidaInterno = d.poseido ? 0 : SVZConfig.HILO_VIDA_MAX;
        SVZNetworking.sync(player);
    }

    /** @return {@code true} si el jugador sufrió muerte permanente en el Telar Roto. */
    public static boolean isMuertePermanente(ServerPlayer player) {
        return SVZData.get(player).muertePermanente;
    }

    /** Quita o pone la marca de muerte permanente (p. ej. resurrección admin). */
    public static void setMuertePermanente(ServerPlayer player, boolean value) {
        SVZData.get(player).muertePermanente = value;
        if (!value && player.isSpectator()) player.setGameMode(GameType.SURVIVAL);
        SVZNetworking.sync(player);
    }

    // =====================================================================
    // OBJETOS LLEVADOS (para el HUD; los items viven en SVZ-Items)
    // =====================================================================

    /** SVZ-Items debe llamar a esto cuando el jugador lleve/deje de llevar un Hilo de Vida. */
    public static void setLlevaHiloVida(ServerPlayer player, boolean lleva) {
        SVZData.get(player).llevaHiloVida = lleva;
        SVZNetworking.sync(player);
    }

    /** SVZ-Items debe llamar a esto cuando el jugador lleve/deje de llevar un Hilo de Cofre. */
    public static void setLlevaHiloCofre(ServerPlayer player, boolean lleva) {
        SVZData.get(player).llevaHiloCofre = lleva;
        SVZNetworking.sync(player);
    }

    public static boolean llevaHiloVida(ServerPlayer player) {
        return SVZData.get(player).llevaHiloVida;
    }

    public static boolean llevaHiloCofre(ServerPlayer player) {
        return SVZData.get(player).llevaHiloCofre;
    }
}
