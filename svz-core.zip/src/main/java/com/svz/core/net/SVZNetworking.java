package com.svz.core.net;

import com.svz.core.api.SVZCoreAPI;
import com.svz.core.data.SVZData;
import com.svz.core.data.SVZPlayerData;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.level.ServerPlayer;

public final class SVZNetworking {
    private SVZNetworking() {}

    public static void registerPayloads() {
        PayloadTypeRegistry.playS2C().register(SVZSyncPayload.TYPE, SVZSyncPayload.CODEC);
    }

    /** Envía el estado actual del jugador a su cliente. */
    public static void sync(ServerPlayer player) {
        if (player.connection == null) return;
        SVZPlayerData d = SVZData.get(player);
        ServerPlayNetworking.send(player, new SVZSyncPayload(
                d.hilos, SVZCoreAPI.getMaxHilos(player), d.hiloVidaInterno,
                SVZCoreAPI.isInTelarRoto(player), d.poseido,
                d.llevaHiloVida, d.llevaHiloCofre, d.clase));
    }
}
