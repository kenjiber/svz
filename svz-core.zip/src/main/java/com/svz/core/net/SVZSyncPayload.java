package com.svz.core.net;

import com.svz.core.SVZCore;
import com.svz.core.api.SVZClass;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** Estado del jugador enviado servidor -> cliente para el HUD. */
public record SVZSyncPayload(int hilos, int maxHilos, int hiloVida, boolean enTelar, boolean poseido,
                             boolean llevaHiloVida, boolean llevaHiloCofre, SVZClass clase)
        implements CustomPacketPayload {

    public static final Type<SVZSyncPayload> TYPE =
            new Type<>(Identifier.fromNamespaceAndPath(SVZCore.MOD_ID, "sync"));

    public static final StreamCodec<RegistryFriendlyByteBuf, SVZSyncPayload> CODEC =
            StreamCodec.of(SVZSyncPayload::write, SVZSyncPayload::read);

    private static void write(RegistryFriendlyByteBuf buf, SVZSyncPayload p) {
        buf.writeVarInt(p.hilos);
        buf.writeVarInt(p.maxHilos);
        buf.writeVarInt(p.hiloVida);
        buf.writeBoolean(p.enTelar);
        buf.writeBoolean(p.poseido);
        buf.writeBoolean(p.llevaHiloVida);
        buf.writeBoolean(p.llevaHiloCofre);
        buf.writeVarInt(p.clase.ordinal());
    }

    private static SVZSyncPayload read(RegistryFriendlyByteBuf buf) {
        return new SVZSyncPayload(buf.readVarInt(), buf.readVarInt(), buf.readVarInt(),
                buf.readBoolean(), buf.readBoolean(), buf.readBoolean(), buf.readBoolean(),
                SVZClass.values()[buf.readVarInt()]);
    }

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
