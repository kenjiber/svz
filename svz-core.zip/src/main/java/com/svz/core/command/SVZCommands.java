package com.svz.core.command;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.svz.core.api.SVZClass;
import com.svz.core.api.SVZCoreAPI;
import com.svz.core.event.SVZHilosChangeEvent.Reason;
import com.svz.core.event.SVZPosesionEvent;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

import java.util.Arrays;
import java.util.function.Predicate;

public final class SVZCommands {
    private SVZCommands() {}

    // NOTA 1.21.11: si esta línea no compila, es el único punto que depende del nuevo sistema de permisos.
    private static final Predicate<CommandSourceStack> ADMIN = Commands.hasPermission(Commands.LEVEL_GAMEMASTERS);

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(Commands.literal("svz")
                        .then(Commands.literal("hilos")
                                .then(Commands.argument("jugador", EntityArgument.player())
                                        .executes(SVZCommands::hilos)))
                        .then(Commands.literal("setclase").requires(ADMIN)
                                .then(Commands.argument("jugador", EntityArgument.player())
                                        .then(Commands.argument("clase", StringArgumentType.word())
                                                .suggests((c, b) -> SharedSuggestionProvider.suggest(
                                                        Arrays.stream(SVZClass.values()).map(SVZClass::getSerializedName), b))
                                                .executes(SVZCommands::setClase))))
                        .then(Commands.literal("sethilos").requires(ADMIN)
                                .then(Commands.argument("jugador", EntityArgument.player())
                                        .then(Commands.argument("cantidad", IntegerArgumentType.integer(0))
                                                .executes(SVZCommands::setHilos))))
                        .then(Commands.literal("poseer").requires(ADMIN)
                                .then(Commands.argument("jugador", EntityArgument.player())
                                        .executes(SVZCommands::poseer)))));
    }

    private static int hilos(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer p = EntityArgument.getPlayer(ctx, "jugador");
        String msg = p.getName().getString() + ": Hilos del Alma " + SVZCoreAPI.getHilos(p) + "/" + SVZCoreAPI.getMaxHilos(p)
                + " | Clase: " + SVZCoreAPI.getClase(p).getSerializedName()
                + " | Poseído: " + (SVZCoreAPI.isPoseido(p) ? "sí" : "no");
        ctx.getSource().sendSuccess(() -> Component.literal(msg), false);
        return SVZCoreAPI.getHilos(p);
    }

    private static int setClase(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer p = EntityArgument.getPlayer(ctx, "jugador");
        SVZClass clase = SVZClass.byName(StringArgumentType.getString(ctx, "clase"));
        if (clase == null) {
            ctx.getSource().sendFailure(Component.literal("Clase inválida. Opciones: chef, herrero, guerrero, ninguna."));
            return 0;
        }
        SVZCoreAPI.forceSetClase(p, clase);
        ctx.getSource().sendSuccess(() -> Component.literal(
                "Clase de " + p.getName().getString() + " = " + clase.getSerializedName()), true);
        return 1;
    }

    private static int setHilos(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer p = EntityArgument.getPlayer(ctx, "jugador");
        SVZCoreAPI.setHilos(p, IntegerArgumentType.getInteger(ctx, "cantidad"), Reason.ADMIN, null);
        ctx.getSource().sendSuccess(() -> Component.literal(
                "Hilos de " + p.getName().getString() + " = " + SVZCoreAPI.getHilos(p)
                        + " (máx. " + SVZCoreAPI.getMaxHilos(p) + ")"), true);
        return SVZCoreAPI.getHilos(p);
    }

    private static int poseer(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer p = EntityArgument.getPlayer(ctx, "jugador");
        SVZCoreAPI.setPoseido(p, true, SVZPosesionEvent.Causa.ADMIN);
        ctx.getSource().sendSuccess(() -> Component.literal(p.getName().getString() + " ahora está poseído."), true);
        return 1;
    }
}
