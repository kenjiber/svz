package com.svz.core;

import com.svz.core.command.SVZCommands;
import com.svz.core.data.SVZData;
import com.svz.core.logic.SVZEventHandlers;
import com.svz.core.net.SVZNetworking;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SVZCore implements ModInitializer {
    public static final String MOD_ID = "svzcore";
    public static final Logger LOGGER = LoggerFactory.getLogger("SVZ-Core");

    @Override
    public void onInitialize() {
        SVZData.register();
        SVZNetworking.registerPayloads();
        SVZEventHandlers.register();
        SVZCommands.register();
        LOGGER.info("SVZ-Core cargado.");
    }
}
