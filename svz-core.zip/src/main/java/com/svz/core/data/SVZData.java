package com.svz.core.data;

import com.svz.core.SVZCore;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;

/** Registro del attachment persistente de jugador (Fabric Data Attachment API). */
public final class SVZData {
    private SVZData() {}

    public static AttachmentType<SVZPlayerData> TYPE;

    public static void register() {
        TYPE = AttachmentRegistry.<SVZPlayerData>create(
                Identifier.fromNamespaceAndPath(SVZCore.MOD_ID, "player_data"),
                b -> b.initializer(SVZPlayerData::new)
                        .persistent(SVZPlayerData.CODEC)
                        .copyOnDeath());
    }

    public static SVZPlayerData get(ServerPlayer player) {
        return player.getAttachedOrCreate(TYPE);
    }
}
