package com.svz.core.data;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.svz.core.SVZConfig;
import com.svz.core.api.SVZClass;

/** Datos persistentes por jugador (se guardan en el NBT del jugador). Uso interno: usa SVZCoreAPI. */
public final class SVZPlayerData {
    public int hilos = SVZConfig.HILOS_BASE;
    public SVZClass clase = SVZClass.NINGUNA;
    public boolean claseElegida = false;
    public int hiloVidaInterno = SVZConfig.HILO_VIDA_MAX;
    public boolean poseido = false;
    public boolean muertePermanente = false;
    public boolean llevaHiloVida = false;
    public boolean llevaHiloCofre = false;

    public static final Codec<SVZPlayerData> CODEC = RecordCodecBuilder.create(i -> i.group(
            Codec.INT.optionalFieldOf("hilos_del_alma", SVZConfig.HILOS_BASE).forGetter(d -> d.hilos),
            SVZClass.CODEC.optionalFieldOf("clase", SVZClass.NINGUNA).forGetter(d -> d.clase),
            Codec.BOOL.optionalFieldOf("clase_elegida", false).forGetter(d -> d.claseElegida),
            Codec.INT.optionalFieldOf("hilo_vida_interno", SVZConfig.HILO_VIDA_MAX).forGetter(d -> d.hiloVidaInterno),
            Codec.BOOL.optionalFieldOf("poseido", false).forGetter(d -> d.poseido),
            Codec.BOOL.optionalFieldOf("muerte_permanente", false).forGetter(d -> d.muertePermanente),
            Codec.BOOL.optionalFieldOf("lleva_hilo_vida", false).forGetter(d -> d.llevaHiloVida),
            Codec.BOOL.optionalFieldOf("lleva_hilo_cofre", false).forGetter(d -> d.llevaHiloCofre)
    ).apply(i, SVZPlayerData::new));

    public SVZPlayerData() {}

    private SVZPlayerData(int hilos, SVZClass clase, boolean claseElegida, int hiloVida, boolean poseido,
                          boolean muertePermanente, boolean llevaVida, boolean llevaCofre) {
        this.hilos = hilos;
        this.clase = clase;
        this.claseElegida = claseElegida;
        this.hiloVidaInterno = hiloVida;
        this.poseido = poseido;
        this.muertePermanente = muertePermanente;
        this.llevaHiloVida = llevaVida;
        this.llevaHiloCofre = llevaCofre;
    }
}
