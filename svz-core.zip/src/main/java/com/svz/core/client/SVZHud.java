package com.svz.core.client;

import com.svz.core.SVZConfig;
import com.svz.core.SVZCore;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.Identifier;

import java.util.Comparator;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * HUD de SVZ (arriba a la izquierda). Otros mods pueden añadir bloques con
 * {@link #registerElement(Identifier, int, Element)} y reemplazar los iconos
 * (por ejemplo con texturas de SVZ-Items) con {@link #setIconRenderer(IconType, IconRenderer)}.
 * Los iconos por defecto se dibujan por código: este mod no incluye texturas.
 */
public final class SVZHud {
    private SVZHud() {}

    /** Bloque del HUD. Se apila verticalmente en orden ascendente de {@code order}. */
    @FunctionalInterface
    public interface Element {
        /**
         * @param x esquina izquierda disponible
         * @param y esquina superior disponible
         * @return alto en píxeles que ocupó (incluye margen); 0 si no dibujó nada
         */
        int render(GuiGraphics graphics, DeltaTracker delta, int x, int y);
    }

    /** Dibuja un icono de {@code size}x{@code size} px. */
    @FunctionalInterface
    public interface IconRenderer {
        void render(GuiGraphics graphics, int x, int y, int size, int argbColor, boolean filled);
    }

    public enum IconType { HILO_ALMA, HILO_VIDA, HILO_COFRE }

    private record Entry(Identifier id, int order, Element element) {}

    private static final List<Entry> ENTRIES = new CopyOnWriteArrayList<>();
    private static final Map<IconType, IconRenderer> ICONS = new EnumMap<>(IconType.class);

    private static final int COLOR_ALMA = 0xFFE8E8F5;
    private static final int COLOR_VIDA = 0xFFE05A5A;
    private static final int COLOR_COFRE = 0xFFD9A441;
    private static final int COLOR_VACIO = 0xFF3A3A44;

    /** Registra un bloque del HUD con orden por defecto (1000). */
    public static void registerElement(Identifier id, Element element) {
        registerElement(id, 1000, element);
    }

    /** Registra (o reemplaza) un bloque del HUD. Menor {@code order} = más arriba. */
    public static void registerElement(Identifier id, int order, Element element) {
        ENTRIES.removeIf(e -> e.id().equals(id));
        ENTRIES.add(new Entry(id, order, element));
        ENTRIES.sort(Comparator.comparingInt(Entry::order));
    }

    /** Reemplaza cómo se dibuja un tipo de icono (p. ej. con una textura). */
    public static void setIconRenderer(IconType type, IconRenderer renderer) {
        ICONS.put(type, renderer);
    }

    /** Dibuja un icono con el renderer actual del tipo. */
    public static void drawIcon(GuiGraphics g, IconType type, int x, int y, int size, int color, boolean filled) {
        ICONS.get(type).render(g, x, y, size, color, filled);
    }

    static void init() {
        IconRenderer porDefecto = (g, x, y, s, color, filled) -> {
            int c = filled ? color : COLOR_VACIO;
            // "Puntada" en cruz: simula un hilo sin necesitar texturas.
            g.fill(x + 3, y, x + 5, y + 8, c);
            g.fill(x, y + 3, x + 8, y + 5, c);
        };
        for (IconType t : IconType.values()) ICONS.put(t, porDefecto);

        registerElement(Identifier.fromNamespaceAndPath(SVZCore.MOD_ID, "hilos_alma"), 0, SVZHud::renderHilosAlma);
        registerElement(Identifier.fromNamespaceAndPath(SVZCore.MOD_ID, "hilo_vida_interno"), 10, SVZHud::renderHiloVida);
        registerElement(Identifier.fromNamespaceAndPath(SVZCore.MOD_ID, "objetos"), 20, SVZHud::renderObjetos);

        HudElementRegistry.addLast(Identifier.fromNamespaceAndPath(SVZCore.MOD_ID, "hud"), SVZHud::renderAll);
    }

    private static void renderAll(GuiGraphics g, DeltaTracker delta) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui || !SVZClientState.hasData) return;
        int y = 4;
        for (Entry e : ENTRIES) y += e.element().render(g, delta, 4, y);
    }

    // ---- Bloques por defecto ----

    private static int renderHilosAlma(GuiGraphics g, DeltaTracker delta, int x, int y) {
        int n = SVZClientState.hilos;
        int max = SVZClientState.maxHilos;
        boolean alerta = n >= SVZConfig.ALERTA_MIN && n <= SVZConfig.ALERTA_MAX;
        boolean parpadeo = alerta && (System.currentTimeMillis() / 300) % 2 == 0;
        int color = alerta ? (parpadeo ? 0xFFFF2A2A : 0xFF7A1212) : COLOR_ALMA;

        for (int i = 0; i < max; i++) {
            int cx = x + (i % 10) * 11;
            int cy = y + (i / 10) * 11;
            drawIcon(g, IconType.HILO_ALMA, cx, cy, 9, color, i < n);
        }
        int rows = (max + 9) / 10;
        int h = rows * 11;
        if (SVZClientState.poseido) {
            g.drawString(Minecraft.getInstance().font, "POSEÍDO", x, y + h, 0xFFFF3030);
            h += 10;
        }
        return h + 3;
    }

    private static int renderHiloVida(GuiGraphics g, DeltaTracker delta, int x, int y) {
        if (!SVZClientState.enTelar) return 0;
        int v = SVZClientState.hiloVida;
        int max = SVZConfig.HILO_VIDA_MAX;
        boolean bajo = v <= max / 5;
        boolean parpadeo = bajo && (System.currentTimeMillis() / 300) % 2 == 0;
        int color = bajo ? (parpadeo ? 0xFFFF2A2A : 0xFF7A1212) : COLOR_VIDA;

        g.drawString(Minecraft.getInstance().font, "Hilo de Vida: " + v + "/" + max, x, y, 0xFFFFFFFF);
        int bw = 90;
        g.fill(x, y + 11, x + bw, y + 16, COLOR_VACIO);
        g.fill(x, y + 11, x + (int) (bw * (v / (float) max)), y + 16, color);
        return 20;
    }

    private static int renderObjetos(GuiGraphics g, DeltaTracker delta, int x, int y) {
        boolean vida = SVZClientState.llevaHiloVida;
        boolean cofre = SVZClientState.llevaHiloCofre;
        if (!vida && !cofre) return 0;
        int cx = x;
        if (vida) {
            drawIcon(g, IconType.HILO_VIDA, cx, y, 9, COLOR_VIDA, true);
            cx += 12;
        }
        if (cofre) {
            drawIcon(g, IconType.HILO_COFRE, cx, y, 9, COLOR_COFRE, true);
        }
        return 12;
    }
}
