package com.svz.core.client;

import com.svz.core.net.SVZSyncPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;

public class SVZCoreClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(SVZSyncPayload.TYPE,
                (payload, context) -> SVZClientState.apply(payload));
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> SVZClientState.reset());
        SVZHud.init();
    }
}
