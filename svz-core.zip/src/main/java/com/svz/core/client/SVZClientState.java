package com.svz.core.client;

import com.svz.core.api.SVZClass;
import com.svz.core.net.SVZSyncPayload;

/** Copia en el cliente del estado del jugador local (solo lectura para el HUD y otros mods cliente). */
public final class SVZClientState {
    private SVZClientState() {}

    public static volatile boolean hasData = false;
    public static volatile int hilos = 10;
    public static volatile int maxHilos = 10;
    public static volatile int hiloVida = 100;
    public static volatile boolean enTelar = false;
    public static volatile boolean poseido = false;
    public static volatile boolean llevaHiloVida = false;
    public static volatile boolean llevaHiloCofre = false;
    public static volatile SVZClass clase = SVZClass.NINGUNA;

    static void apply(SVZSyncPayload p) {
        hilos = p.hilos();
        maxHilos = p.maxHilos();
        hiloVida = p.hiloVida();
        enTelar = p.enTelar();
        poseido = p.poseido();
        llevaHiloVida = p.llevaHiloVida();
        llevaHiloCofre = p.llevaHiloCofre();
        clase = p.clase();
        hasData = true;
    }

    static void reset() {
        hasData = false;
    }
}
