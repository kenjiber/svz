package com.svz.core.api;

import com.mojang.serialization.Codec;
import com.svz.core.SVZConfig;
import net.minecraft.util.StringRepresentable;

/**
 * Clases de jugador de Sobreviviendo a Venezuela.
 * Cada jugador elige clase una sola vez.
 */
public enum SVZClass implements StringRepresentable {
    CHEF("chef", SVZConfig.HILOS_BASE),
    HERRERO("herrero", SVZConfig.HILOS_BASE),
    GUERRERO("guerrero", SVZConfig.HILOS_GUERRERO),
    /** Estado inicial: el jugador aún no ha elegido clase. */
    NINGUNA("ninguna", SVZConfig.HILOS_BASE);

    public static final Codec<SVZClass> CODEC = StringRepresentable.fromEnum(SVZClass::values);

    private final String id;
    private final int hilosIniciales;

    SVZClass(String id, int hilosIniciales) {
        this.id = id;
        this.hilosIniciales = hilosIniciales;
    }

    /** @return hilos del alma con los que empieza (y máximo) esta clase. */
    public int getHilosIniciales() {
        return hilosIniciales;
    }

    @Override
    public String getSerializedName() {
        return id;
    }

    /** @return la clase con ese nombre (sin distinguir mayúsculas) o {@code null}. */
    public static SVZClass byName(String name) {
        for (SVZClass c : values()) {
            if (c.id.equalsIgnoreCase(name)) return c;
        }
        return null;
    }
}
