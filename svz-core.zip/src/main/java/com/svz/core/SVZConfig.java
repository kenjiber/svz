package com.svz.core;

/** Constantes de balance del núcleo SVZ. Ajusta aquí los valores. */
public final class SVZConfig {
    private SVZConfig() {}

    /** SVZ-Posesion lo desactiva para aplicar su propia regla (1 hilo cada 2 golpes). */
    public static boolean DRENAJE_JUGADOR_POSEIDO = true;

    public static final int HILOS_BASE = 10;
    public static final int HILOS_GUERRERO = 20;
    public static final int HILO_VIDA_MAX = 100;

    public static final int PERDIDA_MUERTE = 1;
    public static final int PERDIDA_MUERTE_TELAR = 2;

    /** Hilos que drena un golpe de un mob (tag svzcore:drena_hilos) o jugador poseído. */
    public static final int DRENAJE_POR_GOLPE = 1;

    /** Hilo de vida interno gastado por bloque roto en el Telar Roto. */
    public static final int COSTO_BLOQUE = 1;
    /** Multiplicador: hilo de vida interno gastado = ceil(daño * factor). */
    public static final double FACTOR_DANO = 1.0;

    /** Rango de hilos en el que el HUD parpadea en rojo. */
    public static final int ALERTA_MIN = 1;
    public static final int ALERTA_MAX = 3;
}
