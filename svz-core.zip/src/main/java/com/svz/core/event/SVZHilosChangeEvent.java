package com.svz.core.event;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;

/** Se dispara cuando los Hilos del Alma de un jugador cambian (ganancia o pérdida). */
public final class SVZHilosChangeEvent {
    private SVZHilosChangeEvent() {}

    public static final Event<Listener> EVENT = EventFactory.createArrayBacked(Listener.class,
            listeners -> (p, o, n, r, s) -> {
                for (Listener l : listeners) l.onHilosChange(p, o, n, r, s);
            });

    /** Causa del cambio. */
    public enum Reason { MUERTE, MUERTE_TELAR, DRENAJE, CLASE, ADMIN, API }

    @FunctionalInterface
    public interface Listener {
        /**
         * @param player   jugador afectado
         * @param oldValue hilos antes del cambio
         * @param newValue hilos después del cambio
         * @param reason   causa
         * @param source   entidad responsable (drenaje, etc.); puede ser {@code null}
         */
        void onHilosChange(ServerPlayer player, int oldValue, int newValue, Reason reason, Entity source);
    }
}
