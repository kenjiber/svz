package com.svz.core.event;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;

/** Se dispara cuando un jugador muere dentro del Telar Roto. */
public final class SVZMuerteTelarEvent {
    private SVZMuerteTelarEvent() {}

    public static final Event<Listener> EVENT = EventFactory.createArrayBacked(Listener.class,
            listeners -> (p, s, perm) -> {
                for (Listener l : listeners) l.onMuerteTelar(p, s, perm);
            });

    @FunctionalInterface
    public interface Listener {
        /**
         * @param player     jugador muerto
         * @param source     fuente de daño de la muerte
         * @param permanente {@code true} si fue por agotar el Hilo de Vida interno (muerte permanente)
         */
        void onMuerteTelar(ServerPlayer player, DamageSource source, boolean permanente);
    }
}
