package com.svz.core.event;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.server.level.ServerPlayer;

/** Se dispara cuando un jugador es marcado como poseído. */
public final class SVZPosesionEvent {
    private SVZPosesionEvent() {}

    public static final Event<Listener> EVENT = EventFactory.createArrayBacked(Listener.class,
            listeners -> (p, c) -> {
                for (Listener l : listeners) l.onPosesion(p, c);
            });

    /** Cómo llegó a ser poseído. */
    public enum Causa { HILOS_AGOTADOS, ADMIN, API }

    @FunctionalInterface
    public interface Listener {
        void onPosesion(ServerPlayer player, Causa causa);
    }
}
