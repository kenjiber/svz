package com.svz.core.event;

import com.svz.core.api.SVZClass;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.server.level.ServerPlayer;

/** Se dispara cuando un jugador elige (o un admin cambia) su clase. */
public final class SVZClaseChangeEvent {
    private SVZClaseChangeEvent() {}

    public static final Event<Listener> EVENT = EventFactory.createArrayBacked(Listener.class,
            listeners -> (p, o, n) -> {
                for (Listener l : listeners) l.onClaseChange(p, o, n);
            });

    @FunctionalInterface
    public interface Listener {
        void onClaseChange(ServerPlayer player, SVZClass oldClass, SVZClass newClass);
    }
}
