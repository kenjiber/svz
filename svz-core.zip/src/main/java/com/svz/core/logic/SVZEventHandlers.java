package com.svz.core.logic;

import com.svz.core.SVZConfig;
import com.svz.core.SVZCore;
import com.svz.core.api.SVZCoreAPI;
import com.svz.core.event.SVZHilosChangeEvent.Reason;
import com.svz.core.event.SVZMuerteTelarEvent;
import com.svz.core.net.SVZNetworking;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityWorldChangeEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.TagKey;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.GameType;

/** Reglas automáticas del núcleo: muertes, daño, drenaje, farmeo y cambio de dimensión. */
public final class SVZEventHandlers {
    private SVZEventHandlers() {}

    /** Entidades de este tag drenan hilos al golpear a un jugador. Rellénalo desde SVZ-Mobs vía datapack. */
    public static final TagKey<EntityType<?>> DRENA_HILOS =
            TagKey.create(Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath(SVZCore.MOD_ID, "drena_hilos"));

    public static void register() {
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (entity instanceof ServerPlayer p) onDeath(p, source);
        });

        ServerLivingEntityEvents.AFTER_DAMAGE.register((entity, source, baseDamage, damageTaken, blocked) -> {
            if (entity instanceof ServerPlayer p && damageTaken > 0) onDamage(p, source, damageTaken);
        });

        PlayerBlockBreakEvents.AFTER.register((level, player, pos, state, be) -> {
            if (player instanceof ServerPlayer sp) SVZCoreAPI.spendHiloVidaInterno(sp, SVZConfig.COSTO_BLOQUE);
        });

        ServerEntityWorldChangeEvents.AFTER_PLAYER_CHANGE_WORLD.register((player, origin, destination) -> {
            boolean entra = SVZCoreAPI.isTelarRoto(destination.dimension()) && !SVZCoreAPI.isTelarRoto(origin.dimension());
            if (entra) SVZCoreAPI.iniciarHiloVidaInterno(player);
            else SVZNetworking.sync(player);
        });

        ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
            aplicarMuertePermanente(newPlayer);
            SVZNetworking.sync(newPlayer);
        });

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayer p = handler.getPlayer();
            aplicarMuertePermanente(p);
            SVZNetworking.sync(p);
        });
    }

    private static void onDeath(ServerPlayer p, DamageSource source) {
        if (SVZCoreAPI.isInTelarRoto(p)) {
            SVZCoreAPI.removeHilos(p, SVZConfig.PERDIDA_MUERTE_TELAR, Reason.MUERTE_TELAR, source.getEntity());
            SVZMuerteTelarEvent.EVENT.invoker().onMuerteTelar(p, source, SVZCoreAPI.isMuertePermanente(p));
        } else {
            SVZCoreAPI.removeHilos(p, SVZConfig.PERDIDA_MUERTE, Reason.MUERTE, source.getEntity());
        }
    }

    private static void onDamage(ServerPlayer victim, DamageSource source, float damageTaken) {
        // Gasto de Hilo de Vida interno por daño recibido (solo en el Telar Roto)
        SVZCoreAPI.spendHiloVidaInterno(victim,
                Math.max(1, (int) Math.ceil(damageTaken * SVZConfig.FACTOR_DANO)));

        // Drenaje de hilos por mobs del tag o jugadores poseídos
        Entity attacker = source.getEntity();
        if (attacker == null || attacker == victim || !victim.isAlive()) return;
        boolean drena = attacker.getType().is(DRENA_HILOS)
                || (SVZConfig.DRENAJE_JUGADOR_POSEIDO && attacker instanceof ServerPlayer ap && SVZCoreAPI.isPoseido(ap));
        if (drena) SVZCoreAPI.drenarHilos(victim, SVZConfig.DRENAJE_POR_GOLPE, attacker);
    }

    private static void aplicarMuertePermanente(ServerPlayer p) {
        if (SVZCoreAPI.isMuertePermanente(p) && p.isAlive()) p.setGameMode(GameType.SPECTATOR);
    }
}
